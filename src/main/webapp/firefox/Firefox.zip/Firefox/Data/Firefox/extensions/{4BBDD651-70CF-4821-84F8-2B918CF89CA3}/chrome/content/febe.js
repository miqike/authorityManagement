/*
		FEBE - Firefox Environment Backup Extension
		Author:  Chuck Baker
		Version:  8.8.1
*/

var EXPORTED_SYMBOLS = [ "FEBE" ];
if (typeof FEBE == 'undefined') var FEBE = {};

//		Common (global) variables
var Cc = Components.classes;
var Ci = Components.interfaces;
var Cu = Components.utils;

Cu.import("resource://gre/modules/AddonManager.jsm");
Cu.import("resource://gre/modules/PlacesUtils.jsm");
Cu.import("resource://gre/modules/BookmarkHTMLUtils.jsm");
Cu.import("resource://gre/modules/BookmarkJSONUtils.jsm");
Cu.import("resource://gre/modules/Services.jsm");
Cu.import("resource://gre/modules/FileUtils.jsm");
Cu.import("resource://gre/modules/NetUtil.jsm");
Cu.import("resource://gre/modules/osfile.jsm");
Cu.import("resource://gre/modules/Sqlite.jsm");
Cu.import("resource://devtools/shared/Loader.jsm");
Cu.import("resource://gre/modules/FormHistory.jsm");
Cu.import("resource://gre/modules/Promise.jsm");

window.addEventListener('load',function(){FEBE.febeLoad()},true);

document.onreadystatechange = function() {
	let OK = false;
	let windowtype = document.documentElement.getAttribute("windowtype");
	if(windowtype == "navigator:browser") OK = true;
	if(windowtype.indexOf("febe:") == 0) OK = true;
	if(!OK) return true;
	if(document.readyState == "complete") {		
		window.addEventListener("close",FEBE.febeClose,true);
		window.addEventListener("DOMContentLoaded",FEBE.febeCheckForMissedScheduledBackupLoad,true);
		
		FEBE.febeSetMsgs();
		FEBE.febeGetPrefs();
		if(windowtype == "navigator:browser"){
			FEBE.febePreLoad();
		}else{
			FEBE.febeGetAddonList(); 
		}
	}
	return true;
}

// Listen for addons being installed or uninstalled and load addon info
var listener = {
  onInstalled: function(addon){
    FEBE.febePreLoad();
  },
  onUninstalled: function(addon){
    FEBE.febePreLoad();
  }
}
AddonManager.addAddonListener(listener);

function febeObserverSvc(){
	this.register();
}

// Replacement for deprecated Application.storage
var FEBEstorage = {
	topWin: Cc["@mozilla.org/appshell/window-mediator;1"].getService(Ci.nsIWindowMediator).getMostRecentWindow("navigator:browser"),  
	setItem: function setItem(key, value){
			if(typeof this.topWin.storage == "undefined") this.topWin.storage = {};
			if(key == null || key == "") return false;
			this.topWin.storage[key] = value;
			return true;
	},
	getItem: function getItem(key,dFault){
			if(key == null || key == "") return false;
			if(typeof this.topWin.storage[key] == "undefined") return dFault;
			let value = this.topWin.storage[key];
			return value;
	}
}

febeObserverSvc.prototype = {
	observe: function(subject, topic, data) {
		switch(topic){
			case "quit-application-requested":
				if(data == null) break;
				FEBE.setStyles();
				if(!FEBE.febePrefs.getBoolPref("extensions.febe.backupOnShutdown")){break;}	// Backup on shutdown?
				if(FEBEstorage.getItem("shuttingDownAfterProfileRestore", false)){break;}
				if(!FEBEstorage.getItem("backupOnShutdownCompleted", false)){		// See if shutdown backup has already run		
					if(data != "restart"){	// Ignore restarts, only backup on shutdown (quit)
						if(!FEBE.febeCheckWaitTime("shutdown")){break;}
						if(FEBE.febePrefs.getBoolPref("extensions.febe.backupOnShutdown.prompt")){
							let tmp = FEBE.febeStyle.purple12+FEBE.febeMsg[282]+"\n";
							tmp += FEBE.febeStyle.black+FEBE.febeMsg[283]+"\n";
							if(!FEBE.febeConfirm(tmp)){return true;}
						}
						subject.QueryInterface(Ci.nsISupportsPRBool);
						subject.data = true;											// Abort the shutdown
						FEBE.febeBackupRunType = 3;	// 'On shutdown'
						FEBE.febePrefs.setCharPref("extensions.febe.lastbackuponshutdown",FEBE.febeNow())
						FEBE.initBackup();														// Perform the backup						
						FEBEstorage.setItem("backupOnShutdownCompleted", true);		// Set the flag so we don't run it again
						let wait = FEBE.febePrefs.getIntPref("extensions.febe.grace.shutdown");
						febeDebug("Shutting down in "+wait+" seconds");
						FEBE.febeMainWindow.setTimeout(function(){FEBE.febeShutdown();},wait * 1000);
					}
				}
				break;
			default:
				break;
		}
		return true;
	},
	
	register: function() {
		let observerService = Cc["@mozilla.org/observer-service;1"].getService(Ci.nsIObserverService);
		observerService.addObserver(this, "quit-application-requested", false);
		return true;
	},
	
	unregister: function() {
		let observerService = Cc["@mozilla.org/observer-service;1"].getService(Ci.nsIObserverService);
		try{
			observerService.removeObserver(this, "quit-application-requested");
		}catch(e){;;}
		return true;
	},
	
	notify: function(subject, topic, data){
		let observerService = Cc["@mozilla.org/observer-service;1"].getService(Ci.nsIObserverService);
		observerService.notifyObservers(subject, topic, data);
		return true;
	}
}

function febeDelayedBuObj(initiated,tooltip,PID,buTime){
	this.initiated = initiated;
	this.tooltip = tooltip;
	this.PID = PID;
	this.buTime = buTime;
	return true;
}

function febeDebug(msg){
	try{
		if(FEBE.febeMainWindow.FEBE.debug){
			FEBE.febeMainWindow.FEBE.logMsg(msg);
		}
	}catch(err){;;}
	return true;
}

FEBE = {
	debug: false,
	febeAddedToIgnoreList: [],					// Hold items added to ignore list when prompted during backup
	febeAddonDataExternallyLoaded: {},	// Holds info about saved "all addons" data
	febeAddons: {},											// Array of installed add-ons
	febeAdditionalCnt: 0,								// Count of additional items backed up (i.e., cookies, bookarks, etc.)
	febeAdditionalList: {},
	febeBackupAborted: false,						// Set to true if backup is aborted by user
	febeBackupRunType: 0,								// 1=Manual, 2=On startup, 3=On shutdown, 4=Scheduled, 5=Reminded, 6=Delayed
	febeBUdate: new Date(),							// Date of backup to restore
	febeBuDesDir: "",										// Pointer to backup destination directory
	febeBuItemVerifiedList: {},
	febeBUtype: "",											// "selective" , "profile, or "alternate"
	febeCheckAM: false,									// Running  'Check AddonManager functionality' routine
	febeClearDestDir: false, 						// Clear destination directory?
	febeClipboard: [],									// Holds alert messages for the clipboard
	febeControllerWindow: null,					// Pointer to the window that is controlling the scheduled backup
	febeDataFile: {},										// Pointer to FEBEDATAFILE
	febeDestDir: "",										// nsIFile pointer used in febeDirCopy()
	febeDestDirs: [],										// Array holding the pathnames of all backup destination directories
	FEBEdir: "",												// Pointer to FEBE extension directory
	febeDisabledCount: 0,								// Count of disabled extensions
	febeErr: "",												// Error variable
	febeErrorList: [],									// Array holding failed items (errors)
	febeETinstall: [],									// Array of ext/theme objects to install
	febeExBuDir: "",										// Directory where the results are stored
	febeExtBuName: "",									// Name of file being backed up
	febeExtensionsList: {},							// Array holding extension names
	febeFEBEbackedUp: false,						// Has FEBE itself been backed up?
	febeFixList: [],										// List of directory entries that have permissions to fix
	febeIgnoreError: "",								// Error to ignore
	febeIgnoreList: {},									//  List of add-ons to ignore
	febeIncludeFEBEinBu: "",						// Include a copy of FEBE with backup?
	febeInitialized: false,							// Initalize run: function (yet?
	febeInstallDirectory: {},						// Location of FEBE (nsiFile)
	febeIsOnlineBackup: false,					// To determine if backup is local or online
	febeIsScheduledBu: false,						// Is currently running backup a scheduled one?
	febeIsScheduleController: false,		// If true, this window is controlling the FEBE scheduler
	febeItemCount: 0,										// Count of items to be backed up (used in progress meter)
	febeLastSheduledBackupMissed: false,	// If true, the last scheduled backup was missed (used in 'When to backup' prefpane)
	febeLocalizedStr: {},								// "extensions", " themes", "bookmarks", etc.
	febeMainWindow: {},									// Pointer to main browser window
	febeMaxDirs: 0,											// Maximum number of timestamped directories
	febeMsg: [],												// Array holding localized strings
	febeNamespace: 'http://www.w3.org/1999/xhtml',	// HTML5 namespace
	febeObserver: new febeObserverSvc(),
	febeOtherCloudServices: {},					// Other cloud services information
	febePathName: "",										// Holds full path name of various files
	febePendingCount: 0,								// Number of pending extension/theme installs
	febePfName: "",											// Same as this.febePrName
	febePfParent: "",										// Parent directory of filel picker file
	febePlatform: 0,										// 1=Windows, 2=*nix, 3=Mac 
	febePlaySoundsURI: {},							// Location of sounds
	febePrName: "",											// Leafname of file picker file
	febeProfDir: "",										// Pointer to profile directory
	febeProfileBackupIsSelected: false,
	febeProfileDestinationIsSelected: false,
	febeProfileIndex: -1,								// Number of index of profile being restored
	febeProfileService: Cc["@mozilla.org/toolkit/profile-service;1"].getService(Ci.nsIToolkitProfileService),

	febeProfileWin: {},									// Profile restore window
	febeProfList: [],
	febeProfName: "",										// Profile name
	febeProgressCount: 0,								// Current count of items to be backed up (used in progress meter)
	febeProgressWin: {},								// Window object for FEBE progress window
	febeReminded: false,								// If true,  dont show backup reminder
	febeSkippedList: {},								// Array of items skipped (Ignored, Global, Proxy items)
	febeSkippedScheduledLastChecked: 0,	// Used to determined if scheduled  backup was missed (due to sleep mode)
	febeStatusSave: "",									// Current value of  dom.disable_window_status_change
	febeSubRootDir: "",									// Used in febeDirCopy()
	febeThemesList: {},									// Array holding theme names
	febeTmpDir: "",											// nsIFile pointer to temp directory
	febeUDBuDone: [],										// Array of completed User-defined backups
	febeUseTimestampedDir: false,				// Create timestamped subdirectories?
	febeVerifyExtList: [],
	febeVersion: "",										// Version of this extension (FEBE)
	febeWarningList: [],								// Array holding failed items (warnings)
	febeWelcomePage: "",								// URL of welcome page
	febeWin: {},												// Window object for FEBE windows
	febex: "",  												// Misc flag
	fxVer: Cc['@mozilla.org/xre/app-info;1'].getService(Ci.nsIXULAppInfo).version,	// Version of Firefox currently running

	// Preferences
	febeBuBookmarksHTML: false,					// Backup bookmarks.(.html)?
	febeBuBookmarksJSON: false,					// Backup bookmarks.(.json)?
	febeBuBrowserHistory: false,				// Backup history.dat?
	febeBuCookies: false,								// Backup cookies.txt?
	febeBuExtensions: false,						// Backup extensions?
	febeBuFormFillHistory: false,				// Backup formhistory.dat?
	febeBuPermissions: false,						// Backup hostperm.1?
	febeBuPreferences: false,						// Backup prefs.js?
	febeBuProfile: false,								// Backup entire profile?
	febeBuSearchPlugins: false,					// Backup searchplungins directory?
	febeBuThemes: false,								// Backup themes?
	febeBuUDBu: false,									// Backup User-defined backups?
	febeBuUserChrome: false,						// Backup userChrome.css?
	febeBuUserPwd: false,								// Backup key3.db and signons.txt?
	febeDispProgress: false,						// Display progress window?
	febeDispResults: false,							// Display results page?
	febeGlobalList: {},									// List of globally installed items (GUIDs)
	febeHideHelp: false,								// Hide help icons?
	febeHideIcons: false,								// Hide statusbar icons?
	febeIgnoreDisabled: false,					// Ignore disabled extension?
	febePlaySounds: false,							// Play sounds?
	febeRunAsync: true,									// Run zip routine asynchronously?
	febeSaveResults: false,							// Save results page?
	febeVerifyBackups: false,						// Verify backups?
	selectedItemsList: {},
	febeSimpleStorage: require("sdk/simple-storage"),	

	// Backup file names
	febeBmBuNameHTML: "",								// Bookmarks backup filename (.html)
	febeBmBuNameJSON: "",								// Bookmarks backup filename (json)
	febeChBuName: "",										// UserChrome backup filename
	febeCkBuName: "",										// Cookies backup filename
	febeFfBuName: "",										// Form fill history backup filename
	febeHsBuName: "",										// Browser history backup filename
	febePmBuName: "",										// Permissions backup filename
	febePrBuName: "",										// Preferences backup filename
	febePwBuName: "",										// Password backup filename
	febeSpBuName: "",										// Search plugins backup filename
	febeUdBuName: "",										// User-defined backup filename
	febeUpBuName: "",										// User profile backup filename
	
	// Variables used in scheduler
	febeBackupInProgress: false,				// Is a backup currently running?
	febeScheduledBackupID: 0,						// PID of scheduled backup
	febeNextBackup: "",									// Text description of next scheduled backup
	febeSchedule: "",										// Scheduled backup frequency
	febeIsScheduled: false,							// Is a backup scheduled?
	febeSetTimeoutIDs: [],							// Array holding settimeout ids
	febeDailyHour: 0,										// Hour(00 - 23) of daily backup
	febeDailyMinute: 0,									// Minute (0 - 55) of daily backup, 5 min increments
	febeWeeklyDay: 0,										// Day of week (sun=0 ... sat=6) of daily backup
	febeWeeklyHour: 0,									// Hour(00 - 23) of weekly backup
	febeWeeklyMinute: 0,								// Minute (0 - 55) of weekly backup, 5 min increments
	febeMonthlyDay: 0,									// Day of month (1 - 28) of monthly backup
	febeMonthlyHour: 0,									// Hour(00 - 23) of monthly backup
	febeMonthlyMinute: 0,								// Minute (0 - 55) of monthly backup, 5 min increments
	febeNB: new Date(),									// Next backup date
	febeScheduledBuTimer: {},						// nsITimer object
	
	// Styles used in messages
	febeStyle: {},

	// These should be constants, but CLEO opens this file and re-declares them
	FEBEBUHISTORYFILE: "febeBUhistory.json",
	FEBEDATAFILE: "febeUserDefinedBuData.json",
	FEBEIGNORELISTDATAFILE: "febeIgnoreListData.json",
	FEBEEXTENSIONDATA: "febeExtensionData.json",
	FEBE_GUID: "{4BBDD651-70CF-4821-84F8-2B918CF89CA3}",  // GUID of this extension

	// Get pointer to preferences
	febePrefs: Cc["@mozilla.org/preferences-service;1"].getService(Ci.nsIPrefService).getBranch(""),

	febeUDBuList: [],
	febeUDBuAction: 0,				// 1=New, 2=Edit, 3=Delete
	febeUDBuTrxPending: false,
	febeNameGuidxref: {},
	febeItemsSelectedCount: 0,
	febeItemsListedCount: 0,
	
febePreLoad: function(buType){
	this.debug = this.febePrefs.getBoolPref("extensions.febe.debugMode");
	febeDebug("Executing febePreLoad()")	
	
	// Do not get addon information if backup is 'Full Profile'
	if(buType == "profile") return true
	if(FEBE.febePrefs.getCharPref("extensions.febe.buType") == "profile") return true;
	
	// Build addons information and store in case it cannot be loaded again
	let allAddons = [];
	try{	// File may be locked if opening multiple windows on startup
		FEBE.febeDataFile = Cc["@mozilla.org/file/directory_service;1"].getService(Ci.nsIProperties).get("ProfD", Ci.nsIFile);
		FEBE.febeDataFile.append(FEBE.FEBEEXTENSIONDATA);
		if(FEBE.febeDataFile.exists()) FEBE.febeDataFile.remove(false);
		FEBE.febeDataFile.create(Ci.nsIFile.NORMAL_FILE_TYPE, 0x1ED);	// 0x1ED = 0755, 0x1FF = 0777
		let fos = Cc["@mozilla.org/network/file-output-stream;1"].createInstance(Ci.nsIFileOutputStream);
		fos.init(FEBE.febeDataFile, 0x02 | 0x08 | 0x20, 0x1ED, 0); // write, create, truncate
		
		let cos = Cc["@mozilla.org/intl/converter-output-stream;1"].createInstance(Ci.nsIConverterOutputStream);
		cos.init(fos, "UTF-8", 0, 0x0000);
		AddonManager.getAllAddons(function(addons){
			addons.forEach(function(addon){
				let item = {};
				for(let property in addon){	// Filter out unreachable properties
					try{
						item[property] = addon[property];
					}catch(err){
						item[property] = null;
					}
				}
				
				allAddons.push(item);

				let cache = [];
				let jstr = JSON.stringify(item, function(key, value){
					// Remove circular references (i.e., '_plugin', '_log')
					if(typeof value === 'object' && value !== null){
						if(cache.indexOf(value) !== -1){
							// Circular reference found, ignore
							return;
						}
						cache.push(value);
					}
					return value;
				});
				cache = null;
				
				cos.writeString(jstr+"\n"); 
			});
			cos.close();
			fos.close();
			FEBEstorage.setItem("febeAllAddons", allAddons);
			febeDebug("Addon info downloaded from AMO")
		});
	}catch(err){;;}
	return true;
},
	
febeLoad: function(){
	window.removeEventListener("load",FEBE.febeLoad,true);
	this.errorConsole(null);
	this.febeInitEssentials();	
	this.setDelayedBuVars('get');
	this.initBackupItemList();
	
	// Only do the rest if we're loading a browser window (not alerts, options, help, etc.)
	if(document.documentElement.getAttribute("windowtype") != "navigator:browser") return true;
	
	this.febeCheckIfNewInstall();

	// Check for backup on startup
	let wait = this.febePrefs.getIntPref("extensions.febe.grace.startup");
	febeDebug("Check for backup on startup - grace period: "+wait+" seconds");
	wait = wait * 1000;
	febeDebug("febeLoad: febeAlreadyCheckedForBuOnStartup = "+FEBEstorage.getItem("febeAlreadyCheckedForBuOnStartup", false));
	if(!FEBEstorage.getItem("febeAlreadyCheckedForBuOnStartup", false)){
		setTimeout(function(){
				FEBE.febeCheckBackupOnStartup();
		},wait);
	}
	FEBEstorage.setItem("febeAlreadyCheckedForBuOnStartup", true);
	febeDebug("febeLoad: setting febeAlreadyCheckedForBuOnStartup to true");
	this.febeScheduleBackup(false);
	this.febePrefs.setBoolPref("extensions.febe.backupInProgress",false);
	this.febeDelayedBu = new febeDelayedBuObj(false,null,-1,0);
	this.febePrefs.setBoolPref("extensions.febe.dontaskagain",false);   	// Clear dont ask flag
	return true;
},

setStyles: function(){
	FEBE.febeStyle.purple = "<style>color:purple; font-weight:normal;</style>";
	FEBE.febeStyle.purpleBold = "<style>color:purple; font-weight:bold; font-size:12px;</style>";
	FEBE.febeStyle.purple12 = "<style>color:purple; font-size:12px;</style>";
	FEBE.febeStyle.purpleMargin = "<style>color:purple; font-weight:bold; margin:0px 0px 0px 30px;</style>";	
	FEBE.febeStyle.black = "<style>color:black;</style>";
	FEBE.febeStyle.black8 = "<style>color:black;font-size:8pt;</style>";
	FEBE.febeStyle.black9 = "<style>color:black;font-size:9pt;</style>";
	FEBE.febeStyle.black12 = "<style>color:black; font-size:12px;</style>";
	FEBE.febeStyle.blackBold = "<style>color:black; font-weight:bold; font-size:12px;</style>";
	FEBE.febeStyle.blackMargin = "<style>color:black; margin:0px 0px 0px 30px;</style>";
	FEBE.febeStyle.blackMonospace = "<style>color:black; font-weight:normal;font-family:courier;</style>";
	FEBE.febeStyle.orangeredBold = "<style>color:orangered; font-weight:bold; font-size:12px;</style>";
	FEBE.febeStyle.orangered8 = "<style>color:orangered;font-size:8pt;</style>";
	FEBE.febeStyle.orangered9 = "<style>color:orangered;font-size:9pt;</style>";
	FEBE.febeStyle.orangered10 = "<style>color:orangered;font-size:10pt;</style>";
	FEBE.febeStyle.orangeredBold10 = "<style>color:orangered; font-weight:bold; font-size:10px;</style>";
	FEBE.febeStyle.orangered12 = "<style>color:orangered;font-size:12pt;</style>";
	FEBE.febeStyle.orangered14 = "<style>color:orangered;font-size:14pt;</style>";
	FEBE.febeStyle.orangeredItalic = "<style>color:orangered;font-size:12pt;font-style:italic;</style>";
	febeDebug("Styles set");
	return true;
},

setDelayedBuVars: function(opt){
	if(typeof FEBE.febeDelayedBu === 'undefined'){
		FEBE.febeDelayedBu = new febeDelayedBuObj(false,null,-1,0);
	}
	if(typeof FEBE.febeDelayedBuArray === 'undefined'){
		FEBE.febeDelayedBuArray = [];
	}
	let isDelayedWin = document.documentElement.getAttribute('windowtype') == "febe:delayed";
	if(opt == 'set' && isDelayedWin){
		let save = JSON.stringify(FEBE.febeDelayedBuArray);
		FEBEstorage.setItem("febeDelayedBuArray", save);
	}
	if(opt == 'get' && isDelayedWin){
		let saved = FEBEstorage.getItem("febeDelayedBuArray", "");
		if(saved.length != 0) FEBE.febeDelayedBuArray = JSON.parse(saved);
	}
	return true;
},

initBackupItemList: function(){
	let a1 = ['bookmarks','preferences', 'cookies', 'userChrome', 'usernamePasswords', 'searchPlugins', 'browserHistory', 'formfillHistory', 'permissions', 'userDefinedBackups'];
	let a2 = ['extensions_febe_buBookmarks_json', 'extensions_febe_buPreferences', 'extensions_febe_buCookies', 'extensions_febe_buUserChrome', 'extensions_febe_buUserPwd', 'extensions_febe_buSearchPlugins', 'extensions_febe_buBrowserHistory', 'extensions_febe_buFormFillHistory', 'extensions_febe_buPermissions', 'extensions_febe_buUDBu'];
	for(let i=0; i<a1.length; i++){
		this.selectedItemsList[a1[i]] = {};
		this.selectedItemsList[a1[i]].id = a2[i];
		this.selectedItemsList[a1[i]].exists = null;
		this.selectedItemsList[a1[i]].error = null;
		//this.selectedItemsList[a1[i]].error.message = null;
	}
	febeDebug("initBackupItemList() executed");
	return true;
},

openBrowserConsole: function(){	
	let HUDService = devtools.require("devtools/client/webconsole/hudservice");
	HUDService.toggleBrowserConsole();
	
	let hud = HUDService.getBrowserConsole();
	if(hud) {
		hud.iframeWindow.focus();
	}else{
		HUDService.toggleBrowserConsole();
		let alreadyShown = FEBEstorage.getItem("febeErrorConsoleShown", false);	
		if(!alreadyShown){
			FEBE.errorConsoleInitMsg();
			FEBEstorage.setItem("febeErrorConsoleShown", true);
		}
	}
	return true;
},

toggleBrowserConsole: function(){	
	let HUDService = devtools.require("devtools/client/webconsole/hudservice");	
	let hud = HUDService.getBrowserConsole();
	if(hud){
		// Already open
		hud.iframeWindow.focus();
	}else{
		// Close it if open, Open it closed
		HUDService.toggleBrowserConsole();
	}
	let alreadyShown = FEBEstorage.getItem("febeErrorConsoleShown", false);	
	if(!alreadyShown){
		FEBE.errorConsoleInitMsg();
		FEBEstorage.setItem("febeErrorConsoleShown", true);
	}
	return true;
},

logMsg: function(msg) {
	msg = "FEBE: "+msg;
	try{
		let cs = Cc["@mozilla.org/consoleservice;1"].getService(Ci.nsIConsoleService);
		cs.logStringMessage(msg);
	}catch(er){;;}
	console.log(msg);
	return true;
},
	
propsConsole: function(obj,title,ignoreProperties,ignoreFunctions,ignoreObjects,expandObjs,sort){
	if(title != null){
		title = "("+title+")";
	}else{
		title = "";
	}
	if (obj === null) {
		this.logMsg("propsConsole called with null argument: "+title+"\n");
		return false;
	}
	if (obj === undefined) {
		this.logMsg("propsConsole called with undefined argument: "+title+"\n");
		return false;
	}
	let tmp, line, pVal, type, msg, attrb = [], func = [], objects = [];
	msg = "propsConsole: "+title+"\ntypeof '"+obj+"': ("+typeof obj+"), "+((sort) ? "Sorted" : "Unsorted")+"\n";
	for(let property in obj){
		line = property;
		try{
			pVal = obj[property];
		}catch(err){
			pVal = "(Unreachable)  "+err;
		}
		try{
			type = typeof obj[property];
		}catch(e){
			type = "Unknown";
		}
		try{
			tmp = line + " = "+pVal;
		}catch(e){
			tmp = "(Unreachable)";
		}
		switch(type){
			case 'function':
				if(!ignoreFunctions) func.push(tmp);
				break;
			case 'object':
				if(ignoreObjects) continue;
				try{
					let props = JSON.stringify(obj[property]);
					if(expandObjs && props != "null") tmp += " --> "+props;
				}catch(err){;;}
				objects.push(tmp);
				break;
			default:
				if(!ignoreProperties) attrb.push(tmp);
				break;
		}
	} 
	if(func.length == 0) func.push("(none)");
	if(objects.length == 0) objects.push("(none)");
	if(attrb.length == 0) attrb.push("(none)");

	if(sort){
		attrb.sort();
		func.sort();
		objects.sort();
	}

	if(!ignoreProperties){
		msg += "\n*** PROPERTIES/ATTRIBUTES ***\n";
		for(let i in attrb){
			msg += attrb[i]+"\n";
		}
	}
	
	if(!ignoreFunctions){
		msg += "\n*** FUNCTIONS ***\n";
		for(let i in func){
			msg += func[i]+"\n";
		}
	}
	
	if(!ignoreObjects){
		msg += "\n*** OBJECTS ***\n";
		for(let i in objects){
			msg += objects[i]+"\n";
		}
	}
	this.logMsg(msg);
	return true;
},
		 
febeGetUnicharPref: function (prefName) {
	let tmp = this.febePrefs.getComplexValue(prefName, Ci.nsISupportsString).data;
	return tmp;
},

febeSetUnicharPref: function (prefName, prefValue) {
	let supportsString = Cc["@mozilla.org/supports-string;1"].createInstance(Ci.nsISupportsString);
	supportsString.data = prefValue;
	this.febePrefs.setComplexValue(prefName, Ci.nsISupportsString, supportsString);
}, 

febeResetPref: function (prefName) {
  let prefSvc = Cc["@mozilla.org/preferences-service;1"].getService(Ci.nsIPrefService);
	prefSvc.clearUserPref(prefName);
	let pType = prefSvc.getPrefType(prefName);
	let prefVal;
	switch (pType){
		case prefSvc.PREF_BOOL:	
			prefVal = this.febePrefs.getBoolPref(prefName); 
			break;
		case prefSvc.PREF_INT:
			prefVal = this.febePrefs.getIntPref(prefName);
			break;
		case prefSvc.PREF_STRING:
			prefVal = this.febeGetUnicharPref(prefName);
			break;
	}
	return prefVal;
},
	
febeSetMsgs: function (){
	// Error messages, prompts, etc.
	febeDebug("Executing febeSetMsgs()");
	let wm = Cc["@mozilla.org/appshell/window-mediator;1"].getService(Ci.nsIWindowMediator);  
	this.febeMainWindow = wm.getMostRecentWindow("navigator:browser"); 

	if(!this.febeMsg[0]){
		let bundle = Services.strings.createBundle("chrome://FEBE/locale/febe.properties");
		let enumerator = bundle.getSimpleEnumeration();
		while (enumerator.hasMoreElements()) {
			let string = enumerator.getNext().QueryInterface(Ci.nsIPropertyElement);
			let stringName = string.key;
			if(stringName.substr(0,3) != "msg") continue;
			let index = stringName.substr(3);
			index = parseInt(index);
			let value = string.value;
			this.febeMsg[index] = value;
		}
	}	
	
	// Localize backup item names
	FEBE.febeLocalizedStr["bookmarks"] = FEBE.febeMsg[246];
	FEBE.febeLocalizedStr["cookies"] = FEBE.febeMsg[248];
	FEBE.febeLocalizedStr["directory"] = FEBE.febeMsg[259];
	FEBE.febeLocalizedStr["Error:"] = FEBE.febeMsg[264];
	FEBE.febeLocalizedStr["extension"] = FEBE.febeMsg[244];
	FEBE.febeLocalizedStr["Febe Backups"] = FEBE.febeMsg[263];
	FEBE.febeLocalizedStr["ffhistory"] = FEBE.febeMsg[253];
	FEBE.febeLocalizedStr["history"] = FEBE.febeMsg[252];
	FEBE.febeLocalizedStr["other"] = FEBE.febeMsg[258];
	FEBE.febeLocalizedStr["permissions"] = FEBE.febeMsg[254];
	FEBE.febeLocalizedStr["preferences"] = FEBE.febeMsg[247];
	FEBE.febeLocalizedStr["profile"] = FEBE.febeMsg[256];
	FEBE.febeLocalizedStr["searchPlugins"] = FEBE.febeMsg[251];
	FEBE.febeLocalizedStr["size"] = FEBE.febeMsg[260];
	FEBE.febeLocalizedStr["theme"] = FEBE.febeMsg[245];
	FEBE.febeLocalizedStr["uploaded ok"] = FEBE.febeMsg[262];
	FEBE.febeLocalizedStr["Uploading:"] = FEBE.febeMsg[261];
	FEBE.febeLocalizedStr["userChrome"] = FEBE.febeMsg[249];
	FEBE.febeLocalizedStr["userDefined"] = FEBE.febeMsg[255];
	FEBE.febeLocalizedStr["usernames-passwords"] = FEBE.febeMsg[250];
	FEBEstorage.setItem("febeMsg", FEBE.febeMsg);	// Save messsages for external routines
	return true;
},

febeGetPrefs: function (){
  // Get/set the preferences
	febeDebug("Executing febeGetPrefs()");
	this.febeBuBookmarksHTML = this.febePrefs.getBoolPref("extensions.febe.buBookmarks.html");
	this.febeBuBookmarksJSON = this.febePrefs.getBoolPref("extensions.febe.buBookmarks.json");
	this.febeBuBrowserHistory = this.febePrefs.getBoolPref("extensions.febe.buBrowserHistory");
	this.febeBuCookies = this.febePrefs.getBoolPref("extensions.febe.buCookies");
	this.febeBuExtensions = this.febePrefs.getBoolPref("extensions.febe.buExtensions");
	this.febeBuFormFillHistory = this.febePrefs.getBoolPref("extensions.febe.buFormFillHistory");
	this.febeBuPermissions = this.febePrefs.getBoolPref("extensions.febe.buPermissions");
	this.febeBuPreferences = this.febePrefs.getBoolPref("extensions.febe.buPreferences");
	this.febeBuSearchPlugins = this.febePrefs.getBoolPref("extensions.febe.buSearchPlugins");
	this.febeBuThemes = this.febePrefs.getBoolPref("extensions.febe.buThemes");
	this.febeBuUDBu = this.febePrefs.getBoolPref("extensions.febe.buUDBu");
	this.febeBuUserChrome = this.febePrefs.getBoolPref("extensions.febe.buUserChrome");
	this.febeBuUserPwd = this.febePrefs.getBoolPref("extensions.febe.buUserPwd");
	this.febeClearDestDir = this.febePrefs.getBoolPref("extensions.febe.clearDestDir");
	this.febeDispProgress = this.febePrefs.getBoolPref("extensions.febe.displayprogresswin");
	this.febeDispResults = this.febePrefs.getBoolPref("extensions.febe.displayresultspage");
	this.febeExBuDir = this.febeGetUnicharPref("extensions.febe.curBUdir");	
	this.febeGetBuType();
	this.febeHideHelp = this.febePrefs.getBoolPref("extensions.febe.hidehelp");
	this.febeHideHelpIcons();
	this.febeHideIcons = this.febePrefs.getBoolPref("extensions.febe.hideIcons");
	this.febeIgnoreDisabled = this.febePrefs.getBoolPref("extensions.febe.ignoreDisabled");
	this.febeMaxDirs = this.febePrefs.getIntPref("extensions.febe.maxBuDirs");
	this.febeOtherCloudServices = JSON.parse(this.febeGetUnicharPref("extensions.febe.othercloudservices"));	
	this.febePlaySounds = this.febePrefs.getBoolPref("extensions.febe.playSounds");
	this.febeRunAsync = this.setAsyncMode();
	this.febeSaveResults = this.febePrefs.getBoolPref("extensions.febe.saveresultspage");
	this.febeStatusSave = this.febePrefs.getBoolPref("dom.disable_window_status_change");
	this.febeUseTimestampedDir = this.febePrefs.getBoolPref("extensions.febe.useTimestampedDir");
	this.febeVerifyBackups = this.febePrefs.getBoolPref("extensions.febe.verifyBackups");
	this.febeIncludeFEBEinBu = this.febePrefs.getBoolPref("extensions.febe.includefebe");
	
	// Create pointer to profile directory
	this.febeProfDir = Cc["@mozilla.org/file/directory_service;1"].getService(Ci.nsIProperties).get("ProfD", Ci.nsIFile);
	
	// Find FEBE install location
	// First look in profile/extensions
	this.febeInstallDirectory = null;
	let dir = this.febeProfDir.clone();
	dir.append("extensions");
	dir.append(this.FEBE_GUID);
	if(dir.exists()){
		this.febeInstallDirectory = dir;
	}else{
		// Not there, look in Fx install/browser/extensions
		dir = Cc["@mozilla.org/file/directory_service;1"].getService(Ci.nsIProperties).get("CurProcD", Ci.nsIFile);
		dir.append("extensions");
		dir.append(this.FEBE_GUID);
		if(dir.exists()){
			this.febeInstallDirectory = dir;
		}
	}
	if(!this.febeInstallDirectory) alert("Cannot find FEBE install location");
	febeDebug("Done executing febeGetPrefs()");
	return true;
},

febeGetAddonList: function (){
	febeDebug("Executing febeGetAddonList()");
  // Get all the information about the installed addons we need.  At this point, "febeAllAddons" should have been created (asnychronously) during onload
	let extDirList = {}, addonMgrList = {};
	let allAddons = FEBEstorage.getItem("febeAllAddons","");
	if(allAddons == ""){
		if(!FEBE.getSavedAddonData()){
			FEBE.febeError(this.febeMsg[523]);
			return false;
		}
	}
	
	// First get list of ignored addons
	this.febeSkippedList = {};
	this.febeDataFile = Cc["@mozilla.org/file/directory_service;1"].getService(Ci.nsIProperties).get("ProfD", Ci.nsIFile);
	this.febeDataFile.append(this.FEBEIGNORELISTDATAFILE);
	let item, id;
	if(this.febeDataFile.exists() && this.febeDataFile.fileSize > 0){
		let fis = Cc["@mozilla.org/network/file-input-stream;1"].createInstance(Ci.nsIFileInputStream);
		fis.init(this.febeDataFile, 0x01, 0x124, 0);
		fis.QueryInterface(Ci.nsILineInputStream);

		let cis = Cc["@mozilla.org/intl/converter-input-stream;1"].createInstance(Ci.nsIConverterInputStream);
		cis.init(fis,"UTF-8", 0, 0x0000);
		
		let lis = cis.QueryInterface(Ci.nsIUnicharLineInputStream);
		let line = {}, hasmore;	
		do {
			hasmore = lis.readLine(line);			
			item = new Object(JSON.parse(line.value));
			id = item.id;
			this.febeIgnoreList[id] = true;
		} while(hasmore);
		cis.close();
		fis.close();
	}else{
		// Create data file and add Fx default theme
		if(!this.febeDataFile.exists()){
			this.febeDataFile.create(Ci.nsIFile.NORMAL_FILE_TYPE, 0x1ED);	// 0x1ED = 0755, 0x1FF = 0777
		}
		let fos = Cc["@mozilla.org/network/file-output-stream;1"].createInstance(Ci.nsIFileOutputStream);
		fos.init(this.febeDataFile, 0x02 | 0x08 | 0x20, 0x1ED, 0); // write, create, truncate
		
		let cos = Cc["@mozilla.org/intl/converter-output-stream;1"].createInstance(Ci.nsIConverterOutputStream);
		cos.init(fos, "UTF-8", 0, 0x0000);

		item = {};
		id = "{972ce4c6-7e08-4474-a285-3208198ce6fd}";	// Firefox default theme
		item.id = id;
		item.name = this.febeMsg[419];
		this.febeSkippedList[id] = item;		
		let jstr = JSON.stringify(item);
		cos.writeString(jstr+"\n"); 
		cos.close();
		fos.close();
	}
	
	this.getStaged();
	
	let personas = [];
	let personasInstalled = [];
	let prefData = "";
	let types = ['extension','theme','plugin'];
	let color1 = ['blue','olive','purple'];
	let color2 = ['cornflowerblue','green','darkslateblue'];
	let extDir = Cc["@mozilla.org/file/directory_service;1"].getService(Ci.nsIProperties).get("ProfD", Ci.nsIFile);
	extDir.append("extensions");
	let prefName = "lightweightThemes.usedThemes";
	
	if(this.febePrefs.prefHasUserValue(prefName)){
		prefData = this.febeGetUnicharPref(prefName);
		personasInstalled = JSON.parse(prefData);
		for(let i in personasInstalled){
			try{
				let pId = personasInstalled[i].id + "@personas.mozilla.org";
				personas[pId] = new Object(personasInstalled[i]);
			}catch(e){;;}
		}
	}
	if(this.febeCheckAM == true){
		this.febeprt(this.febeMsg[409].replace('%DIR%',extDir.path),"black",0,1);
	}
	let itemIsXpi = {};
	
	let entries = extDir.directoryEntries;
	let cnt = 0;
	while(entries.hasMoreElements()){
		let entry = entries.getNext();
		entry.QueryInterface(Ci.nsIFile);
		item = {};
		let isProxy = false;
		item.isEligibleForBackup = true;
		let GUID;
		if(this.isFileExt(entry.leafName,".xpi")){	// Is item an xpi?
			GUID = entry.leafName.substr(0,entry.leafName.length-4)
			itemIsXpi[GUID] = true;
			item.isXpi = true;
		}else{
			GUID = entry.leafName;
			itemIsXpi[GUID] = false;
			item.isXpi = false;	
			if(!entry.isDirectory()){
				isProxy = true; // If it's not a directory or an .xpi, assume it is a proxy extension/plugin
				item.isEligibleForBackup = false;
			}
		}
		item.guid = GUID;
		item.name = entry.leafName;
		item.isValid = false;
		item.type = "unknown";
		item.installlocation = entry.path;
		item.isProxy = isProxy;

		if(this.febeCheckAM == true){
			this.febeprt("guid: "+item.guid,"brown");
			this.febeprt("isXpi: "+item.isXpi,"chocolate");
			this.febeprt("isProxy: "+item.isProxy,"chocolate");
			this.febeprt("installlocation: "+item.installlocation,"chocolate",0,1);
			extDirList[item.guid] = item.guid;
		}
		cnt++;
		this.febeAddons[GUID] = item;

	}
	if(this.febeCheckAM == true){
		this.febeprt("*** "+this.febeMsg[497]+" "+cnt,"black",0,1);
	}
	
	// Get info for all items
	this.febeCheckForGlobalExtensions();
	if(this.febeCheckAM == true){this.febeprt(this.febeMsg[408],"black");}
	cnt = {};
	this.febePendingCount = 0;
	for(let i in allAddons){
		let addon = allAddons[i];
		try{
			this.febeExtBuName = this.getBuName(addon.name);
			let febeExtExt = ".xpi";
			let isPersona = false;
			if(addon.type == "theme"){
				let id = addon.id;
				if(!!personas[id]){
					febeExtExt = ".persona.json";
					this.febeExtBuName += febeExtExt;
					isPersona = true;
				}else{
					febeExtExt = ".jar";
					this.febeExtBuName += "{" + addon.version + "}"+febeExtExt;
				}
			}else{
				this.febeExtBuName += "{" + addon.version + "}"+febeExtExt;
			}
			item = {};
			item.guid = addon.id;
			item.type = addon.type;
			item.name = addon.name;
			item.version = addon.version;
			item.buname = this.febeExtBuName;
			item.desc = addon.description;
			item.homepageURL = addon.homepageURL;
			item.userDisabled = addon.userDisabled;
			item.isCompatible = addon.isCompatible;
			item.isEligibleForBackup = true;
			item.iconURL = this.febeIconToDataURL(addon.iconURL,"chrome://febe/skin/xpinstallItemGeneric.png");
			if(item.type == "theme"){
				item.iconURL64 = this.febeIconToDataURL(addon.icon64URL,"chrome://febe/skin/defaultThemeIcon64x64.png");
			}else{
				item.iconURL64 = this.febeIconToDataURL(addon.icon64URL,"chrome://febe/skin/defaultExtIcon64x64.png");
			}
			item.isXpi = itemIsXpi[addon.id];
			let isProxy = false;
			let file = extDir.clone();
			if(item.isXpi == true){
				file.append(item.guid+".xpi");
			}else{
				file.append(item.guid);
				if(file.exists() && !file.isDirectory()){
					isProxy = true;
					item.isEligibleForBackup = false;
				}
			}
			item.installlocation = file.path;
			item.isProxy = isProxy;
			item.ignore = false;
			if(typeof this.febeIgnoreList[addon.id] != 'undefined'){
				if(this.febeIgnoreList[addon.id] == true){
					item.ignore = true;	
					item.isEligibleForBackup = false;
					this.febeSkippedList[addon.id] = item;
				}else{
					item.ignore = false;
				}
			}
			item.isPlugin = false;
			if(item.type == "plugin"){
				item.ignore = true;	
				item.isPlugin = true;
				item.isXpi = false;
				item.isEligibleForBackup = false;
			}
			if(item.isProxy){
				item.isXpi = false;
				item.isEligibleForBackup = false;
				this.febeSkippedList[addon.id] = item;
			}
			item.isPending = false;
			if(addon.pendingUpgrade){
				item.isPending = true;
				item.isEligibleForBackup = false;
				this.febeSkippedList[addon.id] = item;
				this.febePendingCount++;
			}
			item.isValid = true;
			item.isPersona = isPersona;
			item.size = addon.size;
			item.installDate = addon.installDate;
			item.updateDate = addon.updateDate;
			item.creator = addon.creator;
			item.id = addon.id;
			item.isGlobal = false;
			item.rating = addon.averageRating;
			if(this.febeGlobalList[addon.id]){
				item.isGlobal = true;
				item.isEligibleForBackup = false;
				this.febeSkippedList[addon.id] = item;
			}
			
			let status = ((item.userDisabled) ? this.febeMsg[414] : this.febeMsg[413]);
			if(!item.isEligibleForBackup){
				if(item.isGlobal) status += ", "+this.febeMsg[420];
				if(item.ignore) status += ", "+this.febeMsg[421];
				if(item.isPending) status += ", "+this.febeMsg[422];
				if(item.isProxy) status += ", "+this.febeMsg[423];
				let mdash = " "+String.fromCharCode(8212)+" ";
				status += mdash+this.febeMsg[424];
			}
			item.status = status;
			item.tooltipdata = this.febeTooltipData(item);
			this.febeAddons[addon.id] = item;

			if(this.febeCheckAM == true){
				let type = types.indexOf(item.type);
				this.febeprt("");
				this.febeprt("name: "+item.name+"  ("+item.type+")",color1[type]);
				let itemList = [];
				for(let i in item) itemList.push(i);
				itemList.sort();
				for(let i=0; i<itemList.length; i++){
					let prop = itemList[i];
					if(prop =='name') continue;
					if(prop =='type') continue;
					if(prop == 'tooltip') continue;
					if(prop == 'iconURL') continue;
					if(prop == 'iconURL64') continue;
					let tmp = "--> "+prop+": "+item[prop];
					this.febeprt(tmp,color2[type]);
				}
				if(item.type != "plugin" && !item.isPersona) addonMgrList[item.guid] = item.guid;
			}
		}catch(err){
			let tmp = this.febeExtBuName;
			if(this.febeCheckAM == true){
				this.febeprt("");
				this.febeprt(this.febeMsg[4],"red");
				this.febeprt(tmp+e,"red",0,1);
				this.febeprt("");
			}
		}
		if(!cnt[item.type]) cnt[item.type] = 0;
		if(!cnt.global) cnt.global = 0;
		cnt[item.type]++;;
		if(item.isGlobal) cnt.global++;
	}
	
	if(this.febeCheckAM == true){
		this.febeprt("");
		this.febeprt("*** "+this.febeMsg[399].replace("%CNT%",cnt['extension']),"black");
		this.febeprt("*** "+this.febeMsg[398].replace("%CNT%",cnt['theme']),"black");
		this.febeprt("*** "+this.febeMsg[400].replace("%CNT%",cnt['plugin']),"black");
		this.febeprt(this.febeMsg[394].replace("%CNT%",cnt['global']),"black");
		
		// Check for discrepancies
		for(let i in extDirList){	// listed in ext directory but not in AM
			let tmp = this.febeMsg[395].replace("%GUID%",i);
			if(!addonMgrList[i]) this.febeprt(tmp,"red",0,1);
		}
		this.febeprt("");
		for(let i in addonMgrList){	// listed in AM but not in ext directory
			if(this.febeGlobalList[i]) continue;
			let tmp = this.febeMsg[396].replace("%GUID%",i);
			if(!extDirList[i]) this.febeprt(tmp,"red",0,1);
		}
	}
	
	FEBEstorage.setItem("febeAddons",this.febeAddons);
	febeDebug("Done executing febeGetAddonList()");
	return true;
},

getBuName: function(name){
	// Remove spaces and undesirable characters from extension name
	let tmp = "";
	let mask = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
	mask += ".+-_";
	for (let j = 0; j <= name.length; j++){
		let c = name.charAt(j);
		if( mask.indexOf(c) != -1 ){tmp += c};
	}
	return tmp;
},

getStaged: function(){
	let stagedDir = Cc["@mozilla.org/file/directory_service;1"].getService(Ci.nsIProperties).get("ProfD", Ci.nsIFile);
	stagedDir.append("extensions");
	stagedDir.append("staged");
	if(!stagedDir.exists()) return true;
	
	let entries = stagedDir.directoryEntries;
	let cnt = 0;
	while(entries.hasMoreElements()){
		let entry = entries.getNext();
		entry.QueryInterface(Ci.nsIFile);
		if(entry.isDirectory()) continue;
		if(this.isFileExt(entry.leafName,".json")){	// Pending item info file
			let pItem = this.getJSONobject(entry.path);
			let id = pItem.id;
			let item = {};
			item.id = id;
			item.name = this.getBuName(pItem.defaultLocale.name);
			item.version = pItem.version;
			item.homepageURL = pItem.defaultLocale.homepageURL;
			item.iconURL64 = "chrome://febe/skin/defaultExtIcon64x64.png";
			item.creator = pItem.defaultLocale.creator;
			item.size = pItem.size
			item.iconURL = "chrome://febe/skin/xpinstallItemGeneric.png";
			item.desc = pItem.defaultLocale.description;
			item.isPending = true;
			item.isEligibleForBackup = false;
			item.updateDate = new Date(pItem.installDate);
			let status = this.febeMsg[413]+", "+this.febeMsg[422];
			let mdash = " "+String.fromCharCode(8212)+" ";
			status += mdash+this.febeMsg[424];
			item.status = status;
			item.tooltipdata = this.febeTooltipData(item);
			this.febeSkippedList[id] = item;		
			this.febePendingCount++;
		}
	}
},

isFileExt: function(fName,ext){
	// Does fName end with the file extension ext?
	// Examples: 
	// isFileExt("{4BBDD651-70CF-4821-84F8-2B918CF89CA3}.json",".json") returns true
	// isFileExt("{4BBDD651-70CF-4821-84F8-2B918CF89CA3}.json",".xpi") returns false
	let p = fName.lastIndexOf(ext);	
	//if(p == -1) return false;
	let fl = fName.length;
	let el = ext.length;
	if(fl - el != p) return false;
	return true;
},

getJSONobject: function(fName){
	// Get the first/only JSON object in fName and return it
	let file = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
	file.initWithPath(fName);
	if(!file.exists() || file.isDirectory()) return false;
	let fis = Cc["@mozilla.org/network/file-input-stream;1"].createInstance(Ci.nsIFileInputStream);
	fis.init(file, 0x01, 0x124, 0);
	fis.QueryInterface(Ci.nsILineInputStream);

	let cis = Cc["@mozilla.org/intl/converter-input-stream;1"].createInstance(Ci.nsIConverterInputStream);
	cis.init(fis,"UTF-8", 0, 0x0000);
	
	let lis = cis.QueryInterface(Ci.nsIUnicharLineInputStream);
	let line = {}, hasmore, item;	
	do {
		hasmore = lis.readLine(line);			
		item = new Object(JSON.parse(line.value));
		break;
	} while(hasmore);
	cis.close();
	fis.close();
	return item;
},

febeCheckForGlobalExtensions: function (){
  // Check for global extensions
	this.febeGlobalList = {};
	let febeGlobalExtDir = Cc["@mozilla.org/file/directory_service;1"].getService(Ci.nsIProperties).get("CurProcD", Ci.nsIFile);
	febeGlobalExtDir.append("extensions");
	if(febeGlobalExtDir.exists()){
		let entries = febeGlobalExtDir.directoryEntries;
		let id;
		while(entries.hasMoreElements()){
			let entry = entries.getNext();
			entry.QueryInterface(Ci.nsIFile);
			if(entry.isDirectory()){
				id = entry.leafName;
			}else{
				id = "";
				let isXpi = entry.leafName.match(/^(.+)\.xpi$/i);
				if(isXpi) id = isXpi[1];
				let isJar = entry.leafName.match(/^(.+)\.jar$/i);
				if(isJar) id = isJar[1];
			}
			this.febeGlobalList[id] = true;
		}
	}
	return true;
},

febeTooltipData: function (ext){
//makeTT(event,iconData,authorLabel,authorDesc,idLabel,idDesc,sizeLabel,sizeDesc,installdateLabel,installdateDesc,statusLabel,statusDesc)
//makeTT(event,'chrome://febe/skin/defaultThemeIcon64x64.png','Author:','Shamanski Designs','ID:','38241@personas.mozilla.org','Size (installed):','(unknown)','Last Install Date:','(unknown)','Status:','Disabled')

	let tooltipdata = {};
	tooltipdata.name = ext.name;
	tooltipdata.icon = ext.iconURL64;
	
	tooltipdata.author = {};
	tooltipdata.author.label = this.febeMsg[356];
	if(ext.creator){
		tooltipdata.author.name = ext.creator.name;
	}else{
		tooltipdata.author.name = "("+this.febeMsg[267]+")";
	}
	
	tooltipdata.id = {};
	tooltipdata.id.label = this.febeMsg[357];
	tooltipdata.id.guid = ext.id;
	
	tooltipdata.size = {};
	tooltipdata.size.label = this.febeMsg[358];
	let size = ext.size;
	let units = " bytes";
	if(size > 1024){
		size = size / 1024;
		units = " KB";
	}
	if(size > 1024){
		size = size / 1024;
		units = " MB";
	}
	size = Math.round(size);
	if(size == 0){
		size = "("+this.febeMsg[267]+")";
		units = "";
	}
	tooltipdata.size.data = size+units;
	
	tooltipdata.installDate = {};
	tooltipdata.installDate.label = this.febeMsg[359];
	let installdate = ext.updateDate;
	if(installdate == null){
		installdate = "("+this.febeMsg[267]+")";
	}
	tooltipdata.installDate.date = installdate;
	
	tooltipdata.status = {};
	tooltipdata.status.label = this.febeMsg[189];
	tooltipdata.status.text = ext.status;

	tooltipdata.rating = {};
	tooltipdata.rating.label = this.febeMsg[547];
	tooltipdata.rating.value = ext.rating;

	let retValue = encodeURI(JSON.stringify(tooltipdata));
	return retValue;
},

febeIconToDataURL: function (iconURL,defaultimg){
	// Convert icon URL to data url	
	let retValue = "";
	try{
		let ioserv = Cc["@mozilla.org/network/io-service;1"].getService(Ci.nsIIOService); 
		let channel = ioserv.newChannel(iconURL, 0, null); 
		let stream = channel.open(); 

		if (channel instanceof Ci.nsIHttpChannel && channel.responseStatus != 200) {
			retValue =  defaultimg; 
		}else{
			let bstream = Cc["@mozilla.org/binaryinputstream;1"].createInstance(Ci.nsIBinaryInputStream); 
			bstream.setInputStream(stream); 

			let size = 0; 
			let file_data = ""; 
			while(size = bstream.available()) { 
				file_data += bstream.readBytes(size); 
			}
			let data = btoa(file_data);
			retValue = "data:image;base64,"+data;
		}
	}catch(e){
		retValue = defaultimg;
	}
	return retValue;
},

febeGetBuType: function (){
	if(typeof FEBE.febeMsg[0] === 'undefined') FEBE.febeSetMsgs();
	FEBE.febeBUtype = FEBE.febePrefs.getCharPref("extensions.febe.buType");
	let selective = FEBE.febeMsg[269];
	let profile = FEBE.febeMsg[270];
	let alternate = FEBE.febeMsg[271];
	let both = FEBE.febeMsg[272];
	let txt, type, lastbutype;
	switch(FEBE.febeBUtype){
		case "selective":
			FEBE.febeBuProfile = false;
			txt = selective;
			break;
		case "profile":
			FEBE.febeBuProfile = true;
			txt = profile;
			break;
		case "alternate":
			lastbutype = FEBE.febePrefs.getCharPref("extensions.febe.lastbackup.type");
			FEBE.febeBuProfile = false;
			if(lastbutype == "selective"){FEBE.febeBuProfile = true;}
			if(FEBE.febeBuProfile == true){
				type = profile;
			}else{
				type = selective;
			}
			txt = alternate +" ("+type+")";
			break;
		case "both":
			FEBE.febeBuProfile = false;
			txt = both + "  ("+selective+" & "+profile+")";
			break;
	}
	FEBE.febeSetUnicharPref("extensions.febe.lastbackup.type.desc",txt);
	FEBE.febeSetUnicharPref("extensions.febe.currentbackup.type",txt);
	febeDebug("Executing febeGetBuType() - FEBE.febeBUtype: "+FEBE.febeBUtype);
	return txt;
},

febeBuInProgress: function (){
	return this.febePrefs.getBoolPref("extensions.febe.backupInProgress");
},

febeBuInProgressCheck: function (){
	FEBE.setStyles();
	let style = FEBE.febeStyle.orangeredBold;
	let tmp = style+this.febeMsg[229]+"\n\n"
	style = FEBE.febeStyle.black12;
	tmp += style+this.febeMsg[230]+"\n\n";
	style = FEBE.febeStyle.purple12;
	tmp += style+this.febeMsg[231];
	if(!FEBE.febeConfirm(tmp)){
		this.febePrefs.setBoolPref("extensions.febe.backupInProgress",false);
		return false;
	}
	return true;
},

febeAbort: function (){
  // 'Abort' button pressed
	this.febePrefs.setBoolPref("extensions.febe.backupInProgress",false);
	window.close();
	this.febeAlert(this.febeMsg[351]);
	this.febeBackupAborted = true;
	return false;
},

febeInitPref: function (prefName, dflt){	// Needed?
  // Set a preference to default if needed
	if(!this.febePrefs.prefHasUserValue(prefName)){		
		this.febeSetUnicharPref(prefName,dflt);
	}else if(this.febeGetUnicharPref(prefName) == ""){
		this.febeSetUnicharPref(prefName,dflt);
	}
	return true;
},

// Object declarations
febeExtObj: function (Name, Type, Version, Path, Icon, Home, Guid, Verified, Include, isDisabled, Minversion, Maxversion){
	this.Name = new String(Name);
	this.Type = new Number(Type);
	this.Version = new String(Version);
	this.Path = new String(Path); 
	this.Icon = new String(Icon); 
	this.Home = new String(Home); 
	this.Guid = new String(Guid); 
	this.Verified = Boolean(Verified);
	this.Include = Boolean(Include);
	this.isDisabled = Boolean(isDisabled);
	this.Minversion = new String(Minversion); 
	this.Maxversion = new String(Maxversion); 
	return true;
},

febeUDBuDoneObj: function (Description, Name){
	this.Description = Description;
	this.Name = Name;
	return true;
},

febeSetTimeoutObj: function (PID,Process,Started,Wait){
	this.PID = PID;
	this.Process = Process;
	this.Started = Started;
	this.Wait = Wait;
	return true;
},

febeCookieObj: function (expires, host, isDomain, isSecure, name, path, policy, status, value){
	this.expires = expires;
	this.host = host;
	this.isDomain = isDomain;
	this.isSecure = isSecure;
	this.name = name;
	this.path = path;
	this.policy = policy;
	this.status = status;
	this.value = value;
},

febePrefObj: function (Name, Type, Value){	// Needed?
	this.Name = Name;
	this.Type = Type;
	this.Value = Value;
},

febeGetPlatform: function (){
	let platform = navigator.platform.toLowerCase();
	this.febePlatform = 2;	// Default to *nix since there are so many different flavors
	if(platform.indexOf("win") != -1){this.febePlatform = 1;}
	if(platform.indexOf("linux") != -1){this.febePlatform = 2;}
	if(platform.indexOf("unix") != -1){this.febePlatform = 2;}
	if(platform.indexOf("sunos") != -1){this.febePlatform = 2;}
	if(platform.indexOf("darwin") != -1){this.febePlatform = 3;}
	if(platform.indexOf("macintel") != -1){this.febePlatform = 3;}
	if(platform.indexOf("macppc") != -1){this.febePlatform = 3;}
	febeDebug("Executing febeGetPlatform() - febePlatform: "+this.febePlatform);
	return this.febePlatform;
},

febeGetVersion: function() {
	let ver = "";;
	try{
		ver = this.febePrefs.getCharPref("extensions.febe.currentversion");
	}catch(e){
		ver="0.0";
	}
	febeDebug("Executing febeGetVersion() - ver: "+ver);
	return ver;
},

febeCheckIfNewInstall: function(){
	febeDebug("Executing febeCheckIfNewInstall()");
	AddonManager.getAddonByID(FEBE.FEBE_GUID, function(addon){
		let version = addon.version;
		FEBE.febePrefs.setCharPref("extensions.febe.currentversion",version);
		let newFEBEinstall = false;
		let prefName = "extensions.febe.previousversion";
		if(FEBE.febePrefs.prefHasUserValue(prefName)){
			let pversion = FEBE.febePrefs.getCharPref(prefName);
			if (pversion != version){newFEBEinstall = true;}
		}else{
			newFEBEinstall = true;
		}
		FEBE.febePrefs.setCharPref(prefName,version);
		febeDebug("newFEBEinstall? "+newFEBEinstall);
		if(newFEBEinstall == true){
			FEBE.febeWelcomePage = "http://softwarebychuck.com/febe/Welcome%20pages/FEBE8welcome.html";
			setTimeout(function(){FEBE.febeWelcomePageDisplay();},1500);	// Let the browser catch up
		}
	});
	febeDebug("Done executing febeCheckIfNewInstall()");
	return true;
},

febeSetVersion: function (){
	this.febeSetMsgs();
	let febeVer = this.febeGetVersion();
	if(document.getElementById("febeVersionDispID")){
		document.getElementById("febeVersionDispID").value = febeVer;
	}
	if(document.getElementById("febeVersionID")){
		let ver = document.getElementById("febeVersionID").value;
		document.getElementById("febeVersionID").value = ver.replace('%VER%',febeVer);
	}

	if(document.getElementById("febeFxVersionDispID")){
		document.getElementById("febeFxVersionDispID").value = FEBE.fxVer;
	}
	if(document.getElementById("febeCurrentProfileTextID")){
		let size = this.getProfileDirSize();
		size = "  ("+size+" MB)"
		document.getElementById("febeCurrentProfileTextID").value = this.febeProfileName() + size;
	}
	return true;
},

febeValidateMaxDirs: function (){	// Needed?
	let maxDirs = document.getElementById("maxBuDirsID").value;
	if(isNaN(maxDirs)){
		let w = this.window;
		this.febeAlert(this.febeMsg[101]);
		w.focus();
		document.getElementById("maxBuDirsID").focus();
		document.getElementById("maxBuDirsID").select();
		return false;
	}
	document.getElementById("maxBuDirsID").value = parseInt(maxDirs);
	return true;
},

febeOpenLink: function (URL){
	if(!URL){return false;}
	let wm = Cc["@mozilla.org/appshell/window-mediator;1"].getService(Ci.nsIWindowMediator);
	let win = wm.getMostRecentWindow("navigator:browser");
	let currBlank = false;
	try{
		let febeGetBrowser = win.getBrowser();
		let loc = febeGetBrowser.mCurrentTab.linkedBrowser.contentDocument.location;
		if(loc == "about:blank") currBlank = true;
		if(loc == "about:newtab") currBlank = true;
		if(febeGetBrowser.mCurrentTab.label == "(Untitled)") currBlank = true;
	}catch(e){;;}
	if(currBlank){
		win.loadURI(URL);
	}else{
		win.openNewTabWith(URL, this.docURL, null, null);
  }
  return win;
},

febeOpenResultsPage: function (URL){
	if(!URL){return false;}
	if(!FEBE.febeControllerWindow) FEBE.febeScheduleController();
	FEBE.febeControllerWindow.openNewTabWith(URL, this.docURL, null, null);
	return true;
},

febeHideHelpIcons: function (){
	this.febeHideHelp = this.febePrefs.getBoolPref('extensions.febe.hidehelp');
	let helpIcons = document.getElementsByClassName('helpButton');
	for(let i=0; i<helpIcons.length; i++){
		let item = document.getElementById(helpIcons[i].id);
		if(item) item.style.visibility = (this.febeHideHelp ? "hidden" : "visible");
	}
	return true;
},	

febeOptions: function (){
	FEBE.setStyles();
	if(!this.febeIsScheduleController){
		let tmp = FEBE.febeStyle.orangeredBold+this.febeMsg[526]+"\n";
		tmp += FEBE.febeStyle.blackMargin+this.febeMsg[527]+"\n";
		tmp += FEBE.febeStyle.blackMargin+this.febeMsg[528]+"\n";
		FEBE.febeConfirmAsk2(tmp);
		return true;
	};
	FEBE.febeWin = FEBE.febeControllerWindow.openDialog('chrome://febe/content/settings/febeOptions.xul', 'FEBE Options', 'chrome,titlebar,toolbar,centerscreen,resizable');	
	FEBE.febeControllerWindow.focus();
	FEBE.febeWin.focus();	
	return true;
},

febeSwitchToControllingWindowLoad: function(){
	let d = document.getElementById('switchnow');
	let checked = FEBE.febePrefs.getBoolPref("extensions.febe.switchToController");
	d.setAttribute('checked', checked);
	return true;
},

febeSwitchToControllingWindowCheck: function(elm){
	let checked = elm.checked;
	this.febePrefs.setBoolPref("extensions.febe.switchToController", checked);
	return true;
},

febeSwitchToControllingWindow: function(){
	let checked = this.febePrefs.getBoolPref("extensions.febe.switchToController");
	if(checked){
		FEBE.febeScheduleController();
		FEBE.febeControllerWindow.FEBE.febeOptions();
		FEBE.febeControllerWindow.focus();
	}
	return true;
},

febeHelp: function (helpIndex,fieldName){
	let opts = this.febeSetWinOpts(false);
	this.febeWin = window.openDialog('chrome://febe/content/febeHelp.xul', 'FEBE Help', opts,helpIndex,fieldName);
	this.febeWin.focus();
	return true;
},

febeAlert: function (message,modal){
	FEBE.logMsg(message);
	let opts = this.febeSetWinOpts(modal);
	this.febeWin = window.openDialog('chrome://febe/content/febeAlert.xul','FEBE Alert',opts,message);	
	this.febeWin.focus();
	return true;
},

febeSetWinOpts: function(modal){
	//modal = false;		// As of Fx 36 some windows are hidden behind the browser so never use modal
	let opts = "chrome,dialog,alwaysRaised,resizable";
	if(modal){opts += ",modal";}
	let febeMsgType = this.febePrefs.getCharPref('extensions.febe.alertType');
	if(febeMsgType == 'slider'){opts += ",popup";}
	if(febeMsgType == 'standard'){opts += ",centerscreen,titlebar";}
	
  // Always use standard alert windows when in debug mode
	FEBE.debug = this.febePrefs.getBoolPref("extensions.febe.debugMode");
	if(FEBE.debug){opts = "chrome,dialog,alwaysRaised,resizable,centerscreen,titlebar,modal";}
	return opts;
},

febeConfirm: function(message){
	FEBE.setStyles();
	let opts = this.febeSetWinOpts(true);
	let wm = Cc["@mozilla.org/appshell/window-mediator;1"].getService(Ci.nsIWindowMediator);  
	this.febeMainWindow = wm.getMostRecentWindow("navigator:browser"); 
	this.febeWin = this.febeMainWindow.openDialog('chrome://febe/content/febeConfirm.xul', 'FEBE Confirm', opts,message);	
	this.febeWin.focus();
	return this.febePrefs.getBoolPref('extensions.febe.confirm');
},

febeConfirmAsk: function (message){
	FEBE.setStyles();
	let opts = this.febeSetWinOpts(true);
	this.febeWin = window.openDialog('chrome://febe/content/febeConfirmAsk.xul', 'FEBE Confirm', opts ,message);	
	this.febeWin.focus();
	return this.febePrefs.getBoolPref('extensions.febe.confirm');
},

febeConfirmAsk2: function (message){
	FEBE.setStyles();
	let opts = this.febeSetWinOpts(true);
	this.febeWin = window.openDialog('chrome://febe/content/febeConfirmAsk2.xul', 'FEBE Confirm', opts ,message);	
	this.febeWin.focus();
	return true;
},

febeError: function (message){
	let opts = this.febeSetWinOpts(true);
	this.febeWin = window.openDialog('chrome://febe/content/febeError.xul', 'FEBE Error', opts,message);
	this.febeWin.focus();	
	return true;
},

febeCantFind: function (message){
	let opts = this.febeSetWinOpts(true);
	this.febeWin = window.openDialog('chrome://febe/content/febeIgnoreAdd.xul', 'FEBE Ignore',opts,message,FEBE.febex);	
	this.febeWin.focus();
	return this.febePrefs.getBoolPref('extensions.febe.confirm');
},

febeConfirmOK: function (){
	this.febePrefs.setBoolPref('extensions.febe.confirm',true);
	return true;
},

febeConfirmCancel: function (){
	this.febePrefs.setBoolPref('extensions.febe.confirm',false);
	return true;
},

febeSetAlertMsg: function (){
	// If the message contains a style or class, it must be the first part of the message 
	// (one style per line, if needed).  
	// If a class is assigned, it must be in the form of: <class>classname</class>
	let tmp = window.arguments[0]+"   \n\n";
	let lines = tmp.split(/\n/); // Break it into an array
	let msg = [], re, a;
	let separator = document.createElement('separator');
	for(let i=0;i<lines.length;i++){	
		let line = lines[i];
		let item = {};
		item.Style = "font-family: arial; font-size: 10pt; font-weight: normal; color: purple";
		item.Text = line;

		// Parse for links
		let link = line.indexOf("<link>");
		if(link == 0){
			re = /(<link>)(.*),(.*)(<\/link>)/g
			a = re.exec(line);
			item.Text = a[2];
			item.Link = a[3];
			item.Klass = "link";	
			msg[i] = item;
			continue;
		}
		
		// Parse for styles
		let style = line.indexOf("<style>");
		if(style == 0){
			re = /(<style>)(.*)(<\/style>)(.*)/g
			a = re.exec(line);
			item.Style = a[2];
			item.Text = a[4];
			msg[i] = item;
			continue;
		}
		
		// Parse for class
		let klass = line.indexOf("<class>");
		if(klass == 0){
			re = /(<class>)(.*)(<\/class>)(.*)/g
			a = re.exec(line);
			item.Klass = a[2];
			item.Text = a[4];
			msg[i] = item;
			continue;
		}
		
		msg[i] = item;
	}
	this.febeClipboard = [];
	let msgBox = document.getElementById("febeMsgBox");
	if(msgBox){
		for(let i=0; i<msg.length; i++){
			if(msg[i].Text == ""){
				msgBox.appendChild(separator.cloneNode(false));
				this.febeClipboard.push(msg[i].Text);
				continue;
			}
			let desc = document.createElement('description');
			desc.setAttribute("style",msg[i].Style);
			if(msg[i].Klass){
				desc.removeAttribute("style");
				desc.setAttribute("class",msg[i].Klass);
				if(msg[i].Klass == "link"){
					let txt = document.createElement('text');
					txt.setAttribute("value",msg[i].Text);
					txt.removeAttribute("onclick");
					clickify(txt, msg[i].Link);
					desc.appendChild(txt);
				}else{
					desc.textContent = msg[i].Text;			
				}
			}else{
				desc.textContent = msg[i].Text;			
			}
			msgBox.appendChild(desc);
			this.febeClipboard.push(msg[i].Text);
		}
		try{
			document.documentElement.getButton("cancel").focus();
		}catch(err){;;}
	}
	this.febePlaySound('message');
	
	function clickify(elem, address) {
    elem.setAttribute('href', address);
		elem.onclick = function(event){FEBE.febeOpenLink(this.getAttribute('href'))};
		return true;
	}
	return true;
},

febeSliderLoad: function (noSlide){
	let febeMsgType = this.febePrefs.getCharPref('extensions.febe.alertType');
	
	// 'noSlide' is for resizable windows opened with window.openDialog()
	if(typeof noSlide == 'undefined') noSlide = false;
	if(noSlide) febeMsgType = "standard";
	sizeToContent();
	let finalHeight = window.outerHeight;
	let windowtype = document.documentElement.getAttribute("windowtype");

	if(febeMsgType == 'slider'){
		var sliderIncrement = 10;		// Amount the slider grows by (pixels)
		var sliderTime = 25;				// Time between increments (milliseconds)
		window.outerHeight = 1;			// First shrink the window down
		let x =(screen.availLeft + screen.availWidth - window.outerWidth) - 10;
		if(windowtype == 'febe:help') x=0;	// Help screens popup on the left
		let y = screen.availTop + screen.availHeight - window.outerHeight;
		window.moveTo(x,y);
		window.focus();
		setTimeout(function(){animateAlert();}, sliderTime);
	}
	function animateAlert(){
		if(window.outerHeight < finalHeight){
			window.screenY -= sliderIncrement;
			window.outerHeight += sliderIncrement;
			setTimeout(function(){animateAlert()}, sliderTime);
			return true;
		}
	}
	
	// On windows that don't have a 'Copy to clipboard' button, the button label will be blank
	let copy2clipboardBtn = document.documentElement.getButton("extra1");
	let copy2clipboard = FEBE.febePrefs.getBoolPref("extensions.febe.copyToClipboard");
	copy2clipboardBtn.hidden = (!copy2clipboard || (copy2clipboardBtn.label == ""));
	try{
		document.documentElement.getButton("cancel").focus();
	}catch(err){;;}
	return true;
},

alertExample:	function(){
	let febeMsgType = this.febePrefs.getCharPref('extensions.febe.alertType');
	let tmp;
	if(febeMsgType == 'standard'){
		tmp = this.febeMsg[494];
	}else{
		tmp = this.febeMsg[495];
	}
	this.febeAlert(tmp,false);
	return true;
},

febeCopyToClipboard: function (){
  // Copy the contents of a febeAlert, febeConfirm, or febeError box to the system clipboard
	let gClipboardHelper = Cc["@mozilla.org/widget/clipboardhelper;1"].getService(Ci.nsIClipboardHelper);
	gClipboardHelper.copyString(this.febeClipboard.join("\n"));
	this.febeClipboard = [];
	this.febePlaySound('success');
	return true;
},

febePlaySound: function (which){
	FEBE.febeGetPrefs();
	FEBE.febeHandleSounds();
	if(!FEBE.febePlaySounds) return true;
	let soundURL = FEBE.febePlaySoundsURI[which];	
	let audio = new Audio(soundURL); 
	audio.play();
	return true;
},

febePlaySoundHelp: function (which){
  // Alway play sounds in the "Play sounds" help window
	FEBE.febeGetPrefs();
	let soundURL = FEBE.febePlaySoundsURI[which];	
	let audio = new Audio(soundURL); 
	audio.play();
	return true;
},

febeHandleSounds: function (){
	let opt, uri;
	FEBE.febePlaySounds = FEBE.febePrefs.getBoolPref("extensions.febe.playSounds");
	FEBE.febePlaySoundsURI['busuccess'] = "chrome://febe/content/sounds/busuccess.ogg";
	opt = FEBE.febeGetUnicharPref("extensions.febe.sounds.useBuSuccessSoundType");
	uri = FEBE.febeGetUnicharPref("extensions.febe.sounds.useBuSuccessSoundLocation");
	if(opt == "custom"){FEBE.febePlaySoundsURI['busuccess'] = "file://"+uri;}
	
	FEBE.febePlaySoundsURI['bufailure'] = "chrome://febe/content/sounds/bufailure.ogg";
	opt = FEBE.febeGetUnicharPref("extensions.febe.sounds.useBuFailureSoundType");
	uri = FEBE.febeGetUnicharPref("extensions.febe.sounds.useBuFailureSoundLocation");
	if(opt == "custom"){FEBE.febePlaySoundsURI['bufailure'] = "file://"+uri;}
	
	FEBE.febePlaySoundsURI['warning'] = "chrome://febe/content/sounds/warning.ogg";
	opt = FEBE.febeGetUnicharPref("extensions.febe.sounds.useWarningSoundType");
	uri = FEBE.febeGetUnicharPref("extensions.febe.sounds.useWarningSoundLocation");
	if(opt == "custom"){FEBE.febePlaySoundsURI['warning'] = "file://"+uri;}
	
	FEBE.febePlaySoundsURI['message'] = "chrome://febe/content/sounds/alert.ogg";
	opt = FEBE.febeGetUnicharPref("extensions.febe.sounds.useMessageSoundType");
	uri = FEBE.febeGetUnicharPref("extensions.febe.sounds.useMessageSoundLocation");
	if(opt == "custom"){FEBE.febePlaySoundsURI['message'] = "file://"+uri;}
	
	FEBE.febePlaySoundsURI['help'] = "chrome://febe/content/sounds/help.ogg";
	opt = FEBE.febeGetUnicharPref("extensions.febe.sounds.useHelpSoundType");
	uri = FEBE.febeGetUnicharPref("extensions.febe.sounds.useHelpSoundLocation");
	if(opt == "custom"){FEBE.febePlaySoundsURI['help'] = "file://"+uri;}
	
	FEBE.febePlaySoundsURI['success'] = "chrome://febe/content/sounds/success.ogg";
	opt = FEBE.febeGetUnicharPref("extensions.febe.sounds.useSuccessSoundType");
	uri = FEBE.febeGetUnicharPref("extensions.febe.sounds.useSuccessSoundLocation");
	if(opt == "custom"){FEBE.febePlaySoundsURI['success'] = "file://"+uri;}
	
	FEBE.febePlaySoundsURI['failure'] = "chrome://febe/content/sounds/failure.ogg";
	opt = FEBE.febeGetUnicharPref("extensions.febe.sounds.useFailureSoundType");
	uri = FEBE.febeGetUnicharPref("extensions.febe.sounds.useFailureSoundLocation");
	if(opt == "custom"){FEBE.febePlaySoundsURI['failure'] = "file://"+uri;}

	return true;
},

febeParent: function (pathname){
  // Return the parent of pathname.  Ex:
  // If pathname is "C:\Documents and Settings\Owner\My Documents\some dir",
  // the will: function (return "C:\Documents and Settings\Owner\My Documents"
  
	let file = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
	file.initWithPath(pathname);
	return file.parent.path;
},

febeLeafname: function (pathname){
  // Return the leafname of pathname.  Ex:
  // If pathname is "C:\Documents and Settings\Owner\My Documents\some dir",
  // the will: function (return "some dir"
  
	let file = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
	file.initWithPath(pathname);
	return file.leafName;
},

febePause: function (millis){
  // Pause for (millis) milliseconds
	let date = new Date();
	let curDate = null;
	
	do {curDate = new Date();}
		while(curDate-date < millis);
	return true;
}, 

febeWrap: function (str,len){	
  // Return a string wrapped at len characters max per line
	str = str.toString();
	let tmpA = str.split(" ");
	let returnVal="";
	let tmp = "";
	let skip = false;
	for(let i = 0; i < tmpA.length; i++){
		tmp += tmpA[i]+" ";
		if(tmp.length >= len){
			returnVal +="\n"+tmpA[i]+" ";
			tmp = "";
			i--;
			skip = true;
		}else{
			if(skip == false){returnVal += tmpA[i]+" ";}
			skip = false;
		}
	}
	return returnVal;
},

febeFatal: function (err,msg,throwErr){
  // Display fatal errors	
	if(FEBE.febeIgnoreError != "" && err.toString().indexOf(FEBE.febeIgnoreError) != -1){return true;}
	let style = FEBE.febeStyle.black8;
	let tmp = this.febeWrap(err.toString(),100);
	tmp = tmp.replace(/\n/g,"\n"+style);
	tmp = style + tmp;
	tmp +="\n\n";
	style = FEBE.febeStyle.orangered12;
	if(msg.length > 100){style = FEBE.febeStyle.orangered8;}
	msg = msg.replace(/\n/g,"\n"+style);
	tmp += style+msg;
	FEBE.febeError(tmp);
	if(FEBE.febeProgressWin) FEBE.febeProgressWin.close();
	FEBE.febePrefs.setBoolPref("extensions.febe.backupInProgress",false);
	if(throwErr) throw err;
	return true;
},

febeRestoreError: function (err,msg){
  // Trap restore errors
	if(this.febeIgnoreError == "all"){return true;}
	let style = FEBE.febeStyle.black8;
	let tmp = this.febeWrap(err.toString(),100);
	tmp = tmp.replace(/\n/g,"\n"+style);
	tmp = style + tmp;
	tmp +="\n\n";
	style = FEBE.febeStyle.orangered12;
	if(msg.length > 100){style = FEBE.febeStyle.orangered8;}
	msg = msg.replace(/\n/g,"\n"+style);
	tmp += style+msg;
	let message = tmp;
	let opts = this.febeSetWinOpts(true);
	this.febeWin = window.openDialog('chrome://febe/content/febeRestoreError.xul', 'FEBE Restore Error', opts ,message);
	this.febeSetAlertMsg();
	return true;
},

febeLocalizedDate: function (aDate){
	let lDate = new Date(parseInt(aDate));
	let rv = lDate.toLocaleDateString()+" "+lDate.toLocaleTimeString();
	if(rv.indexOf("Invalid") != -1){rv = aDate;}
	return rv; 
},

febeNewDirName: function (which,dirName){
  // Rename timestamped directories from/to ISO8601 to European
	let str = dirName.substr(10,5);
	switch(which){
		case 0:	// Rename DD.MM to MM-DD
			str = str.substr(3,2)+"-"+str.substr(0,2);
			break;
		case 1:	// Rename MM-DD to DD.MM
			str = str.substr(3,2)+"."+str.substr(0,2);
			break;
	}//switch
	let newName = dirName.substr(0,10) + str + dirName.substr(15);
	return newName;
},

febeStripSpaces: function (extName){	// Needed?
  // Remove spaces and undesirable characters from extension name
	let tmp = "";
	let mask = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
	mask += ".+-_";
	
	if(extName){
		for (let i = 0; i <= extName.length; i++){
			let c = extName.charAt(i);
			if( mask.indexOf(c) != -1 ){tmp += c};
		}
	}
	return tmp;
},

febeCopyFile: function (sourcefile,destdir,dName){
	let msg = "In febeCopyFile()"
	msg += "\n   sourcefile: "+sourcefile;
	msg += "\n   destdir: "+destdir;
	msg += "\n   dName: "+dName;
	febeDebug(msg);
	this.febeErr = "";
	if(dName == "parent.lock"){return true;}	// Skip this file

	let aFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
	aFile.initWithPath(sourcefile);
	let aDir = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
	aDir.initWithPath(destdir);
	let oFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
	oFile.initWithPath(destdir);
	oFile.append(dName);
	try{
		oFile.remove(false);
	}catch(e){;;}
		
	try{
		aFile.copyTo(aDir,dName);
		let newPerms = 438;	// -rw-rw-rw-
		if(oFile.isExecutable()) newPerms = 511;	// -rwx-rwx-rwx
		oFile.permissions = newPerms;
		oFile.lastModifiedTime = new Date().getTime();	// Set last modified datetime to current datetime
	}catch(e){
		let msg = this.febeMsg[168].replace("%sourcefile%",sourcefile+"\n");
		msg = msg.replace("%destdir%",destdir+"\n");
		msg = msg.replace("%dName%",dName);
		this.febeErr = "skip";
		this.febeErrorList.push(msg);
		febeDebug(msg);
		return false;
	}
	febeDebug("Done with febeCopyFile()")
	return true;
},

febeGetBuDate: function (filename){
	let oFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
	oFile.initWithPath(filename);
	this.febeBUdate = new Date(oFile.lastModifiedTime);
	return this.febeBUdate;
},

febeRestartFx: function (){
	// Borrowed from Jed Brown's "Restart Firefox" extension
	a = Ci.nsIAppStartup,Cc["@mozilla.org/toolkit/app-startup;1"].getService(a).quit(a.eRestart | a.eAttemptQuit);
	return true;
},

febeObfuscate: function (bool, str){
  //Modified base64 obfuscation
	switch(bool){
		case true:
			try{	//Bug 439711 - btoa does not work on unicode characters, so use encodeURIComponent() instead
				let test = btoa(str);
			}catch(e){
				str = "0"+encodeURIComponent(str);
				return str.toString();
			}//try
			let r=Math.floor(Math.random()*4+2);
			for(var i=0; i<r; i++){
				str = btoa(str);
			}				
			return i.toString()+str;
			break;
		case false:
			let c = new Number(str.charAt(0));
			str = str.substr(1);
			if(c == 0) {return decodeURIComponent(str);}
			for(let i=0; i<c; i++){
				str = atob(str);
			}	
			return str;
			break;
		default:
			return null;
			break;
	}
	return true;
},

febeChmod: function (aDir){
// Recursively set file permissions
//  Directories: hex: 0x1ED, octal: 0755, dec: 493, drwx-rw-rw
//  Files: hex: 0x1A4, octal: 0644, dec: 420
	//if(this.febePlatform == 1) return true;	// Don't bother with Windows
	let aFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
	if (!aFile) return false;

	aFile.initWithPath(aDir);
	let entries = aFile.directoryEntries;
	
	while(entries.hasMoreElements()){
		let entry = entries.getNext();
		entry.QueryInterface(Ci.nsIFile);
		let src = entry.path;
		if(entry.isDirectory()){
			entry.permissions = 0x1ED;
			this.febeChmod(src);
		}else{
			entry.permissions = 0x1A4;
		}
	}
	return true;
},

febeEscape: function (str){
  // Convert apostrophes to double quotes
	return str.toString().replace(/\'/g,'"');
},

febeDontAskAgain: function (){	// Needed?
	let d = document.getElementById('dontask');
	let dontask = d.checked;
	this.febePrefs.setBoolPref("extensions.febe.dontaskagain",dontask);
	return true;
},

getSavedAddonData: function(){
	this.febeAddonDataExternallyLoaded.value = false;
	this.febeAddonDataExternallyLoaded.date = null;
	
	this.febeDataFile = Cc["@mozilla.org/file/directory_service;1"].getService(Ci.nsIProperties).get("ProfD", Ci.nsIFile);
	this.febeDataFile.append(this.FEBEEXTENSIONDATA);
	if(this.febeDataFile.exists() && this.febeDataFile.fileSize > 0){
		let fis = Cc["@mozilla.org/network/file-input-stream;1"].createInstance(Ci.nsIFileInputStream);
		fis.init(this.febeDataFile, 0x01, 0x124, 0);
		fis.QueryInterface(Ci.nsILineInputStream);

		let cis = Cc["@mozilla.org/intl/converter-input-stream;1"].createInstance(Ci.nsIConverterInputStream);
		cis.init(fis,"UTF-8", 0, 0x0000);
		
		let lis = cis.QueryInterface(Ci.nsIUnicharLineInputStream);
		let line = {}, hasmore, allAddons = [], cnt = 0;	
		do {
			hasmore = lis.readLine(line);			
			let item = new Object(JSON.parse(line.value));
			allAddons.push(item);
			cnt++;
		} while(hasmore);
		cis.close();
		fis.close();
		
		this.febeAddonDataExternallyLoaded.value = true;
		let dTime = this.febeDataFile.lastModifiedTime;
		this.febeAddonDataExternallyLoaded.date = new Date(dTime).toLocaleString();
		FEBEstorage.setItem("febeAddonDataExternallyLoaded", this.febeAddonDataExternallyLoaded);
		
		FEBEstorage.setItem("febeAllAddons", allAddons);
		return true;
	}
	return false;
},

febeRemoveStyle: function (txt){
  // remove ,style> tag from txt
	let styleStart = txt.indexOf("<style>");
	if(styleStart == -1){return txt;}
	let styleEnd = txt.indexOf("</style>");
	if(styleEnd == -1){return txt;}
	return txt.substr(styleEnd+8);
},

febeNow: function (){
	// Return current localized date/time
	let dte = new Date();
	return FEBE.febeLocalizedDate(dte);
},

febeInitDir: function (){	
	// Get pointer to FEBE extension directory
	this.febeProfDir = Cc["@mozilla.org/file/directory_service;1"].getService(Ci.nsIProperties).get("ProfD", Ci.nsIFile);
	this.FEBEdir = this.febeProfDir.clone();
	this.FEBEdir.append("extensions");
	this.FEBEdir.append(this.FEBE_GUID);

	if(this.febeInitialized == true){return true;}	// Only run the rest of this routine once
	this.febeInitialized = true;	
	
//	Get profile name
	let tmp = this.febeProfDir.leafName;
	let p = tmp.indexOf(".")
	this.febeProfName  = tmp.substr(p+1);
	FEBEstorage.setItem("febeProfName", this.febeProfName);
	return true;
},

febeInitEssentials: function (){
	// Pointer to profile directory
	this.febeProfDir = Cc["@mozilla.org/file/directory_service;1"]
        .getService(Ci.nsIProperties)
        .get("ProfD", Ci.nsIFile);
	this.febeSetUnicharPref("extensions.febe.curProfDir",this.febeProfDir.path);
				
  // Pointer to main browser window
	let wm = Cc["@mozilla.org/appshell/window-mediator;1"].getService(Ci.nsIWindowMediator);  
	this.febeMainWindow = wm.getMostRecentWindow("navigator:browser"); 
	
	// Get pointer to FEBE extension directory
	this.FEBEdir = this.febeProfDir.clone();
	this.FEBEdir.append("extensions");
	this.FEBEdir.append(this.FEBE_GUID);

	// Set obsevers
	window.addEventListener("load", function(){FEBE.febeObserver.register();},false);
	window.addEventListener("unload", function(){FEBE.febeObserver.unregister();},false);
	
	this.setStyles();
	return true;
},

febeCheckBackupOnStartup: function (){
	FEBE.setStyles();
	let windowtype = document.documentElement.getAttribute('windowtype');
	febeDebug("febeCheckBackupOnStartup: windowtype = "+windowtype+"  (Should be 'navigator:browser')");
	if(windowtype != "navigator:browser"){febeDebug("windowtype != 'navigator:browser' - returning false");return false;}
	if(!this.febeCheckWaitTime("startup")){febeDebug("febeCheckWaitTime('startup') is false - returning");return false;}
	if(!this.febeIsScheduleController){febeDebug("febeIsScheduleController is false - returning");return false;}
	let ok = false;
	if(this.febePrefs.getBoolPref("extensions.febe.backupOnStartup")){ok = true;}
	if(this.febePrefs.getBoolPref("extensions.febe.backupOnStartup.prompt") && ok){
		let tmp = FEBE.febeStyle.purple12+this.febeMsg[281]+"\n";
		tmp += FEBE.febeStyle.black+this.febeMsg[283]+"\n";
		ok = FEBE.febeConfirm(tmp);
		febeDebug("febeCheckBackupOnStartup: Show popup window - ok = "+ok);
	}
	febeDebug("febeCheckBackupOnStartup: ok = "+ok);
	if(ok){
		this.febeBackupRunType = 2	// 'On startup'
		this.febePrefs.setCharPref("extensions.febe.lastbackuponstartup",this.febeNow())
		this.initBackup();
		febeDebug("Initializing backup on startup");
	}else{
		febeDebug("Setting backup reminder for backup on startup");
		this.backupReminder();
	}
	return true;
},

febeCheckWaitTime: function (which){
	febeDebug("febeCheckWaitTime: which = "+which);
	let lastbustartup = this.febePrefs.getCharPref("extensions.febe.lastbackuponstartup");
	let lastbushutdown = this.febePrefs.getCharPref("extensions.febe.lastbackuponshutdown");
	let waitstartup = this.febePrefs.getIntPref("extensions.febe.daystowaitforbackupOnStartup");
	let waitshutdown = this.febePrefs.getIntPref("extensions.febe.daystowaitforbackupOnShutdown");
	let startupelapsed = this.febeDaysElapsed(lastbustartup);
	let shutdownelapsed = this.febeDaysElapsed(lastbushutdown);
	febeDebug("febeCheckWaitTime: lastbustartup = '"+lastbustartup+"'");
	febeDebug("febeCheckWaitTime: lastbushutdown = '"+lastbushutdown+"'");
	febeDebug("febeCheckWaitTime: waitstartup = '"+waitstartup+"'");
	febeDebug("febeCheckWaitTime: waitshutdown = '"+waitshutdown+"'");
	febeDebug("febeCheckWaitTime: startupelapsed = '"+startupelapsed+"'");
	febeDebug("febeCheckWaitTime: shutdownelapsed = '"+shutdownelapsed+"'");

	switch(which){
		case "startup":
			if(lastbustartup == "") return true;
			if(startupelapsed >= waitstartup) return true;
			break;
		case "shutdown":
			if(lastbushutdown == "") return true;
			if(shutdownelapsed >= waitshutdown) return true;
			break;
	}//switch
	return false;
},

febeDaysElapsed: function (starttime){
	// Return the number of days elapsed between starttime (in milliseconds) and now
	let dte = new Date(starttime);
	let now = new Date(this.febeNow());
	let diff = now - dte;
	let elapsed = diff / (24 * 60 * 60 * 1000);
	return elapsed;
},

febeCheckForMissedScheduledBackupLoad: function (){
	if(FEBE.febePrefs.getBoolPref("extensions.febe.disableMissedScheduledBackup")){return false}	// Not checking for missed backups
	setTimeout(function(){FEBE.febeCheckForMissedScheduledBackup(true);},10000);
	return true;
},

febeClose: function (){
  // Re-assign the schedule controller to another window if necessary
	if(FEBE.febeIsScheduleController){
		FEBE.febeIsScheduleController = false;
		FEBE.febeScheduleController(window);
	}
	return true;
},

febeLocales: function (){
  // Return a list of installed locales

	// Parse chrome.manifest
	// ex:
	// locale	febe	en-US	chrome/locale/en-US/
	// locale	febe	bg-BG	chrome/locale/bg-BG/
	// locale	febe	ca-AD	chrome/locale/ca-AD/

	let extDir = Cc["@mozilla.org/file/directory_service;1"]
        .getService(Ci.nsIProperties)
        .get("ProfD", Ci.nsIFile);
	
	extDir.append("extensions");
	extDir.append(this.FEBE_GUID);
	extDir.append("chrome.manifest");
	
	// open an input stream from file
	let istream = Cc["@mozilla.org/network/file-input-stream;1"].createInstance(Ci.nsIFileInputStream);
	istream.init(extDir, 0x01, 0x124, 0);
	istream.QueryInterface(Ci.nsILineInputStream);
	
	// read lines into array
	let lArray = [], line = {}, hasmore, str = "chrome/locale/", idx, tmp;
	do {
		hasmore = istream.readLine(line);			// locale	febe	en-US	chrome/locale/en-US/
		idx = line.value.indexOf(str);
		if(idx != -1){
			tmp = line.value.substring(idx);		// chrome/locale/en-US/
			tmp = tmp.substring(str.length);		// en-US/
			idx = tmp.indexOf("/");
			tmp = tmp.substring(0,idx);					// en-US
			lArray.push(tmp);
		}
		
	} while(hasmore);
	istream.close();
	return lArray;
},

febeWelcomePageDisplay: function (){
	try{
		gBrowser.selectedTab = gBrowser.addTab(this.febeWelcomePage);
	}catch(e){;}
},

backupReminder: function (){
  // See if we need to remind about a backup
	FEBE.setStyles();
	let prefName = "extensions.febe.lastbackup";
	if(!this.febePrefs.prefHasUserValue(prefName)){return true;}
	let lastBU = Date.parse(this.febePrefs.getCharPref(prefName));
	let now = Date.parse(Date());

	let reminderDays = this.febePrefs.getIntPref("extensions.febe.reminderdays");
	if(reminderDays > 0){
		if(this.febeReminded == true){return true;}
		let elapsed = (now - lastBU) / (24 * 60 * 60 * 1000);	// Number of days since last backup
		//elapsed = 100
		if(elapsed >= reminderDays){
			let tmp = FEBE.febeStyle.orangeredBold+this.febeMsg[171]+"\n";
			tmp += FEBE.febeStyle.black+this.febeMsg[172].replace("%days%",parseInt(elapsed))+"\n";
			tmp += this.febeLocalizedDate(lastBU)+"\n\n";
			tmp += FEBE.febeStyle.black+this.febeMsg[232]+"\n";
			tmp += FEBE.febeStyle.blackBold+this.febeMsg[233]+"\n";
			if(this.febeReminded != true){
				if(FEBE.febeConfirm(tmp)){
				this.febeBackupRunType = 5	// 'Reminded'
				this.initBackup();}
				this.febeReminded = true;
			}
		}
	}
	return true;	
},

febeGetEnvironmentVariableValue: function (envString){
	let env = Cc["@mozilla.org/process/environment;1"].createInstance(Ci.nsIEnvironment);
  return env.get(envString);
},

setupDelayedBackup: function (){
	let opts = this.febeSetWinOpts(false);
	this.febeWin = window.openDialog('chrome://febe/content/febeDelayed.xul','FEBE Delayed',opts);	
	this.febeWin.focus();
	return true;

},

setDelayedBuDefaults: function(){
	// Set the default delayed backup (last values used)
	let hrs = document.getElementById('delayHrs');
	hrs.value = this.febePrefs.getIntPref('extensions.febe.delayHrs');
	let min = document.getElementById('delayMin');
	min.value = this.febePrefs.getIntPref('extensions.febe.delayMin');
	let sec = document.getElementById('delaySec');
	sec.value = this.febePrefs.getIntPref('extensions.febe.delaySec');
	FEBE.delayedBackupShow();
	return true;
},

delayedBackupShow: function(){
	let vbox = document.getElementById('showDBUs');
	if(!vbox) return false;
	while (vbox.firstChild) {
		vbox.removeChild(vbox.firstChild);
	}
	let hb = document.createElement('hbox');
	let lbl = document.createElement('label');
	lbl.setAttribute('value',"");
	let btn = document.createElement('button');
	btn.setAttribute('label',this.febeMsg[427]);
	FEBE.setDelayedBuVars('get');
	let anyBuSet = false;
	for(let i=0; i<FEBE.febeDelayedBuArray.length; i++){
		let which = FEBE.febeDelayedBuArray[i];
		if(which == null) continue;
		if(which.buTime < new Date().getTime()) continue;	// Backup aready happened
		let hbox = hb.cloneNode(false);
		let label = lbl.cloneNode(true);
		label.value = which.tooltip;
		hbox.appendChild(label);
		let button = btn.cloneNode(true);
		button.onclick = function(event){FEBE.cancelDelayedBu(i)};
		hbox.appendChild(button);
		vbox.appendChild(hbox);
		anyBuSet = true;
		hbox.scrollIntoView(false);
	}

	if(!anyBuSet){
		FEBE.febeDelayedBu = new febeDelayedBuObj(false,null,-1,0);
		FEBE.febeSetStatus();
	}else{
		// Set the tooltip to the next delayed backup
		for(let i=0; i<FEBE.febeDelayedBuArray.length; i++){
			let which = FEBE.febeDelayedBuArray[i];
			if(which == null) continue;
			let save = FEBE.febeDelayedBu;
			FEBE.febeDelayedBu = which;
			FEBE.febeSetStatus();
			FEBE.febeDelayedBu = save;
			break;
		}
	}
	return true;
},

cancelDelayedBu: function(which){
	let obj = FEBE.febeDelayedBuArray[which];
	let PID = obj.PID;
	FEBE.febeMainWindow.clearTimeout(PID);
	delete FEBE.febeDelayedBuArray[which];
	FEBE.setDelayedBuVars('set');	
	FEBE.delayedBackupShow();
	return true;
},

performDelayedBackup: function (){
	let hrs = document.getElementById('delayHrs').value;
	FEBE.febePrefs.setIntPref('extensions.febe.delayHrs',hrs);
	let min = document.getElementById('delayMin').value;
	FEBE.febePrefs.setIntPref('extensions.febe.delayMin',min);
	let sec = document.getElementById('delaySec').value;
	FEBE.febePrefs.setIntPref('extensions.febe.delaySec',sec);
	
	let delay = hrs * 60 * 60 * 1000;
	delay += min * 60 *1000;
	delay += sec * 1000;
	if(delay == 0) return false;
	FEBE.febeSetMsgs();
	FEBE.febeDelayedBu.initiated = true;
	let startTime = new Date().getTime() + delay;
	let dte = new Date(startTime);
	let tooltip = FEBE.febeMsg[426]+" "+dte.toLocaleTimeString();
	FEBE.febeDelayedBu.tooltip = tooltip;
	let PID = FEBE.febeMainWindow.setTimeout(function(){
		FEBE.febeBackupRunType=6;
		FEBE.initBackup();
		FEBE.febeBackupRunType=0;
		FEBE.febeDelayedBu.initiated = false;
		FEBE.delayedBackupShow();
	},delay);
	let obj = new febeDelayedBuObj(true,tooltip,PID,startTime);
	FEBE.febeDelayedBuArray.push(obj);	
	FEBE.setDelayedBuVars('set');
	FEBE.delayedBackupShow();
	return true;
},

initBackup: function (){
  // Get setup and start the backup	
	FEBE.febeGetAddonList(); 
	let freq = FEBE.febePrefs.getCharPref("extensions.febe.schedule.frequency");
	FEBE.febeIsScheduledBu = ((freq == 'none') ? false : true);
	let dte = new Date();
	let febeStartTime = FEBE.febeLocalizedDate(dte.getTime());
	FEBE.febePrefs.setCharPref("extensions.febe.buStartTime",dte.getTime());
	if(FEBE.febeIsScheduledBu) FEBE.febePrefs.setCharPref("extensions.febe.schedule.last.backup",dte);
	FEBE.febeVersion = FEBE.febeMsg[49]+" "+FEBE.febeGetVersion();
	FEBE.febeGetPrefs();
	if(!FEBE.febeGetBDD()){return false;}
	if(!FEBE.febeSanityCheck()){return false;}
	if(!FEBE.febeInitDir()){return false;}
	FEBE.febeFEBEbackedUp = false;
	FEBE.febeAddedToIgnoreList = [];
	this.getBUlocations(true);
	
	// Create timestamped directory if needed
	if(FEBE.febeUseTimestampedDir){
		let ts = FEBE.febePrefs.getCharPref("extensions.febe.timestamp.format");
		if(!FEBE.febeVerifyTimestamp(ts)){return false;}
		FEBE.febeDelTimestampDirs();
		let timestamp = FEBE.febeMakeTimestampName(ts, dte.getTime());
		FEBE.febeBuDesDir.append(timestamp);
		if(!FEBE.febeBuDesDir.exists() || !FEBE.febeBuDesDir.isDirectory()){
			FEBE.febeBuDesDir.create(Ci.nsIFile.DIRECTORY_TYPE, 0x1FF);	// 0x1ED = 0755, 0x1FF = 0777
		}
		FEBE.febeExBuDir = FEBE.febeBuDesDir.path;
		this.febeDestDirs[0].dir = FEBE.febeExBuDir;

		// Create timestamped directories in other backup locations
		for(let i=1; i<this.febeDestDirs.length; i++){
			let dFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
			let dir = this.febeDestDirs[i].dir;
			dFile.initWithPath(dir);
			dFile.append(timestamp);
			if(!dFile.exists() || !dFile.isDirectory()){
				dFile.create(Ci.nsIFile.DIRECTORY_TYPE, 0x1FF);
			}
			this.febeDestDirs[i].dir = dFile.path;
		}

	}
	FEBE.febeSetUnicharPref("extensions.febe.curBUdir",FEBE.febeExBuDir);
	FEBEstorage.setItem("febeBackupLocations", this.febeDestDirs);
	
	if(!FEBE.febeClearDir()){return false;}

	FEBE.febeProfDir = Cc["@mozilla.org/file/directory_service;1"]
		.getService(Ci.nsIProperties)
		.get("ProfD", Ci.nsIFile);
	FEBE.febeSetUnicharPref("extensions.febe.curProfDir",FEBE.febeProfDir.path);
	
	// Set max script execution time if needed
	let febeMaxScriptTimeDflt = FEBE.febePrefs.getIntPref("dom.max_chrome_script_run_time");
	let febeMaxScriptTimeFEBE = FEBE.febePrefs.getIntPref("extensions.febe.max.chrome.script.execution.seconds");
	FEBEstorage.setItem("febeMaxScriptTimeDflt",febeMaxScriptTimeDflt);
	FEBEstorage.setItem("febeMaxScriptTimeFEBE",febeMaxScriptTimeFEBE);	
	if(febeMaxScriptTimeDflt != febeMaxScriptTimeFEBE) FEBE.febePrefs.setIntPref("dom.max_chrome_script_run_time",febeMaxScriptTimeFEBE);

	if(FEBE.febeBuInProgress()){
		if(!FEBE.febeBuInProgressCheck()) return false;
	}
	let win = FEBE.febeControllerWindow;
	if(!win) win = FEBE.febeMainWindow;
	if(win.document.getElementById("febeTLBRbutton")){
		win.document.getElementById("febeTLBRbutton").status = "disabled";
		win.document.getElementById("febeTLBRbutton").hidden = "true";
	}
	FEBE.febeGetBuType();
	if(FEBE.febeDispProgress){
		// Open the progress window
		FEBE.febeProgressWin = win.openDialog('chrome://febe/content/febeProgress.xul', 'FEBE progress', 'chrome,alwaysRaised,centerscreen,dialog=no,modal=no',this.febeBackupRunType);
	}else{
		FEBE.startBackup();
	}
	
	if(win.document.getElementById("febeTLBRbutton")){
		win.document.getElementById("febeTLBRbutton").setAttribute("status","normal");
		win.document.getElementById("febeTLBRbutton").setAttribute("hidden","false");
	}
	if(win.document.getElementById("febestatusbar")){
		win.document.getElementById("febestatusbar").className = "toolbarbutton-1 chromeclass-toolbar-additional febe-normal";
		win.document.getElementById("febestatusbar").hidden = FEBE.febeHideIcons;
		win.document.getElementById("febestatusbar").collapsed = FEBE.febeHideIcons;
	}
	return true;
},

progressLoad: function(win){
	FEBE.countBuItems();
	// Give some time for the progress window to display
	setTimeout(function(){
		FEBE.progressLoaded(win);
	},500);
	return true;
},

progressLoaded: function(win){
	FEBE.febeProgressWin = win;
	FEBE.febeBackupRunType = win.arguments[0];
	FEBE.febeDestDirs = FEBEstorage.getItem("febeBackupLocations", "");
	FEBE.startBackup();
},

countBuItems: function(){
	this.febeItemCount = 0;
	if(this.febeBuProfile){
		// Only backing up full profile
		this.febeItemCount++;
	}else{
		for(let i in this.febeAddons){
			let item = this.febeAddons[i];
			if(!item.isEligibleForBackup) continue;
			if(!item.isValid) continue;
			if(item.ignore) continue;
			if(item.isGlobal) continue;
			if(item.type == 'extension' && !this.febeBuExtensions) continue;
			if(item.type == 'theme' && !this.febeBuThemes) continue;
			if(item.isPersona && !this.febeBuThemes) continue;
			if(this.febeIgnoreDisabled && item.userDisabled) continue;
			this.febeItemCount++;
		}
		if(this.febeBuBookmarksJSON) this.febeItemCount++;
		if(this.febeBuBookmarksHTML) this.febeItemCount++;
		if(this.febeBuPreferences) this.febeItemCount++;
		if(this.febeBuCookies) this.febeItemCount++;
		if(this.febeBuUserChrome) this.febeItemCount++;
		if(this.febeBuUserPwd) this.febeItemCount++;
		if(this.febeBuSearchPlugins) this.febeItemCount++;
		if(this.febeBuBrowserHistory) this.febeItemCount++;
		if(this.febeBuFormFillHistory) this.febeItemCount++;
		if(this.febeBuPermissions) this.febeItemCount++;
		if(this.febeIncludeFEBEinBu) this.febeItemCount++;
		if(this.febeBUtype == "both") this.febeItemCount++;
		
		if(this.febePrefs.prefHasUserValue("lightweightThemes.usedThemes") && this.febeBuThemes) this.febeItemCount++;
		
		if(this.febeBuUDBu){
			this.febeUDBuInit();
			for(let i in this.febeUDBuList){
				let Label = new String(this.febeUDBuList[i].Label);
				if(Label.length == 0){continue;}	// Datafile is empty?
				let Include = Boolean(this.febeUDBuList[i].Include);
				if(Include) {this.febeItemCount++;febeDebug("Counting: "+this.febeUDBuList[i].Label+"   "+this.febeItemCount)}
			}
		}
	}
	if(this.febeSaveResults) this.febeItemCount++;
	return true;
},

febeUpdateProgressWindow: function (pMsg,includeInTotal){
	if(!FEBE.febeDispProgress) return true;
	if(!FEBE.febeProgressWin) return false;
	if(!FEBE.febeProgressWin.document) return false;
	let pMsgField = FEBE.febeProgressWin.document.getElementById("febeProgressText");
	if(pMsgField){pMsgField.setAttribute("value",pMsg)};
	if(includeInTotal){
		let progressCnt = FEBE.febeProgressWin.document.getElementById("progresscount");
		let total = new Number(FEBE.febeItemCount);
		this.febeProgressCount++;
		let cnt = new Number(this.febeProgressCount);
		let pct = new Number(parseInt((cnt/total)*1000,10)/10);
		if(pct > 100) pct = 100;
		progressCnt.value = pct.toString()+"%";
		let pm = FEBE.febeProgressWin.document.getElementById("febeProgressmeterID");
		pm.value = pct;
	}
	FEBE.febeProgressWin.focus();
	FEBE.pauseThread();
	return true;
},

getBUlocations: function(alert){
	if(typeof alert == undefined) alert = true;
	this.febeDestDirs = [];
	
	// Main backup destination directory
	let item = {};
	item.name = "FEBE backup destination directory";
	item.dir = this.febeGetUnicharPref("extensions.febe.curBUdir");
	this.febeDestDirs.push(item);
	
	// Dropbox
	let backupDestinationDirectory = this.febeGetUnicharPref("extensions.febe.extBUdir");	
	let dropboxDir = this.febeGetUnicharPref("extensions.febe.dropbox.rootdir");
	let dropboxEnabled = this.febePrefs.getBoolPref("extensions.febe.dropbox.enabled");
	
	// If the backup destination directory and the local dropbox folder are the same, disable dropbox so only one backup is made
	if(dropboxDir == backupDestinationDirectory) dropboxEnabled = false;

	if(dropboxEnabled){
		item = {};
		item.name = "Dropbox";
		item.dir = this.febeGetUnicharPref("extensions.febe.dropbox.rootdir");
		this.febeDestDirs.push(item);
	}
	
	// Other locations
	this.febeOtherCloudServices = JSON.parse(this.febeGetUnicharPref("extensions.febe.othercloudservices"));	
	
	let location;
	for(let i=1; i<4; i++){
		location = "location"+i.toString();
		if(this.febeOtherCloudServices[location].enabled){
			item = {};
			item.name = this.febeOtherCloudServices[location].name;
			item.dir = this.febeOtherCloudServices[location].uri;
			let dFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
			dFile.initWithPath(item.dir);
			if(!dFile.exists()){
				let tmp = this.febeMsg[503];
				tmp = tmp.replace("%NAME%","'"+item.name+"'");
				tmp = tmp.replace("%LOCATION%","'"+item.dir+"'");
				if(alert) this.febeAlert(tmp);
				continue;
			}
			this.febeDestDirs.push(item);
		}
	}
	return true;	
},

startBackup: function(){
	let buType = this.febePrefs.getCharPref("extensions.febe.buType");
	febeDebug("startBackup() - backup type: "+buType)
	if(buType == "profile"){FEBE.doBackup(); return true;}
	FEBE.initBackupItemList();
	for(let i in FEBE.selectedItemsList){
		let which = FEBE.selectedItemsList[i];
		febeDebug("In startBackup() - Calling febeCheckAdditional for "+which.id);
		FEBE.febeCheckAdditional(which,false);
	}
	FEBE.febeCheckAdditionalAsync();	// Finish checking and start backup
	return true;
},

doBackup: function (){
	febeDebug("doBackup()");
	// All async checks should be done so perform the actual backup
	this.febeExtensionsList = {};
	this.febeThemesList = {};
	this.febeSkippedList = {};
	this.febeErrorList = [];
	this.febeWarningList = [];
	this.febeDisabledCount = 0;
	this.febePrefs.setBoolPref("extensions.febe.backupInProgress",true);
	this.febeGetPrefs();
	this.febeGetAddonList();
	this.febeRunAsync = this.setAsyncMode();
	if(!this.febeBuProfile){
		if(!this.febeBackupExtensions()){
			this.febeCloseProgressWindow();
			return false;
		}
		this.febeBackupPersonas();
		this.febeBackupBookmarksJSON();
		this.febeBackupBookmarksHTML();
		this.febeBackupPreferences();
		this.febeBackupCookies();
		this.febeBackupUserChrome();
		this.febeBackupPasswords();
		this.febeBackupSearchPlugins();
		this.febeBackupBrowserHistory();
		this.febeBackupFormFillHistory();
		this.febeBackupPermissions();
		this.febeBackupUDBu();
		if(this.febeBUtype == "both"){
			this.febeBackupProfile();
		}
	}else{
		this.febeBackupProfile();
	}
	this.febeIncludeFEBE();
	this.febeWriteResults();
	this.febeStoreBUdate(); 
	
	this.febeMainWindow.setTimeout(function(){FEBE.febeCloseProgressWindow();},500);
		
	this.febePrefs.setBoolPref("extensions.febe.backupInProgress",false);
	this.febeScheduleBackup(true);	// Schedule the next backup
	this.febePrefs.setBoolPref("extensions.febe.backupInProgress",false);
	this.febeIsScheduledBu = false;
	
	// Reset javascript execution time if necessary
	let febeMaxScriptTimeDflt = FEBEstorage.getItem("febeMaxScriptTimeDflt",0);
	let febeMaxScriptTimeFEBE = FEBEstorage.getItem("febeMaxScriptTimeFEBE",0);
	if(febeMaxScriptTimeDflt != febeMaxScriptTimeFEBE){this.febePrefs.setIntPref("dom.max_chrome_script_run_time",febeMaxScriptTimeDflt);}

	return true;
},

febeMakeTimestampName: function (timestamp,date){
	let dte=new Date(parseInt(date));
	let YYYY = String(dte.getFullYear());
	let MM = String(dte.getMonth()+1);
	if(MM.length == 1){MM = "0" + MM;}
	let DD = String(dte.getDate());
	if(DD.length == 1){DD = "0" + DD;}
	let hh = String(dte.getHours());
	if(hh.length == 1){hh = "0" + hh;}
	let mm = String(dte.getMinutes());
	if(mm.length == 1){mm = "0" + mm;}
	let ss = String(dte.getSeconds());
	if(ss.length == 1){ss = "0" + ss;}
	
	timestamp = timestamp.replace("YYYY",YYYY);
	timestamp = timestamp.replace("MM",MM);
	timestamp = timestamp.replace("DD",DD);
	timestamp = timestamp.replace("hh",hh);
	timestamp = timestamp.replace("mm",mm);
	timestamp = timestamp.replace("ss",ss);
	return timestamp;
},

febeVerifyTimestamp: function (timestamp){
  // Verify the timestamp mask
	if(timestamp == "FEBE YYYY MM-DD hh.mm.ss"){return true;}	// ISO8601
	if(timestamp == "FEBE YYYY DD.MM hh.mm.ss"){return true;}	// European
	let tmp=FEBE.febeStyle.orangeredBold+this.febeMsg[208];
	tmp = tmp.replace("%TIMESTAMP%",timestamp) +"\n\n";
	tmp += this.febeMsg[209].replace("%FORMAT1%","FEBE YYYY MM-DD hh.mm.ss")+"\n";
	tmp += this.febeMsg[210].replace("%FORMAT2%","FEBE YYYY DD.MM hh.mm.ss")+"\n\n";
	tmp += FEBE.febeStyle.orangeredBold+this.febeMsg[211];
	this.febeAlert(tmp);
	return false;
},

febeVerify: function (verifyFileName){
	// Not currently used
	return true;
},

febeGetBDD: function (){
  // See if backup destination directory exists
	let prefName = "extensions.febe.extBUdir";
	if(this.febePrefs.prefHasUserValue(prefName)){
		this.febeExBuDir = this.febeGetUnicharPref(prefName); 
		if(this.febeExBuDir == ""){
			if(this.febePlatform == 1){this.febeExBuDir = "C:\\";}
			if(this.febePlatform == 2){this.febeExBuDir = "/";}
			if(this.febePlatform == 3){this.febeExBuDir = "/";}
		}
		this.febeBuDesDir = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
		this.febeBuDesDir.initWithPath(this.febeExBuDir);
		if (!(this.febeBuDesDir.exists() && this.febeBuDesDir.isDirectory())){
			this.febeAlert(this.febeMsg[0]+" \""+this.febeExBuDir+"\" "+this.febeMsg[1]+"\n"+this.febeMsg[2]);
			return false;
		}
	} else {
		this.febeAlert(this.febeMsg[3]+"\n"+this.febeMsg[2]);
		return false;
	}
	return true;
},

febeDelTimestampDirs: function (){
  // Delete timestamped directories if needed
	if(this.febeMaxDirs == 0){return true;}	// No limit
	let timestamp = this.febePrefs.getCharPref("extensions.febe.timestamp.format");
	switch(timestamp){
		case "FEBE YYYY MM-DD hh.mm.ss":
			this.febeDelISO8601Dirs();
			break;
		case "FEBE YYYY DD.MM hh.mm.ss":
			this.febeDelEuropeanDirs();
			break;
	}//switch
	return true;
},

febeDelISO8601Dirs: function (){
  // Delete ISO8601 formated directories 
	let dirArray = [];
	let mask = /^FEBE \d\d\d\d \d\d-\d\d \d\d\.\d\d\.\d\d$/;
	let buDirRoot = this.febeBuDesDir.clone();
	let entries = buDirRoot.directoryEntries;
	
	while(entries.hasMoreElements()){
		let entry = entries.getNext();
		entry.QueryInterface(Ci.nsIFile);
		let dirName = entry.leafName;
		if(!entry.isDirectory()){continue;}
		if(!dirName.match(mask)){continue;}
		dirArray.push(dirName);
	}
	let numDirsToDelete = dirArray.length - this.febeMaxDirs + 1;
	dirArray.sort();
	this.febex = false;
	let errArray = [], rmDir;
	for(let i=0; i<numDirsToDelete; i++){
		rmDir = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
		rmDir.initWithPath(buDirRoot.path);
		rmDir.append(dirArray[i]);
		let permissions = (!rmDir.isReadable() && !rmDir.isWritable() && !rmDir.isExecutable());
		if(!permissions){	// If the file is not read/write/execute (deletable), try to change the permissions
			try{
				rmDir.permissions = 0x1FF; // 0777 octal = drwxrwxrwx
				if(typeof rmDir.permissionsOfLink != "undefined") rmDir.permissionsOfLink = 0x1FF;
			}catch(e){;;}
		}
		try{
			rmDir.remove(true);	
		}catch(err){
			this.febex = true;
			let errObj = {};
			errObj.dirName = rmDir.path;
			errObj.name = err.name.toString();
			errArray.push(errObj);
		}
	}
	if(this.febex){
		let tmp ="<class>red</class>"
		tmp += this.febeMsg[490]+"\n";
		let cnt = tot = 0;
		for(let i in errArray){
			let item = errArray[i];
			tot++;
			if(cnt < 3){
				tmp += "<class>black</class>   "+item.dirName+" : "+item.name+"\n";
				cnt++;
			}
		}
		if(cnt < tot){
			let more = tot - cnt;
			tmp += "<class>fontI</class>"+this.febeMsg[496].replace('%NUM%',more)+"\n";
		}

		tmp += "\n"+this.febeMsg[491]+"\n\n";
		tmp += "<link>"
		tmp += this.febeMsg[492];
		tmp += ",http://www.customsoftwareconsult.com/forum/viewtopic.php?f=5&t=3680";
		tmp += "</link>\n\n";
		tmp += this.febeMsg[493];
		
		this.febeAlert(tmp);
	}
	return true;
},

UserException: function (message) {
	// Usage: throw new this.UserException("Error occurred");
   this.message = message;
   this.name = "UserException";
},

febeDelEuropeanDirs: function (){
  // Delete European formated directories 
	let dirArray = {};
	let sortArray = [];
	let mask = /^FEBE \d\d\d\d \d\d.\d\d \d\d\.\d\d\.\d\d$/;
	let buDirRoot = this.febeBuDesDir.clone();
	let entries = buDirRoot.directoryEntries;
	
	while(entries.hasMoreElements()){
		let entry = entries.getNext();
		entry.QueryInterface(Ci.nsIFile);
		let dirName = entry.leafName;
		if(!entry.isDirectory()){continue;}
		if(!dirName.match(mask)){continue;}
		let ISO8601 = this.febeNewDirName(0,dirName);
		sortArray.push(ISO8601);
		dirArray[ISO8601] = dirName;
	}
	sortArray.sort();
	let numDirsToDelete = sortArray.length - this.febeMaxDirs + 1;
	for(let i=0; i<numDirsToDelete; i++){
		let rmDir = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
		rmDir.initWithPath(buDirRoot.path);
		let which = sortArray[i];
		rmDir.append(dirArray[which]);
		rmDir.remove(true);
	}
	return true;
},

febeAbortBackup: function (){
  // Abort scheduled backup before it starts (only if statusbar icon is in "warning" state)
	FEBE.setStyles();
	let d = document.getElementById("febestatusbar");
	let prefName, tmp, lastBu, lastBuType, OK;
	if(Boolean(d)){
		let status = d.getAttribute("status");
		switch(status){
			case "warning":
				tmp=FEBE.febeStyle.orangeredBold+this.febeMsg[179];
				if(!FEBE.febeConfirm(tmp)){return;}
				this.clearSetTimeouts();
				
				tmp = FEBE.febeStyle.orangeredBold+this.febeMsg[150]+"\n";
				tmp += FEBE.febeStyle.blackBold+this.febeMsg[151]+"\n";
				tmp += FEBE.febeStyle.black+this.febeMsg[152]+"\n";
				this.febeAlert(tmp);
				this.febePrefs.setBoolPref("extensions.febe.backupInProgress",false);	// In case it tries to start, just say no ...
				
				// Turn off scheduled backups 
				prefName = "extensions.febe.schedule.frequency";
				this.febePrefs.setCharPref(prefName,"none");
				this.febeScheduleBackup(true);
				break;
			case "normal":
				tmp = FEBE.febeStyle.purple+this.febeMsg[114]+"\n";
				tmp += FEBE.febeStyle.blackMonospace+this.febeGetUnicharPref("extensions.febe.schedule.next.backup")+"\n\n";
				lastBu = this.febeGetUnicharPref("extensions.febe.lastbackup");
				lastBuType = this.febeMsg[267];
				
				prefName = "extensions.febe.lastbackup.type.desc";
				if(this.febePrefs.prefHasUserValue(prefName)){lastBuType = this.febeGetUnicharPref(prefName);}
				tmp += FEBE.febeStyle.purple+this.febeMsg[268]+" "+lastBuType+"\n";
				tmp += FEBE.febeStyle.blackMonospace+lastBu+"\n\n";
				tmp += FEBE.febeStyle.orangeredBold+this.febeMsg[266];
				OK = FEBE.febeConfirm(tmp);
				if(OK){
					this.febeBackupRunType = 1;	//'Manual'
					this.initBackup();
				}
				break;
			case "nobackup": 
				tmp = FEBE.febeStyle.orangered12+this.febeMsg[113]+"\n\n";
				lastBu = this.febeGetUnicharPref("extensions.febe.lastbackup");
				lastBuType = this.febeMsg[267];
				prefName = "extensions.febe.lastbackup.type.desc";
				if(this.febePrefs.prefHasUserValue(prefName)){lastBuType = this.febeGetUnicharPref(prefName);}
				tmp += FEBE.febeStyle.purple+this.febeMsg[268]+" "+lastBuType+"\n";
				tmp += FEBE.febeStyle.blackMonospace+lastBu+"\n\n";;
				tmp += FEBE.febeStyle.orangeredBold+this.febeMsg[266];
				this.febeSetStatus();
				OK = FEBE.febeConfirm(tmp);
				if(OK){
					this.febeBackupRunType = 1;	//'Manual'
					this.initBackup();
				}
				break;
		}//switch
	}
	return true;
},

clearSetTimeouts: function(which){
	// Clear all settimeouts and scheduled backup timer
	for(let i in this.febeSetTimeoutIDs){
		let to = new this.febeSetTimeoutObj;
		to.PID = this.febeSetTimeoutIDs[i].PID;
		to.Process = this.febeSetTimeoutIDs[i].Process;
		clearTimeout(to.PID);
	}
	this.febeSetTimeoutIDs = [];
	return true
},

febeSanityCheck: function (){
  // Check to see if there is anything to backup
	let OK = (
		this.febeBuExtensions ||
		this.febeBuThemes ||
		this.febeBuBookmarksJSON ||
		this.febeBuBookmarksHTML ||
		this.febeBuPreferences ||
		this.febeBuCookies ||
		this.febeBuUserChrome ||
		this.febeBuUserPwd ||
		this.febeBuSearchPlugins ||
		this.febeBuBrowserHistory ||
		this.febeBuFormFillHistory ||
		this.febeBuPermissions ||
		this.febeBuUDBu ||
		this.febeIncludeFEBEinBu ||
		this.febeBuProfile);
	if(!OK){this.febeAlert(this.febeMsg[131]);}
	return OK;
},

febeCloseProgressWindow: function (){
	// Close the progress window, dammit!
	let wm = Cc["@mozilla.org/appshell/window-mediator;1"].getService(Ci.nsIWindowMediator);
	let enumerator = wm.getEnumerator("febe:progress");
	while(enumerator.hasMoreElements()) {
		let win = enumerator.getNext();
		win.close();
	}
},

febeShutdown: function (){
	let application = Cc["@mozilla.org/toolkit/app-startup;1"].getService(Ci.nsIAppStartup);
	application.quit(application.eAttemptQuit);
	return true;
},

febeStoreBUdate: function (){
  // Write last backup info to preferences
	let dte = new Date();
	dte = this.febeLocalizedDate(dte);
	this.febeSetUnicharPref("extensions.febe.lastbackup",dte);
	if(this.febeIsScheduledBu) this.febePrefs.setCharPref("extensions.febe.lastbackup.scheduled.finish",dte);
	this.febeBuDesDir = this.febeGetUnicharPref("extensions.febe.curBUdir");
	this.febeSetUnicharPref("extensions.febe.lastbackup.folder",this.febeBuDesDir);
	return true;
},

febeIncludeFEBE: function (){
  // Include a copy of FEBE with backup
	if(!this.febeIncludeFEBEinBu){return true;}
	if(this.febeFEBEbackedUp){return true;}	// Don't need two copies!  Was aready backed up during extension backup.
	
	this.febeExtBuName = "FEBE{" + this.febePrefs.getCharPref("extensions.febe.currentversion") + "}.xpi";
	let item = this.febeAddons[this.FEBE_GUID];
	this.febeUpdateProgressWindow(this.febeExtBuName,true);
	for(let i=0; i<this.febeDestDirs.length; i++){
		if(item.isXpi == true){	// Perform a straight copy for xpis
			this.febeCopyFile(item.installlocation,this.febeDestDirs[i].dir,this.febeExtBuName);
		}else{
			this.febeZip(item.installlocation,this.febeDestDirs[i].dir,this.febeExtBuName,false,false,this.febeRunAsync);	
		}
		if(i>0) continue;
		if(this.febeErr == "skip"){
			item.skipped = true;
			this.febeSkippedList[item.id] = item;
		}else{
			item.skipped = false;
		}
		this.febeExtensionsList[this.febeExtBuName] = item;
	}
	return true;
},

febeWriteResults: function (){
	this.febeInitEssentials();
	this.febeVerifyBackup();
	
  // Get results template 
	let resultsTemplate=this.getReportTemplate("FEBEresultsTemplate.html");

	// Put the template into a DOM parser
	let domParser = Cc["@mozilla.org/xmlextras/domparser;1"].
		createInstance(Ci.nsIDOMParser);
	let doc = domParser.parseFromString(resultsTemplate, "text/html");
	doc.title = this.febeMsg[108];
	doc.dir = this.febePrefs.getCharPref("extensions.febe.orientation");	// Orientation ('ltr', 'rtl')
	
	// Locking errors
	let errCnt = 0, lockERR = false;
	for(let i in this.selectedItemsList){
		let item = this.selectedItemsList[i];
		if(item.error){
			let msgNum = 0;
			if(i == 'permissions') msgNum = 115;
			if(i == 'bookmarks') msgNum = 30;
			if(i == 'preferences') msgNum = 31;
			if(i == 'cookies') msgNum = 32;
			if(i == 'userChrome') msgNum = 60;
			if(i == 'usernamePasswords') msgNum = 62;
			if(i == 'searchPlugins') msgNum = 64;
			if(i == 'browserHistory') msgNum = 65;
			if(i == 'formfillHistory') msgNum = 66;
			if(i == 'userDefinedBackups') msgNum = 67;
			let msg = this.febeMsg[msgNum]+" "+item.error;
			this.febeErrorList.push(msg);		
			errCnt++;
			lockERR = true;
		}
	}
			
	// Sort the items
	let febeExtKey = [];
	let febeThemeKey = [];
	let febeSkippedKey = [];
	let febeAdditionalKey = [];
	let numExt = 0;
	let numThemes = 0;
	let numSkipped = 0;
	let numAdditional = 0;
	let numErrors = this.febeErrorList.length;
		
	for(let i in this.febeExtensionsList){
		febeExtKey.push(i);
		numExt++;
	};

	for(let i in this.febeThemesList){
		febeThemeKey.push(i);
		numThemes++;
	};
	
	for(let i in this.febeSkippedList){
		let item = this.febeSkippedList[i];
		let key = item.name+","+i;	// Sort by name, guid
		febeSkippedKey.push(key);
		numSkipped++;
	};
	
	for(let i in this.febeAdditionalList){
		febeAdditionalKey.push(i);
		numAdditional++;
	};
		
  function caseInsensitive(a, b) {
		return a.toLowerCase().localeCompare(b.toLowerCase());  
	};
	
	febeExtKey.sort(caseInsensitive);
	febeThemeKey.sort(caseInsensitive);
	febeSkippedKey.sort(caseInsensitive);
	febeAdditionalKey.sort(caseInsensitive);
	this.febeErrorList.sort(caseInsensitive);

	let total = numExt + numThemes + numAdditional;
	
// Create new content

	// Local variables
	let re = new RegExp("\\\\", "g");
	let warnCnt = 0;
	let resultsPageURL = "";
	let txt, elm, txtNode, url, link, table, tbody, msg, lineItem, tmp, p, key, item, tbl, div, tot, span, cnt;

	// Element palette
	let br = document.createElementNS(this.febeNamespace,'br');
	let cellElm = document.createElementNS(this.febeNamespace,'td');
	let cellStyle = 'text-align: center;';
	let imgElm = document.createElementNS(this.febeNamespace,'img');
	let pElm = document.createElementNS(this.febeNamespace,'p');
	let rowElm = document.createElementNS(this.febeNamespace,'tr');
	let spanElm = document.createElementNS(this.febeNamespace,'span');
	let tableElm = document.createElementNS(this.febeNamespace,'table');
	let theadElm = document.createElementNS(this.febeNamespace,'thead');
	let thElm = document.createElementNS(this.febeNamespace,'th');
	let tfootElm = document.createElementNS(this.febeNamespace,'tfoot');
	let tbodyElm = document.createElementNS(this.febeNamespace,'tbody');
	let trElm = document.createElementNS(this.febeNamespace,'tr');
	let tdElm = document.createElementNS(this.febeNamespace,'td');
	let anchorElm = document.createElementNS(this.febeNamespace,'a');
	let mdash = " "+String.fromCharCode(8212)+" ";
	let body = doc.body;
	
	// Calculate time it took to complete backup
	let dte = new Date();
	let febeStopTime = dte.getTime();
	let buStartTime = this.febePrefs.getCharPref("extensions.febe.buStartTime");
	let febeStartTime = buStartTime;
	let elapsedTime = (febeStopTime - febeStartTime)/1000;
	this.febeUpdateProgressWindow(this.febeMsg[77],false);
		
	// Report title
	elm = doc.getElementById("reportheading");
	txt = document.createTextNode(this.febeMsg[109]);
	elm.appendChild(txt);
	
	// 'Detail' or 'Summary' format
	let detail = ((this.febePrefs.getCharPref("extensions.febe.resultsFormat")) == "detail" ? true : false);
	if(detail){
		txt = document.createTextNode(this.febeMsg[323]);
	}else{
		txt = document.createTextNode(this.febeMsg[324]);
	}
	let para = pElm.cloneNode(false);
	para.appendChild(txt);	
	para.appendChild(br.cloneNode(false));
	
	// Version
	txt = document.createTextNode(this.febeMsg[49]+" "+this.febePrefs.getCharPref("extensions.febe.currentversion"));
	para.appendChild(txt);	
	para.appendChild(br.cloneNode(false));
	
	// Author
	txt = document.createTextNode(this.febeMsg[180]+" Chuck Baker");
	para.appendChild(txt);	
	para.appendChild(br.cloneNode(false));
	elm = doc.getElementById("headingInfo");
	elm.appendChild(para);

	// Backup start date
	elm = doc.getElementById("budate");
	txt = document.createTextNode(this.febeLocalizedDate(buStartTime));
	elm.appendChild(txt);

	// Backup type ('Full profile', 'Selective', 'Alternate', or 'Both')
	elm = doc.getElementById("butype");
	txt = this.febeMsg[285]+" "+this.febeGetUnicharPref("extensions.febe.lastbackup.type.desc");
	
	//febeBackupRunType: 1='Manual', 2='On startup', 3='On shutdown', 4='Scheduled, 5='Reminded', 6='Delayed'
	let buType = [];	
	buType.push(this.febeMsg[382]);
	buType.push(this.febeMsg[383]);
	buType.push(this.febeMsg[384]);
	buType.push(this.febeMsg[385]);
	buType.push(this.febeMsg[386]);
	buType.push(this.febeMsg[425]);

	txt += ", "+buType[this.febeBackupRunType-1];
	
	// Asynchronous or synchronous
	txt += ", "+(this.febeRunAsync ? this.febeMsg[430] : this.febeMsg[431]);
	
	txtNode = document.createTextNode(txt);
	elm.appendChild(txtNode);
	
	// Backup location
	elm = doc.getElementById("bulocation");
	txt = document.createTextNode(this.febeMsg[15]+" ");
	let prefix = "file:///";
	if(this.febeExBuDir.substring(0,2) == "\\\\"){prefix = "file:///"}	// add extra "\" for networked drive
	url = prefix+this.febeExBuDir.replace(re,"/");
	link = anchorElm.cloneNode(false);
	link.href = url;
	link.textContent = this.febeExBuDir;
	elm.appendChild(txt);	
	elm.appendChild(link);
	
	// Backup processing time
	elm = doc.getElementById("processingtime");
	txt = document.createTextNode(this.febeMsg[284].replace("%SECONDS%",elapsedTime));
	elm.appendChild(txt);
	
	// Other backups
	elm = doc.getElementById("otherbackups");
	if(this.febeDestDirs.length >1){
		txt = document.createTextNode(this.febeMsg[501]);
		elm.appendChild(txt);
		elm.appendChild(br.cloneNode(false));

		for(let d=1; d<this.febeDestDirs.length; d++){
			let item = this.febeDestDirs[d];
			span = spanElm.cloneNode(false);
			span.className = "lineitem";
			let tmp = this.febeMsg[502];
			tmp = tmp.replace("%NAME%","'"+item.name+"'");
			tmp = tmp.replace("%LOCATION%","'"+item.dir+"'");
			txt = document.createTextNode(tmp);
			span.appendChild(txt);
			elm.appendChild(span);
			elm.appendChild(br.cloneNode(false));
		}
		elm.appendChild(br.cloneNode(false));
	}

	// External addons data used
	this.febeAddonDataExternallyLoaded = FEBEstorage.getItem("febeAddonDataExternallyLoaded", this.febeAddonDataExternallyLoaded);

	if(this.febeAddonDataExternallyLoaded.value && this.febeBUtype != "profile"){
		elm = doc.getElementById("externaldataused");
		span = spanElm.cloneNode(false);
		span.className = "note";
		txt = document.createTextNode(this.febeMsg[498].replace("%DATE%",this.febeAddonDataExternallyLoaded.date));
		span.appendChild(txt);
		elm.appendChild(span);
		elm.appendChild(br.cloneNode(false));
		elm.appendChild(br.cloneNode(false));
	}
	
	// Errors
	if(numErrors != 0){
		elm = doc.getElementById("errors");
		txt = document.createTextNode(this.febeMsg[112].replace("%NUM%",numErrors));
		elm.appendChild(txt);
		cnt = 0;			
		table = tableElm.cloneNode(false);
		table.className = "lineitem";	
		tbody = tbodyElm.cloneNode(false);
		for(let i=0; i<numErrors; i++){
			cnt++;
			msg = this.febeErrorList[i];
			lineItem = buildLineItem3(cnt,msg);	
			tbody.appendChild(lineItem);
		}
		if(lockERR){
			msg = "For more information and a possible fix for locking errors, see ";
			txt = document.createTextNode(msg);
			tr = trElm.cloneNode(false);
			td = tdElm.cloneNode(false);
			td.colSpan = 2;
			td.className = "errLink";
			url = 'http://www.customsoftwareconsult.com/forum/viewtopic.php?f=5&t=4955';
			link = anchorElm.cloneNode(false);
			link.href = url;
			link.textContent = 'this thread in the support forum.';
			td.appendChild(txt);	
			td.appendChild(link);			
			tr.appendChild(td);
			tbody.appendChild(tr);
		}
		table.appendChild(tbody);
		elm.appendChild(table);
		elm.appendChild(br.cloneNode(false));
	}
	

	
	// Skipped (Ignored, Global, Proxy items)
	if(numSkipped != 0){
		elm = doc.getElementById("skippeditems");
		txt = document.createTextNode(this.febeMsg[353].replace("%skipped%",numSkipped));
		elm.appendChild(txt);

		if(detail == true){
			cnt = 0;			
			table = tableElm.cloneNode(false);
			table.className = "lineitem";
						
			tbody = tbodyElm.cloneNode(false);
			for(let i=0; i<numSkipped; i++){
				cnt++;
				tmp = febeSkippedKey[i];
				p = tmp.indexOf(",")+1; 
				key = tmp.substr(p);
				item = this.febeSkippedList[key];
				lineItem = buildLineItem(cnt,item);
				tbody.appendChild(lineItem);
			}

			table.appendChild(tbody);
			elm.appendChild(table);
			elm.appendChild(br.cloneNode(false));
		}
	}
	
	// Extensions
	elm = doc.getElementById("extensions");
	tmp = this.febeMsg[14]+" "+this.febeMsg[13].replace('%NUM%',numExt);

	if(this.febeDisabledCount != 0){tmp += mdash+this.febeMsg[107].replace("%num%",this.febeDisabledCount)}
	if(this.febePendingCount != 0){tmp += mdash+this.febeMsg[278].replace("%num%",this.febePendingCount)}

	txt = document.createTextNode(tmp);
	elm.appendChild(txt);
	
	if(detail == true){
		cnt = 0;			
		table = tableElm.cloneNode(false);
		table.className = "lineitem";
					
		tbody = tbodyElm.cloneNode(false);
		for(let i=0; i<numExt; i++){
			cnt++;
			key = febeExtKey[i];
			item = this.febeExtensionsList[key];
			lineItem = buildLineItem(cnt,item);
			tbody.appendChild(lineItem);
		}
		table.appendChild(tbody);
		elm.appendChild(table);
		elm.appendChild(br.cloneNode(false));
	}
	
	// Themes
	elm = doc.getElementById("themes");
	tmp = this.febeMsg[16]+" "+this.febeMsg[13].replace('%NUM%',numThemes);

	txt = document.createTextNode(tmp);
	elm.appendChild(txt);
	
	if(detail == true){
		cnt = 0;			
		table = tableElm.cloneNode(false);
		table.className = "lineitem";
					
		tbody = tbodyElm.cloneNode(false);
		for(let i=0; i<numThemes; i++){
			cnt++;
			key = febeThemeKey[i];
			item = this.febeThemesList[key];
			lineItem = buildLineItem(cnt,item);
			tbody.appendChild(lineItem);
		}
		table.appendChild(tbody);
		elm.appendChild(table);
		elm.appendChild(br.cloneNode(false));
	}
	
	// Additional items
	elm = doc.getElementById("additional");
	elm.id = "additionalDiv";
	cnt = 0;			
	table = tableElm.cloneNode(false);
	table.className = "lineitem";
				
	tbody = tbodyElm.cloneNode(false);
	for(let i=0; i<numAdditional; i++){
		cnt++;
		key = febeAdditionalKey[i];
		item = this.febeAdditionalList[key];
		lineItem = buildLineItem2(cnt,item);
		tbody.appendChild(lineItem);
	}
	table.appendChild(tbody);
	elm.appendChild(table);

	table.appendChild(tbody);
	elm.appendChild(table);
	elm.appendChild(br.cloneNode(false));
	
	// Additional items total
	tbl = doc.getElementById("additionalDiv");
	div = tbl.parentNode;
	txt = document.createTextNode(this.febeMsg[415]+" "+cnt);
	div.insertBefore(txt,tbl);
		
	// Report totals
	tot = numAdditional + numExt + numThemes;
	elm = doc.getElementById("totcnt");

	tmp = this.febeMsg[416].replace('%TOT%',tot);
	tmp = tmp.replace('%EXT%',numExt);
	tmp = tmp.replace('%THEME%',numThemes);
	tmp = tmp.replace('%ADDITIONAL%',numAdditional);
	txt = document.createTextNode(tmp);
	elm.appendChild(txt);
	elm.appendChild(br.cloneNode(false));
	
	// Homepage
	elm = doc.getElementById("homepagemsg");
	span = spanElm.cloneNode(false);
	txt = document.createTextNode(this.febeMsg[110]+" ");
	span.appendChild(txt);
	
	link = anchorElm.cloneNode(false);
	link.href = "http://softwarebychuck.com/febe/febe.html";
	link.textContent = this.febeMsg[111];
	span.appendChild(link);
	elm.appendChild(span);
	elm.appendChild(br.cloneNode(false));
	elm.appendChild(br.cloneNode(false));
	
	// Useragent
	elm = doc.getElementById("useragent");
	tmp = this.febeMsg[191] + " " + navigator.userAgent;
	span = spanElm.cloneNode(false);
	span.className = "useragent";
	txt = document.createTextNode(tmp);
	span.appendChild(txt);
	elm.appendChild(span);
	
	function buildLineItem(cnt,item){
		let tr, td, num, img, link, span, name, ver, desc;
		tr = trElm.cloneNode(false);
		
		// Count
		td = tdElm.cloneNode(false);
		td.className = "num";
		num = document.createTextNode(cnt+".");
		td.appendChild(num);
		tr.appendChild(td);
		
		// Icon
		td = tdElm.cloneNode(false);
		td.className = "top";
		img = imgElm.cloneNode(false);
		img.className = "icon";
		img.src = item.iconURL;
		td.appendChild(img);
		tr.appendChild(td);
		
		// Name/link
		td = tdElm.cloneNode(false);
		if(item.homepageURL != null){
			link = anchorElm.cloneNode(false);
			link.href = item.homepageURL;
			link.textContent = item.name;
			link.className = "itemname";
			if(item.userDisabled) link.className += " disabled";
			if(typeof item.tooltipdata == undefined) item.tooltipdata = "";
			link.setAttribute('data-tooltipdata',item.tooltipdata);
			td.appendChild(link);
		}else{
			span = spanElm.cloneNode(false);
			span.className = "itemname";
			if(item.userDisabled) span.className += " disabled";
			name = document.createTextNode(item.name);
			span.appendChild(name);
			if(typeof item.tooltipdata === undefined) item.tooltipdata = "";
			span.setAttribute('data-tooltipdata',item.tooltipdata);
			td.appendChild(span);
		}	
		
		// Version
		span = spanElm.cloneNode(false);
		span.className = "ver";
		ver = document.createTextNode(" (v"+item.version+")");
		span.appendChild(ver);
		if(item.version != "") td.appendChild(span);
		
		// Description				
		span = spanElm.cloneNode(false);
		span.className = "description";
		txt = "";
		if(item.isPersona) txt = mdash+FEBE.febeMsg[340];
		txt += mdash+item.desc;
		desc = document.createTextNode(txt);
		span.appendChild(desc);
		td.appendChild(span);
		
		tr.appendChild(td);
		return tr;
	}
	
	function buildLineItem2(cnt,item){
		let label = item.desc;
		let fname = item.fname;
		let tr = trElm.cloneNode(false);
		let td, num, span;

		// Count
		td = tdElm.cloneNode(false);
		td.className = "num";
		num = document.createTextNode(cnt+".");
		td.appendChild(num);
		tr.appendChild(td);
		
		// Label and fname
		td = tdElm.cloneNode(false);
		txt = document.createTextNode(label+" ");
		td.appendChild(txt);
		span = spanElm.cloneNode(false);
		span.className = "itemname";
		txt = document.createTextNode(fname);
		span.appendChild(txt);
		td.appendChild(span);
			
		tr.appendChild(td);
		return tr;
	}

	function buildLineItem3(cnt,msg){
		let td, num;
		let tr = trElm.cloneNode(false);
		
		// Count
		td = tdElm.cloneNode(false);
		td.className = "num";
		num = document.createTextNode(cnt+".");
		td.appendChild(num);
		tr.appendChild(td);
		
		// Message
		td = tdElm.cloneNode(false);
		td.className = "err";
		txt = document.createTextNode(msg);
		td.appendChild(txt);			
		tr.appendChild(td);
		return tr;
	}

  // Write content to results page
	let febeResultsPage = this.febeProfDir.clone();
	febeResultsPage.append("FEBEresults.html");
	
	let resultsFile = Cc["@mozilla.org/network/file-output-stream;1"].createInstance(Ci.nsIFileOutputStream);
	resultsFile.init(febeResultsPage, 0x02 | 0x08 | 0x20, 0x1ED, 0); // write, create, truncate
	let pageSource = doc.documentElement.outerHTML;
	
	let charset = "UTF-8";
	let os = Cc["@mozilla.org/intl/converter-output-stream;1"].createInstance(Ci.nsIConverterOutputStream);

	os.init(resultsFile, charset, 4096, 0x0000);
	os.writeString(pageSource);
	os.close();
	
  // Display the results page in the controlling window
	this.febeScheduleController();
	if(this.febeDispResults)this.febeControllerWindow.FEBE.febeOpenResultsPage(febeResultsPage.path);
	this.febeSetUnicharPref("extensions.febe.lastbackup.resultspage",febeResultsPage.path);
	
	if(this.febeSaveResults){
	  // Save results page with backup , ex: 'Results - FEBE 2013 08-13 05.00.23.html'
		let ts = this.febePrefs.getCharPref("extensions.febe.timestamp.format");
		let timestamp = this.febeMakeTimestampName(ts, buStartTime);
		let dName = this.febeMsg[76]+" - "+timestamp+".html"; 
		this.febeUpdateProgressWindow(dName,true);
		this.febeBuDesDir = this.febeGetUnicharPref("extensions.febe.curBUdir");
		this.febeCopyFile(febeResultsPage.path,this.febeBuDesDir,dName);
		for(let i=0; i<this.febeDestDirs.length; i++){
			this.febeCopyFile(febeResultsPage.path,this.febeDestDirs[i].dir,dName);
		}
		
		// Save pointer to results page
		let aFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
		aFile.initWithPath(this.febeBuDesDir);
		aFile.append(dName);
		if(aFile.exists()) resultsPageURL = aFile.path;
	}
	this.febeSetUnicharPref("extensions.febe.lastbackupresultspageurl",resultsPageURL);
	
	// Set last backup type in preferences
	let lastbutype;
	if(this.febeBuProfile == false){
		lastbutype = "selective"
	}else{
		lastbutype = "profile";
	}
	this.febePrefs.setCharPref("extensions.febe.lastbackup.type", lastbutype);
	
	// Write backup history
	let historyObj = new Object;
	historyObj.date = this.febeLocalizedDate(buStartTime);
	historyObj.type = this.febeGetUnicharPref("extensions.febe.lastbackup.type.desc");
	historyObj.time = elapsedTime;
	historyObj.runtype = this.febeBackupRunType;
	historyObj.resultsurl = this.febeExBuDir;
	historyObj.resultspage = resultsPageURL;
	this.febeDataFile = Cc["@mozilla.org/file/directory_service;1"].getService(Ci.nsIProperties).get("ProfD", Ci.nsIFile);
	this.febeDataFile.append(this.FEBEBUHISTORYFILE);
	let fos = Cc["@mozilla.org/network/file-output-stream;1"].createInstance(Ci.nsIFileOutputStream);
	fos.init(this.febeDataFile, 0x08 | 0x10 | 0x04, 0x1C0, 0); // Create, append, read/write
	let cos = Cc["@mozilla.org/intl/converter-output-stream;1"].createInstance(Ci.nsIConverterOutputStream);
	cos.init(fos, "UTF-8", 0, 0x0000);
	let jstr = JSON.stringify(historyObj);
	cos.writeString(jstr+"\n");
	cos.close();

	// Play sound
	if(errCnt == 0){
		this.febePlaySound("busuccess");
	}else{
		this.febePlaySound("bufailure");
	}	
	return true;
},	

febeWarn: function (){
  // Display scheduled backup warning in statusbar
	let win = FEBE.febeControllerWindow;
	if(!win.FEBE.febeIsScheduleController) {return true;}
	if(win.FEBE.febeHideIcons){return true;}
	let statusbar = win.document.getElementById("febestatusbar");
	if(statusbar) statusbar.setAttribute('status',"warning");
	win.FEBE.febePlaySound("warning");
	for(let i=10000; i<= 40000; i += 10000){
		let to = new FEBE.febeSetTimeoutObj;
		to.PID = win.setTimeout(
			function(){
				FEBE.febeControllerWindow.FEBE.febePlayWarning();
			},i
		)
		to.Process = 'FEBE play warning sound';
		to.Started = win.FEBE.febeNow();
		to.Wait = i;
		win.FEBE.febeSetTimeoutIDs.push(to);
	}
	return true;
},

febePlayWarning: function (){
	FEBE.febeControllerWindow.FEBE.febePlaySound("warning");
},

getReportTemplate: function (fName){
	// Returns the contents (text) of fName
	this.febeGetPrefs();
	let dFile = FEBE.febeInstallDirectory.clone();
	if (!dFile) return false;
	dFile.append("chrome");
	dFile.append("content");
	dFile.append(fName);
	let fis = Cc["@mozilla.org/network/file-input-stream;1"].createInstance(Ci.nsIFileInputStream);
	fis.init(dFile, 0x01, 0x124, 0);
	fis.QueryInterface(Ci.nsILineInputStream);
	let cis = Cc["@mozilla.org/intl/converter-input-stream;1"].createInstance(Ci.nsIConverterInputStream);
	cis.init(fis,"UTF-8", 0, 0x0000);
	let lis = cis.QueryInterface(Ci.nsIUnicharLineInputStream);
	let line = {}, hasmore;	
	let data, content = "";
	do {
		hasmore = lis.readLine(line);
		data = line.value;
		content += data+"\n";
	} while(hasmore);
	cis.close();
	fis.close();
	return content;
},

febePickFiles: function (filter,msgNum){
  // Select extension/themes to install
	const nsIFilePicker = Ci.nsIFilePicker;
	let fp = Cc["@mozilla.org/filepicker;1"].createInstance(nsIFilePicker);
	fp.init(window, this.febeMsg[msgNum], nsIFilePicker.modeOpenMultiple);
	fp.appendFilter(filter,filter);
	
	// Set the default directory to the backup destination directory
	let prefName = "extensions.febe.extBUdir";
	if(!this.febePrefs.prefHasUserValue(prefName)){
		this.febeGetPrefs();
		if(this.febePlatform == 1){this.febeExBuDir = "C:\\";}
		if(this.febePlatform == 2){this.febeExBuDir = "/";}
		if(this.febePlatform == 3){this.febeExBuDir = "/";}
	}else{
		this.febeExBuDir = this.febeGetUnicharPref(prefName);
	}
	
	if(this.febeExBuDir != ""){
		let aDir = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
		aDir.initWithPath(this.febeExBuDir);
		fp.displayDirectory = aDir;
	}

	let rv = fp.show();
	this.febeETinstall = [];
	if (rv == nsIFilePicker.returnOK){
		let files = fp.files;
		while(files.hasMoreElements()) {
			let file = files.getNext()
				.QueryInterface(Ci.nsIFile);
			let obj = {};
			obj.Name = file.leafName;
			obj.Path = file.path;
			obj.nsFile = file
			this.febeETinstall.push(obj);
		}
	}

	return true;
},

febePickRestoreFile: function (filter,msgNum){
  // Select a file to restore
	const nsIFilePicker = Ci.nsIFilePicker;
	let fp = Cc["@mozilla.org/filepicker;1"].createInstance(nsIFilePicker);
	fp.init(window, this.febeMsg[msgNum], nsIFilePicker.modeOpen);
	this.febePlatform = this.febeGetPlatform();
	
	// Fix for mac - Can't handle strings like "bookmarks*.json". - Change to "*.json"
	if(this.febePlatform == 3){
		let n = filter.indexOf("*");
		filter = filter.substr(n);
	}
	fp.appendFilter(filter,filter);
	// Set the default directory to the backup destination directory
	let prefName = "extensions.febe.extBUdir";
	if(!this.febePrefs.prefHasUserValue(prefName)){
		this.febeGetPrefs();
		if(this.febePlatform == 1){this.febeExBuDir = "C:\\";}
		if(this.febePlatform == 2){this.febeExBuDir = "/";}
		if(this.febePlatform == 3){this.febeExBuDir = "/";}
	}else{
		this.febeExBuDir = this.febeGetUnicharPref(prefName);
	}
	if(this.febeExBuDir != ""){
		let aDir = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
		aDir.initWithPath(this.febeExBuDir);
		fp.displayDirectory = aDir;
	}

	let rv = fp.show();
	if (rv == nsIFilePicker.returnOK){
		rv = fp.file;
		this.febePathName = rv.path;
		this.febePrName = this.febePfName = rv.leafName;
		this.febePfParent = rv.parent.path;
		if(rv.fileSize == 0){
			var tmp = FEBE.febeStyle.purpleBold+this.febeMsg[545].replace("%FILE%","'"+this.febePfName+"'")+"\n";
			tmp += FEBE.febeStyle.orangeredBold+this.febeMsg[546];
			this.febeAlert(tmp);
			return false;
		}
		return true;
	}
	return false;
},

febePickFile: function (filter,msgNum,dfltDir){
  // Select a file to restore
	const nsIFilePicker = Ci.nsIFilePicker;
	let fp = Cc["@mozilla.org/filepicker;1"].createInstance(nsIFilePicker);
	fp.init(window, this.febeMsg[msgNum], nsIFilePicker.modeOpen);
	
	// Fix for mac - Can't handle strings like "bookmarks*.json". - Change to "*.json"
	if(this.febePlatform == 3){
		let n = filter.indexOf("*");
		filter = filter.substr(n);
	}
	
	fp.appendFilter(filter,filter);
	
	if(dfltDir != ""){
		let aDir = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
		aDir.initWithPath(dfltDir);
		fp.displayDirectory = aDir;
	}
	
	let rv = fp.show();
	if (rv == nsIFilePicker.returnOK){
		return fp.file.path;
	}
	return false;
},

febePickDir: function (dfltDir,msgNum){
  // Select a directory
	const nsIFilePicker = Ci.nsIFilePicker;
	let fp = Cc["@mozilla.org/filepicker;1"].createInstance(nsIFilePicker);
	fp.init(window, this.febeMsg[msgNum], nsIFilePicker.modeGetFolder);
	fp.appendFilters(nsIFilePicker.filterAll | nsIFilePicker.filterText);

    // Set default directory to current backup directory
	if(dfltDir != ""){
		let dd = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
		try{
			dd.initWithPath(dfltDir);
			fp.displayDirectory = dd;
		}catch(err){;;}
	}
	let rv = fp.show();
	if (rv == nsIFilePicker.returnOK){
		return fp.file.path;
	}else{
		return false;
	}
},

febeConfirmRestore: function (msgNum,bDate,restart,isProfile){
	FEBE.setStyles();
	if(!FEBE.febeMsg[0]) FEBE.febeGetPrefs();
	let platform = FEBE.febeGetPlatform();
	if(platform == 3){return true;}	// Mac can't handle modal alerts properly, so just assume they clicked "OK"
	let style = FEBE.febeStyle.orangered14;
	let tmp = style+FEBE.febeMsg[36] +"\n";
	tmp += FEBE.febeMsg[msgNum] + "\n";
	if(bDate != ""){tmp += FEBE.febeLocalizedDate(bDate) + "\n";}
	tmp += "\n";
	if(bDate != ""){tmp += FEBE.febeMsg[45] + "\n";} 
	tmp += FEBE.febeMsg[40];
	if(isProfile){
		let profName = FEBE.febeProfileWin.getElementById("febeSelectedProfileText").value;
		let results = profName.match(/^profileFx(.*)\(FEBE.*/);
		if(results.length > 1){
			let profVer = results[1]; 
			if(profVer != FEBE.fxVer){
				style = FEBE.febeStyle.orangeredItalic;
				tmp += "\n\n"+style+FEBE.febeMsg[410].replace('%PROFVER%',profVer);
				tmp += "\n"+style+FEBE.febeMsg[411].replace('%CURVER%',FEBE.fxVer);
				tmp += "\n"+style+FEBE.febeMsg[412]+"\n";
			}
		}
	}
	tmp += "\n" + FEBE.febeMsg[41];
	if(restart){tmp += "\n" + style + FEBE.febeMsg[129] + "\n"};
	return FEBE.febeConfirm(tmp);
},

febeClearDir: function (){
	// Clear destination directory
	FEBE.setStyles();
	this.febeBackupAborted = false;
  if(this.febeClearDestDir == false){return true;}
	let entries = this.febeBuDesDir.directoryEntries;
	let numFiles = 0;
	let numDirs = 0;
	while(entries.hasMoreElements()){
		let entry = entries.getNext();
		entry.QueryInterface(Ci.nsIFile);
		if(entry.isFile()){numFiles++;}
		if(entry.isDirectory()){numDirs++;}
	}

	// Warn before delete?
	let clearWarning = this.febePrefs.getBoolPref("extensions.febe.clearwarning");	
	if((clearWarning) && numFiles != 0){
		let promptService = Cc["@mozilla.org/embedcomp/prompt-service;1"].getService(Ci.nsIPromptService);
		let checkResult = {};

		let x1 = new RegExp("x1");
		let x2 = new RegExp("x2");
		let tmp = this.febeMsg[99];
		tmp = tmp.replace(x1,numFiles);
		tmp = tmp.replace(x2,numDirs);
		tmp += "\n"+this.febeMsg[100];
	
		let OK = FEBE.febeConfirm(tmp);
		if(!OK){
			this.febeAlert(this.febeMsg[351]);
			this.febeBackupAborted = true;
			return false;
		}
	}
	
	entries = this.febeBuDesDir.directoryEntries;
	while(entries.hasMoreElements()){
		let entry = entries.getNext();
		entry.QueryInterface(Ci.nsIFile);
		if(entry.isFile()){entry.remove(false);}
	}
	return true;
},

febeDosHappy: function (aString){
	// Mask out DOS incompatible characters
	if(this.febePlatform != 1){return aString;}
	let badList = "\\/:*\"<>|";
	for (let i = 0; i < aString.length; i++){	
		let c = aString.charAt(i);
		let OK = true;
		for (let j = 0; j < badList.length; j++){
			let tChar = badList.charAt(j);
			if(c == tChar){
				OK = false;
				break;
			}
		}
		if(OK == false){aString = aString.replace(c,"_");}
	}
	return aString;
},

febeSetStatusbarMsg: function (){
  // This doesn't work - statusbar never updates
	return true;
},

getProgressWinPointer: function(){
	let wm = Cc["@mozilla.org/appshell/window-mediator;1"].getService(Ci.nsIWindowMediator);  
	return wm.getMostRecentWindow("febe:progress"); 
},

// ------------------ Backup Functions --------------------

febeCreateBackupName: function(name,ext){
	this.febeVersion = this.febeGetVersion();
	if(this.febeProfName == "") this.febeProfName = FEBEstorage.getItem("febeProfName", this.febeProfName);
	let buName = name+"Fx"+this.fxVer+"(FEBE"+this.febeVersion+"){"+this.febeProfName+"}"+ext;
	return buName;
},

febeBackupExtensions: function (){
	this.febeAddons = FEBEstorage.getItem("febeAddons","");
	if(!this.febeBuExtensions && !this.febeBuThemes) return true;
	this.febeProgressWin = this.getProgressWinPointer();
	for(let i in this.febeAddons){
		let item = this.febeAddons[i];
		if(item.type != "extension" && item.type != "theme") continue;
		if(item.isPersona == true) continue;			
		if(item.type == "theme" && this.febeBuThemes == false) continue;
		if(item.type == "extension" && this.febeBuExtensions == false) continue;
		if(item.isValid == false) continue;
		if(this.febeIgnoreDisabled == true){
			if(item.userDisabled == true){
				this.febeDisabledCount++;
				continue;
			}
		}	
		if(!item.isEligibleForBackup) continue;		
		if(item.guid == this.FEBE_GUID){this.febeFEBEbackedUp = true;}
		
		// OK, let's back it up ...
		this.febeErr = "";
		this.febeUpdateProgressWindow(item.buname,true);
		for(let d=0; d<this.febeDestDirs.length; d++){
			if(item.isXpi == true){	// Perform a straight copy for xpis
				this.febeCopyFile(item.installlocation,this.febeDestDirs[d].dir,item.buname);
			}else{
				this.febeZip(item.installlocation,this.febeDestDirs[d].dir,item.buname,false,false,this.febeRunAsync);
				if(FEBE.febeErr == "abort"){
					let wm = Cc["@mozilla.org/appshell/window-mediator;1"].getService(Ci.nsIWindowMediator);  
					let win = wm.getMostRecentWindow("febe:progress"); 
					if(win) win.close();
					return false;
				}
				if(this.febeErr == "skip"){
					item.skipped = true;
					let tmp = this.febeMsg[18].replace("%ITEM%",item.name);
					if(FEBE.febeMainWindow.FEBE.febeAddedToIgnoreList.indexOf(item.guid) != -1) tmp += " "+this.febeMsg[529];
					this.febeErrorList.push(tmp);
				}
			}
			if(item.type == "theme"){
				this.febeThemesList[item.buname] = item;
			}else{
				this.febeExtensionsList[item.buname] = item;
			}	
		}
	}
	return true;
},

febeBackupPersonas: function (){
	febeDebug("Processing personas - Include in backup? "+this.febeBuThemes);
	if(this.febeBuThemes == false){return true;}
	let prefName = "lightweightThemes.usedThemes";
	if(!this.febePrefs.prefHasUserValue(prefName)) return true;
	let personas = [];
	let personasInstalled = JSON.parse(this.febeGetUnicharPref(prefName));
	for(let i in personasInstalled){
		let pId = personasInstalled[i].id + "@personas.mozilla.org";
		personas[pId] = personasInstalled[i];
	}
	for(let i in this.febeAddons){
		let item = this.febeAddons[i];
		if(item.isValid == false) continue;
		if(item.ignore == true) continue;
		if(item.isPersona == false) continue;
		if(this.febeIgnoreDisabled == true){	// Is addon disabled?
			if(item.userDisabled == true){
				this.febeDisabledCount++;
				continue;
			}
		}	

		// Backup persona to .json file
		let dFile, fos, cos;
		
		dFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
		this.febeBuDesDir = this.febeGetUnicharPref("extensions.febe.curBUdir");
		dFile.initWithPath(this.febeBuDesDir);
		dFile.append(item.buname);
		fos = Cc["@mozilla.org/network/file-output-stream;1"].createInstance(Ci.nsIFileOutputStream);
		fos.init(dFile, 0x02 | 0x08 | 0x20, 0x1FF, 0); // write, create, truncate - 0x1ED = 0755, 0x1FF = 0777
		
		cos = Cc["@mozilla.org/intl/converter-output-stream;1"].createInstance(Ci.nsIConverterOutputStream);
		cos.init(fos, "UTF-8", 0, 0x0000);
		
		let jstr = JSON.stringify(personas[item.guid]);
		cos.writeString("["+jstr+"]\n"); 
		cos.close();
		fos.close();
		
		this.febeThemesList[item.buname] = item;
		this.febeUpdateProgressWindow(item.buname,true);
		for(let i=1; i<this.febeDestDirs.length; i++){
			this.febeCopyFile(dFile.path,this.febeDestDirs[i].dir,item.buname);
		}
	}
	
	// Backup lightweight theme preference to .json file (i.e., All personas)
	let dFile, fos, cos;
	let item = {};
	item.guid = "";
	item.type = "theme";
	item.name = "LightweightThemes";
	item.version = "";
	item.buname = "AllInstalledLightweightThemes.personas.json";
	item.desc = this.febeMsg[338];
	item.homepageURL = "https://addons.mozilla.org/en-US/firefox/personas/";
	item.userDisabled = false;
	item.isCompatible = true;
	item.iconURL = "chrome://febe/skin/xpinstallItemGeneric.png";
	item.installlocation = "";
	item.ignore = true;
	item.isValid = false;
	item.isPersona = true;
	
	dFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
	this.febeBuDesDir = this.febeGetUnicharPref("extensions.febe.curBUdir");
	dFile.initWithPath(this.febeBuDesDir);
	dFile.append(item.buname);

	fos = Cc["@mozilla.org/network/file-output-stream;1"].createInstance(Ci.nsIFileOutputStream);
	fos.init(dFile, 0x02 | 0x08 | 0x20, 0x1ED, 0); // write, create, truncate
	
	cos = Cc["@mozilla.org/intl/converter-output-stream;1"].createInstance(Ci.nsIConverterOutputStream);
	cos.init(fos, "UTF-8", 0, 0x0000);
	
	let jstr = JSON.stringify(personasInstalled);
	cos.writeString(jstr); 

	cos.close();
	fos.close();
	
	this.febeThemesList[item.buname] = item;
	this.febeUpdateProgressWindow(item.buname,true);
	for(let i=1; i<this.febeDestDirs.length; i++){
		this.febeCopyFile(dFile.path,this.febeDestDirs[i].dir,item.buname);
	}
	febeDebug("Done processing personas");
	return true;
},

febeBackupBookmarksJSON: function (){
	febeDebug("Processing bookmarksJSON - Include in backup? "+this.febeBuBookmarksJSON);
	febeDebug("bookmarksJSON exist? - "+FEBE.selectedItemsList['bookmarks'].exists)
	febeDebug("bookmarksJSON error: "+FEBE.selectedItemsList['bookmarks'].error);
	
	if (!this.febeBuBookmarksJSON){return true;}
	if(!FEBE.selectedItemsList['bookmarks'].exists) return true;
	if(FEBE.selectedItemsList['bookmarks'].error) return true;
	
	this.febeBmBuNameJSON = this.febeCreateBackupName("bookmarks",".json")	
	this.febeUpdateProgressWindow(this.febeBmBuNameJSON,true);
	if(this.febeVerify(this.febeBmBuNameJSON)){
		let lbl = "bookmarks.json";
		this.febeAdditionalList[lbl] = {};
		this.febeAdditionalList[lbl].desc = this.febeMsg[418];
		this.febeAdditionalList[lbl].fname = this.febeBmBuNameJSON;
	}
	for(let i=0; i<this.febeDestDirs.length; i++){
		let path = OS.Path.join(this.febeDestDirs[i].dir, this.febeBmBuNameJSON);
		BookmarkJSONUtils.exportToFile(path);
	}
	febeDebug("Done backing up bookmarks.json")
	return true;
},

febeBackupBookmarksHTML: function (){
	febeDebug("Processing bookmarksHTML - Include in backup? "+this.febeBuBookmarksHTML);
	febeDebug("bookmarksHTML exist? - "+FEBE.selectedItemsList['bookmarks'].exists)
	febeDebug("bookmarksHTML error: "+FEBE.selectedItemsList['bookmarks'].error);
	
	if (!this.febeBuBookmarksHTML){return true;}
	if(!FEBE.selectedItemsList['bookmarks'].exists) return true;
	if(FEBE.selectedItemsList['bookmarks'].error) return true;
	this.febeBmBuNameHTML = this.febeCreateBackupName("bookmarks",".html");
	this.febeUpdateProgressWindow(this.febeBmBuNameHTML,true);
	if(this.febeVerify(this.febeBmBuNameHTML)){
		var lbl = "bookmarks.html";
		this.febeAdditionalList[lbl] = {};
		this.febeAdditionalList[lbl].desc = this.febeMsg[27];
		this.febeAdditionalList[lbl].fname = this.febeBmBuNameHTML;
	}
	for(let i=0; i<this.febeDestDirs.length; i++){
		let path = OS.Path.join(this.febeDestDirs[i].dir, this.febeBmBuNameHTML);
		BookmarkHTMLUtils.exportToFile(path);
	}
	febeDebug("Done backing up bookmarks.HTML");
	return true;
},

febeBackupPreferences: function (){
	febeDebug("Processing preferences - Include in backup? "+this.febeBuPreferences);
	febeDebug("preferences exist? - "+FEBE.selectedItemsList['preferences'].exists)
	febeDebug("preferences error: "+FEBE.selectedItemsList['preferences'].error);
	
	if (!this.febeBuPreferences){return true;}
	if(!FEBE.selectedItemsList['preferences'].exists) return true;
	if(FEBE.selectedItemsList['preferences'].error) return true;
	var profileDir = this.febeProfDir.clone();
	profileDir.append("prefs.js");
	var srcFile = profileDir.path;
	this.febePrBuName = this.febeCreateBackupName("prefs",".js");
	this.febeUpdateProgressWindow(this.febePrBuName,true);
	if (this.febeCopyFile(srcFile,this.febeExBuDir,this.febePrBuName)){
		if(this.febeVerify(this.febePrBuName)){
			var lbl = "preferences";
			this.febeAdditionalList[lbl] = {};
			this.febeAdditionalList[lbl].desc = this.febeMsg[28];
			this.febeAdditionalList[lbl].fname = this.febePrBuName;
		}
	}
	for(let i=1; i<this.febeDestDirs.length; i++){
		this.febeCopyFile(srcFile,this.febeDestDirs[i].dir,this.febePrBuName)
	}
	febeDebug("Done processing preferences");
	return true;
},

febeBackupCookies: function (){
	febeDebug("Processing cookies - Include in backup? "+this.febeBuCookies);
	febeDebug("cookies exist? - "+FEBE.selectedItemsList['cookies'].exists)
	febeDebug("cookies error: "+FEBE.selectedItemsList['cookies'].error);
	
	if (!this.febeBuCookies){return true;}
	if(!FEBE.selectedItemsList['cookies'].exists || FEBE.selectedItemsList['cookies'].size == 0) return true;
	if(FEBE.selectedItemsList['cookies'].error) return true;

	this.febeCkBuName = this.febeCreateBackupName("cookies",".json");
	var dFile, fos, cos;
	
	dFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
	this.febeBuDesDir = this.febeGetUnicharPref("extensions.febe.curBUdir");
	dFile.initWithPath(this.febeBuDesDir);
	dFile.append(this.febeCkBuName);
	this.febeUpdateProgressWindow(this.febeCkBuName,true);
	
	fos = Cc["@mozilla.org/network/file-output-stream;1"].createInstance(Ci.nsIFileOutputStream);
	fos.init(dFile, 0x02 | 0x08 | 0x20, 0x1ED, 0); // write, create, truncate
	
	cos = Cc["@mozilla.org/intl/converter-output-stream;1"].createInstance(Ci.nsIConverterOutputStream);
	cos.init(fos, "UTF-8", 0, 0x0000);
	
	let wm = Cc["@mozilla.org/appshell/window-mediator;1"].getService(Ci.nsIWindowMediator);
	let win = wm.getMostRecentWindow("navigator:browser");
	let file = win.FileUtils.getFile('ProfD', ['cookies.sqlite']);
	let DB = win.Services.storage.openDatabase(file);	
	let props = this.getPropertyNamesFromSqlite(DB,'moz_cookies');
	
	let stmt = "SELECT * FROM moz_cookies";
	let result = DB.createAsyncStatement(stmt);
	
	let cnt = 0;	
	result.executeAsync({
		handleResult: function(aResultSet){
			for(let row = aResultSet.getNextRow();row;row = aResultSet.getNextRow()){
				let cookie = {};
				for(let i=0; i<props.length; i++){
					cookie[props[i]] = row.getResultByName(props[i]);
				}

				let jstr = JSON.stringify(cookie);
				cos.writeString(jstr+"\n"); 
				cnt++;
			}
		},

		handleError: function(aError) {
			FEBE.databaseReadError('cookies',aError);
		},

		handleCompletion: function(aReason) {
			if (aReason != Components.interfaces.mozIStorageStatementCallback.REASON_FINISHED){
				FEBE.completionFailed('cookies',aReason);
			}else{
				result.finalize();
			}
			cos.close();
			fos.close();
		}
	});		

	if(this.febeVerify(this.febeCkBuName)){
		var lbl = "cookies";
		this.febeAdditionalList[lbl] = {};
		this.febeAdditionalList[lbl].desc = this.febeMsg[29];
		this.febeAdditionalList[lbl].fname = this.febeCkBuName;
	}
	for(let i=1; i<this.febeDestDirs.length; i++){
		this.febeCopyFile(dFile.path,this.febeDestDirs[i].dir,this.febeCkBuName)
	}
	febeDebug("Done processing cookies");
	return true;
},

febeBackupUserChrome: function (){
	febeDebug("Processing userChrome - Include in backup? "+this.febeBuUserChrome);
	febeDebug("userChrome exist? - "+FEBE.selectedItemsList['userChrome'].exists)
	febeDebug("userChrome error: "+FEBE.selectedItemsList['userChrome'].error);

	if (!this.febeBuUserChrome){return true;}
	if(!FEBE.selectedItemsList['userChrome'].exists) return true;
	if(FEBE.selectedItemsList['userChrome'].error) return true;
	var profileDir = this.febeProfDir.clone();
	profileDir.append("chrome");
	if (!profileDir.exists()){return true;}
	var srcDir = profileDir.path;
	this.febeChBuName = this.febeCreateBackupName("userChrome",".fbu");
	this.febeUpdateProgressWindow(this.febeChBuName,true);
	this.febeZip(srcDir,this.febeExBuDir,this.febeChBuName,false,false,this.febeRunAsync);	
	if(this.febeVerify(this.febeChBuName)){
		var lbl = "userchrome";
		this.febeAdditionalList[lbl] = {};
		this.febeAdditionalList[lbl].desc = this.febeMsg[52];
		this.febeAdditionalList[lbl].fname = this.febeChBuName;
	}
	for(let i=1; i<this.febeDestDirs.length; i++){
		this.febeZip(srcDir,this.febeDestDirs[i].dir,this.febeChBuName,false,false,this.febeRunAsync);
	}
	febeDebug("Done processing userChrome");
	return true;
},

febeBackupPasswords: function (){
	febeDebug("Processing usernames-passwords - Include in backup? "+this.febeBuUserPwd);
	febeDebug("usernames-passwords exist? - "+FEBE.selectedItemsList['usernamePasswords'].exists)
	febeDebug("usernames-passwords error: "+FEBE.selectedItemsList['usernamePasswords'].error);

	if (!this.febeBuUserPwd){return true;}
	if(!FEBE.selectedItemsList['usernamePasswords'].exists) return true;
	if(FEBE.selectedItemsList['usernamePasswords'].error) return true;
	this.febePwBuName = this.febeCreateBackupName("usernames-passwords",".json");
	
	var hostname, formSubmitURL, httprealm, username, password, usernameField, passwordField
	var loginManager = Cc["@mozilla.org/login-manager;1"].getService(Ci.nsILoginManager);
	var dFile, fos, cos;
	
	dFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
	this.febeBuDesDir = this.febeGetUnicharPref("extensions.febe.curBUdir");
	dFile.initWithPath(this.febeBuDesDir);
	dFile.append(this.febePwBuName);
	this.febeUpdateProgressWindow(this.febePwBuName,true);
	fos = Cc["@mozilla.org/network/file-output-stream;1"].createInstance(Ci.nsIFileOutputStream);
	fos.init(dFile, 0x02 | 0x08 | 0x20, 0x1ED, 0); // write, create, truncate
	
	cos = Cc["@mozilla.org/intl/converter-output-stream;1"].createInstance(Ci.nsIConverterOutputStream);
	cos.init(fos, "UTF-8", 0, 0x0000);
	
	var logins = loginManager.getAllLogins({});
	for (var i = 0; i < logins.length; i++) {
		var login = {};
	  login.hostname = logins[i].hostname;
		login.formSubmitURL = logins[i].formSubmitURL;
		login.httpRealm = logins[i].httpRealm;
		login.username = logins[i].username;
	  login.usernameField = logins[i].usernameField;
		login.password = this.febeObfuscate(true,logins[i].password); 
		login.passwordField = logins[i].passwordField;
	  var jstr = JSON.stringify(login);
		cos.writeString(jstr+"\n"); 
	}
	
	cos.close();
	fos.close();
	if(this.febeVerify(this.febePwBuName)){
		var lbl = "usernames-passwords";
		this.febeAdditionalList[lbl] = {};
		this.febeAdditionalList[lbl].desc = this.febeMsg[54];
		this.febeAdditionalList[lbl].fname = this.febePwBuName;
	}
	for(let i=1; i<this.febeDestDirs.length; i++){
		this.febeCopyFile(dFile.path,this.febeDestDirs[i].dir,this.febePwBuName)
	}
	febeDebug("Done processing usernames-passwords");
	return true;
},

febeBackupSearchPlugins: function (){
	febeDebug("Processing searchPlugins - Include in backup? "+this.febeBuSearchPlugins);
	febeDebug("searchPlugins exist? - "+FEBE.selectedItemsList['searchPlugins'].exists)
	febeDebug("searchPlugins error: "+FEBE.selectedItemsList['searchPlugins'].error);

	if (!this.febeBuSearchPlugins){return true;}
	if(!FEBE.selectedItemsList['searchPlugins'].exists) return true;
	if(FEBE.selectedItemsList['searchPlugins'].error) return true;

	// See if search plugins exist
	var profileDir = this.febeProfDir.clone();
	profileDir.append("search.json.mozlz4");
	if (!profileDir.exists()){return true;}
	this.febeSpBuName = this.febeCreateBackupName("searchPlugins",".mozlz4");
	this.febeUpdateProgressWindow(this.febeSpBuName,true);
	this.febeBuDesDir = this.febeGetUnicharPref("extensions.febe.curBUdir");
	this.febeCopyFile(profileDir.path,this.febeBuDesDir,this.febeSpBuName)
	
	if(this.febeVerify(this.febeSpBuName)){
		var lbl = "searchplugins";
		this.febeAdditionalList[lbl] = {};
		this.febeAdditionalList[lbl].desc = this.febeMsg[56];
		this.febeAdditionalList[lbl].fname = this.febeSpBuName;
	}
	for(let i=1; i<this.febeDestDirs.length; i++){
		this.febeCopyFile(profileDir.path,this.febeDestDirs[i].dir,this.febeSpBuName)
	}
	febeDebug("Done processing searchPlugins");
	return true;
},

febeBackupBrowserHistory: function (){
	febeDebug("Processing browserHistory - Include in backup? "+this.febeBuBrowserHistory);
	febeDebug("browserHistory exist? - "+FEBE.selectedItemsList['browserHistory'].exists)
	febeDebug("browserHistory error: "+FEBE.selectedItemsList['browserHistory'].error);

	if (!this.febeBuBrowserHistory){return true;}
	if(!FEBE.selectedItemsList['browserHistory'].exists) return true;
	if(FEBE.selectedItemsList['browserHistory'].error) return true;
	febeDebug("Processing browser history");
	this.febeHsBuName = this.febeCreateBackupName("history",".json");
	var dFile, fos, cos, cnt;
	var historyService = Cc["@mozilla.org/browser/nav-history-service;1"].getService(Ci.nsINavHistoryService);
					
	dFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
	this.febeBuDesDir = this.febeGetUnicharPref("extensions.febe.curBUdir");
	dFile.initWithPath(this.febeBuDesDir);
	dFile.append(this.febeHsBuName);
	this.febeUpdateProgressWindow(this.febeHsBuName,true);
	
	fos = Cc["@mozilla.org/network/file-output-stream;1"].createInstance(Ci.nsIFileOutputStream);
	fos.init(dFile, 0x02 | 0x08 | 0x20, 0x1ED, 0); // write, create, truncate
	
	cos = Cc["@mozilla.org/intl/converter-output-stream;1"].createInstance(Ci.nsIConverterOutputStream);
	cos.init(fos, "UTF-8", 0, 0x0000);
	
	// Get all history entries
	var options = historyService.getNewQueryOptions();
	var query = historyService.getNewQuery();
	var result = historyService.executeQuery(query, options); 

	var rr = result.root;
	rr.containerOpen = true;
	cnt = 0;

	for (var i = 0; i < rr.childCount; ++i) {
		var childNode = rr.getChild(i);
		var type = childNode.type;
		if(type != rr.RESULT_TYPE_URI) continue;
		var obj = {aURI : childNode.uri, aTitle : childNode.title, aLastVisited : childNode.time};
		var jstr = JSON.stringify(obj);
		cos.writeString(jstr+"\n"); 
		cnt++;
	}
	
	cos.close();
	fos.close();
	if(this.febeVerify(this.febeHsBuName)){
		var lbl = "history";
		this.febeAdditionalList[lbl] = {};
		this.febeAdditionalList[lbl].desc = this.febeMsg[57];
		this.febeAdditionalList[lbl].fname = this.febeHsBuName;
	}
	for(let i=1; i<this.febeDestDirs.length; i++){
		this.febeCopyFile(dFile.path,this.febeDestDirs[i].dir,this.febeHsBuName)
	}
	febeDebug("Done processing browserHistory");
	return true;
},

febeBackupFormFillHistory: function (){
	febeDebug("Processing formfillHistory - Include in backup? "+this.febeBuFormFillHistory);
	febeDebug("formfillHistory exists? - "+FEBE.selectedItemsList['formfillHistory'].exists)
	febeDebug("formfillHistory error: "+FEBE.selectedItemsList['formfillHistory'].error);
	
	if(!this.febeBuFormFillHistory) return true;
	if(!FEBE.selectedItemsList['formfillHistory'].exists || FEBE.selectedItemsList['formfillHistory'].size == 0) return true;
	if(FEBE.selectedItemsList['formfillHistory'].error) return true;

	this.febeFfBuName = this.febeCreateBackupName("ffhistory",".json");
	this.febeUpdateProgressWindow(this.febeFfBuName,true);
	var dFile, fos, cos;
	
	dFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
	this.febeBuDesDir = this.febeGetUnicharPref("extensions.febe.curBUdir");
	dFile.initWithPath(this.febeBuDesDir);
	dFile.append(this.febeFfBuName);
	this.febeUpdateProgressWindow(this.febeFfBuName,true);
	
	fos = Cc["@mozilla.org/network/file-output-stream;1"].createInstance(Ci.nsIFileOutputStream);
	fos.init(dFile, 0x02 | 0x08 | 0x20, 0x1ED, 0); // write, create, truncate
	
	cos = Cc["@mozilla.org/intl/converter-output-stream;1"].createInstance(Ci.nsIConverterOutputStream);
	cos.init(fos, "UTF-8", 0, 0x0000);
	
	let wm = Cc["@mozilla.org/appshell/window-mediator;1"].getService(Ci.nsIWindowMediator);
	let win = wm.getMostRecentWindow("navigator:browser");
	let file = win.FileUtils.getFile('ProfD', ['formhistory.sqlite']);
	let DB = win.Services.storage.openDatabase(file);	
	let props = this.getPropertyNamesFromSqlite(DB,'moz_formhistory');
	
	let stmt = "SELECT * FROM moz_formhistory";
	let result = DB.createAsyncStatement(stmt);
	
	let cnt = 0;	
	result.executeAsync({
		handleResult: function(aResultSet){
			for(let row = aResultSet.getNextRow();row;row = aResultSet.getNextRow()){
				let ffObj = {};
				for(let i=0; i<props.length; i++){
					ffObj[props[i]] = row.getResultByName(props[i]);
				}

				let jstr = JSON.stringify(ffObj);
				cos.writeString(jstr+"\n"); 
				cnt++;
			}
		},

		handleError: function(aError) {
			FEBE.databaseReadError('formfill history',aError);
		},

		handleCompletion: function(aReason) {
			if (aReason != Components.interfaces.mozIStorageStatementCallback.REASON_FINISHED){
				FEBE.completionFailed('formfill history',aReason);
			}else{
				result.finalize();
			}
			cos.close();
			fos.close();
		}
	});		

	if(this.febeVerify(this.febeFfBuName)){
		var lbl = "formhistory";
		this.febeAdditionalList[lbl] = {};
		this.febeAdditionalList[lbl].desc = this.febeMsg[58];
		this.febeAdditionalList[lbl].fname = this.febeFfBuName;
	}
	for(let i=1; i<this.febeDestDirs.length; i++){
		this.febeCopyFile(dFile.path,this.febeDestDirs[i].dir,this.febeFfBuName)
	}
	febeDebug("Done processing formfillHistory");
	return true;
},

febeBackupPermissions: function (){
	// As of Fx 44, permissions are located in permissions.sqlite and/or content-prefs.sqlite
	febeDebug("Processing permissions - Include in backup? "+this.febeBuPermissions);
	febeDebug("permissions exists? - "+FEBE.selectedItemsList['permissions'].exists)
	febeDebug("permissions error: "+FEBE.selectedItemsList['permissions'].error);
	if (!this.febeBuPermissions){return true;}
	if(!FEBE.selectedItemsList['permissions'].exists) return true;
	if(FEBE.selectedItemsList['permissions'].error) return true;
	if(!FEBE.selectedItemsList['permissions'].exists) return true;
	this.febePmBuName = this.febeCreateBackupName("permissions",".fbu");

	var profileDir1 = this.febeProfDir.clone();
	profileDir1.append("permissions.sqlite");
	var profileDir2 = this.febeProfDir.clone();
	profileDir2.append("content-prefs.sqlite");
	
	this.febeMakeTmpDir("permissionsTmp");

	if(profileDir1.exists()){
		var srcName = profileDir1.path;
		this.febeCopyFile(srcName,this.febeTmpDir.path,"permissions.sqlite");
	}
	if(profileDir2.exists()){
		var srcName = profileDir2.path;
		this.febeCopyFile(srcName,this.febeTmpDir.path,"content-prefs.sqlite");
	}
	
	if(profileDir1.exists() || profileDir2.exists()){
		// Run in sychronous mode so the tmp directory will not be removed before the backup is complete
		this.febeZip(this.febeTmpDir.path,this.febeExBuDir,this.febePmBuName,false,false,false);
	}

	if(this.febeVerify(this.febePmBuName)){
		let lbl = "permissions";
		this.febeAdditionalList[lbl] = {};
		this.febeAdditionalList[lbl].desc = this.febeMsg[116];
		this.febeAdditionalList[lbl].fname = this.febePmBuName;
	}
	
	dFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
	dFile.initWithPath(this.febeExBuDir);
	dFile.append(this.febePmBuName);
	
	for(let i=1; i<this.febeDestDirs.length; i++){
		this.febeCopyFile(dFile.path,this.febeDestDirs[i].dir,this.febePmBuName)
	}
	febeDebug("Removing permissions tmp file: "+this.febeTmpDir.path);
	this.febeTmpDir.remove(true);
	febeDebug("Done processing permissions");
	return true;
},

febeBackupUDBu: function (){
	febeDebug("Processing userDefinedBackups - Include in backup? "+this.febeBuUDBu);
	febeDebug("userDefinedBackups exists? - "+FEBE.selectedItemsList['userDefinedBackups'].exists)
	febeDebug("userDefinedBackups error: "+FEBE.selectedItemsList['userDefinedBackups'].error);

	if (!this.febeBuUDBu){return true;}
	if(!FEBE.selectedItemsList['userDefinedBackups'].exists) return true;
	if(FEBE.selectedItemsList['userDefinedBackups'].error) return true;
	this.febeUDBuDone = [];
	if(!this.febeUDBuInit()){return false;}	// UDBU is empty
	for(let i in this.febeUDBuList){
		let Label = new String(this.febeUDBuList[i].Label);
		if(Label.length == 0){continue;}	// Datafile is empty?
		let Type = new Number(this.febeUDBuList[i].Type);
		let Description = new String(this.febeUDBuList[i].Description);
		Description = "'"+Description+"'";
		let Path = new String(this.febeUDBuList[i].Path);
		let Include = Boolean(this.febeUDBuList[i].Include);
		let item = new this.febeUDBuDoneObj;
		item.Description = Description;
		item.Type = Type;
		if(!Include){continue;}
		if(Type == 1){	// Folder
			this.febeUdBuName = this.febeCreateBackupName(Label,".fbu");
			let srcName = Path;
			item.Name = this.febeUdBuName;
			this.febeUpdateProgressWindow(this.febeUdBuName,true);
			for(let i=0; i<this.febeDestDirs.length; i++){
				this.febeZip(srcName,this.febeDestDirs[i].dir,this.febeUdBuName,true,false,this.febeRunAsync);
			}

			if(this.febeVerify(this.febeUdBuName)){
				let lbl = "user-defined"+this.febeUdBuName;
				this.febeAdditionalList[lbl] = {};
				this.febeAdditionalList[lbl].desc = this.febeMsg[148].replace('%description%',item.Description);
				this.febeAdditionalList[lbl].fname = this.febeUdBuName;
			}else{
				item.Description = "*** Error backing up "+Description;
			}

			this.febeUDBuDone[Label] = item;
			
		}else{		// File
			let file = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
			file.initWithPath(Path);
			let UDBuName = this.febeCreateBackupName(Label,file.leafName);
			this.febeUpdateProgressWindow(UDBuName,true);
			item.Name = UDBuName;
			
			if(file.exists()){
				for(let i=0; i<this.febeDestDirs.length; i++){
					this.febeCopyFile(Path,this.febeDestDirs[i].dir,UDBuName);	
				}
			}else{
				let style = FEBE.febeStyle.orangered12;
				let tmp = style+this.febeMsg[166].replace("%path%",Path)+"\n"
				this.febeAlert(tmp);
			}
			
			if(this.febeVerify(UDBuName)){		
				let lbl = "user-defined"+UDBuName;
				this.febeAdditionalList[lbl] = {};
				this.febeAdditionalList[lbl].desc = this.febeMsg[148].replace('%description%',item.Description);
				this.febeAdditionalList[lbl].fname = UDBuName;
			}else{
				item.Description = this.febeMsg[167].replace("%description%",Description);
			}
			this.febeUDBuDone[Label] = item;
		}
	}	
	febeDebug("Done processing userDefinedBackups");
	return true;
},

febeBackupProfile: function (){
	febeDebug("Processing profile - Include in backup? "+this.febeUpBuName);	
	this.febeUpBuName = this.febeCreateBackupName("profile",".fbu");
	var srcName = this.febeProfDir.clone();
  srcName = srcName.path;
	this.febeExBuDir = this.febeGetUnicharPref("extensions.febe.curBUdir"); 
  this.febeZip(srcName,this.febeExBuDir,this.febeUpBuName,false,false,this.febeRunAsync);	
	this.febeUpdateProgressWindow(this.febeUpBuName,true);
	if(this.febeVerify(this.febeUpBuName)){
		var lbl = "profile";
		this.febeAdditionalList[lbl] = {};
		this.febeAdditionalList[lbl].desc = this.febeMsg[59];
		this.febeAdditionalList[lbl].fname = this.febeUpBuName;
	}
	for(let i=1; i<this.febeDestDirs.length; i++){
		this.febeZip(srcName,this.febeDestDirs[i].dir,this.febeUpBuName,false,false,this.febeRunAsync);	
	}
	febeDebug("Done processing profile");
	return true;
},

// ------------------ End of Backup Functions -------------

// ------------------ Restore Functions -------------------
febeRestoreExtensions: function (){
	if(!this.febeInitDir()){return false;}
	
	// Get set up
	var installCnt = 0;
	var restored = [];
	var listener = {
		onDownloadFailed: DownloadFailed,
		onDownloadCancelled: DownloadCancelled,
		onInstallFailed: InstallFailed,
		onInstallCancelled: InstallCancelled,
		onInstallEnded:installCompleted
	};

	function DownloadFailed(aInstall) {
		alert("onDownloadFailed: "+aInstall.name);
		aInstall.removeListener(listener);
		return true;
	}
	
	function DownloadCancelled(aInstall) {
		alert("onDownloadCancelled: "+aInstall.name);
		aInstall.removeListener(listener);
		return true;
	}
	
	function InstallFailed(aInstall) {
		alert("onInstallFailed: "+aInstall.name);
		aInstall.removeListener(listener);
		return true;
	}
	
	function InstallCancelled(aInstall) {
		alert("onInstallCancelled: "+aInstall.name);
		aInstall.removeListener(listener);
		return true;
	}

	function installError(aInstall) {
		alert("Install error: "+aInstall.name);
		aInstall.removeListener(listener);
		return true;
	}
	
	function installCompleted(aInstall) {
    aInstall.removeListener(listener);
		restored.push(aInstall.name);
		installCnt++;
		if(installCnt == restore.length){
			var tmp = "<class>purple</class>";
			tmp += FEBE.febeMsg[341]+"\n\n";
			tmp += "<class>extensionitem</class>";
			tmp += restored.join("\n<class>extensionitem</class>");
			//tmp += "\n<class>red</class>"+FEBE.febeMsg[342];
			tmp += "\n\nCheck the Add-on Manager tab to see if a restart is required";
			FEBE.febeOpenLink("about:addons");
			FEBE.febeAlert(tmp)
			//var ok = FEBE.febeConfirm(tmp);
			//if(ok == true){
				//FEBE.febeRestartFx();
			//}
		}
	}
	
	function IgnoreError(aInstall) {
		aInstall.removeListener(listener);
		return true;
	}

	// Get a list of items to restore
	this.febePickFiles("*.xpi",25);
	this.febePlatform = this.febeGetPlatform();
	if(this.febePlatform == 3){return true;}	// Mac can't handle modal alerts properly, so just assume they clicked "OK"

	// Create an aInstall object for each item to restore
	var installItems = [];
	var restore = [];

	this.febeETinstall.forEach(function(aFile) {
		AddonManager.getInstallForFile(aFile.nsFile, function(aInstall) {
			aInstall.fname = aFile.Name;
			aInstall.addListener(listener);
			installItems.push(aInstall);
			if(FEBE.febeETinstall.length == installItems.length){
				// Got the list, now parse each item and build the prompt
				var restoreObj = {};
				installItems.forEach(function(item){

				if(!!item.linkedInstalls){				// Item is a multipack
					restoreObj.type = "Multipack";
					restoreObj.name = item.name;
					restore.push(JSON.stringify(restoreObj));

					// Parse the multipack
					for(var i=0;i<item.linkedInstalls.length;i++){
						if(!!item.linkedInstalls[i].linkedInstalls){	// Multipack contains other multipacks
							alert("Multipack contains other multipacks")
						}else{
							if(item.linkedInstalls[i].type == "extension"){
								restoreObj.type = "MultipackExtension";
							}else{
								restoreObj.type = "MultipackTheme";
							}
						}
						restoreObj.name = item.linkedInstalls[i].name;
						restore.push(JSON.stringify(restoreObj));

						}
					}else{
						// Item is not a multipack
						if(item.type == "extension"){
							restoreObj.type = "Extension";
						}else{
							restoreObj.type = "Theme";
						}
						restoreObj.name = item.name;
						restore.push(JSON.stringify(restoreObj));
					}
				});				
			};
		});
		
		for(let i=0; i<FEBE.febeETinstall.length; i++){
			let file = FEBE.febeETinstall[i].nsFile;
			AddonManager.getInstallForFile(file, function(aInstall) {
				aInstall.addListener(listener);
				aInstall.install(aFile.nsFile);
				if(aInstall.linkedInstalls.length > 0){
					for(let j=0; j<aInstall.linkedInstalls.length; j++){
						let install = aInstall.linkedInstalls[j];
						install.addListener(listener);
						install.install(file);
					}
				}else{
					aInstall.addListener(listener);
					aInstall.install(aFile.nsFile);
				}
			});
		}
	});
	return true;
},

buildOtherBuLocationsList: function(popup){
	// Display other backup locations in popup menu
	
	// Clear existing items
	let children = popup.childNodes;
	let n = children.length;
	for(let i = 0; i < n; i++) {
		popup.removeChild(children[0]);
	}

	this.getBUlocations(false);
	let len = this.febeDestDirs.length;
	if(len == 1){	// No other backup locations enabled
		let mi = document.createElement('menuitem');
		mi.setAttribute('label',this.febeMsg[504]);
		mi.setAttribute('class','fontI');
		mi.setAttribute('tooltiptext',this.febeMsg[505]);
		mi.onclick = function(event){FEBE.febeHelp(66, FEBE.febeMsg[504])};
		popup.appendChild(mi);
		return true;
	}
		
	for(let i=1; i<len; i++){
		let item = this.febeDestDirs[i];
		let mi = document.createElement('menuitem');
		mi.setAttribute('label',item.name);
		let arg = encodeURIComponent(item.dir);
		mi.onclick = function(event){FEBE.uploadToOtherLocationOpen(arg)};

		popup.appendChild(mi);
	}

	return true;
},

uploadToOtherLocationOpen: function(destination){
	let dest = decodeURIComponent(destination);
	let source = this.febeGetUnicharPref("extensions.febe.lastbackup.folder");
	let opts = "chrome,dialog=yes,alwaysRaised,resizable=yes,titlebar=no,popup=yes";
	this.febeWin = window.openDialog('chrome://febe/content/febeCopyBackup.xul','FEBE Copy Backup',opts,dest,source);	
	this.febeWin.focus();
	return true;
},


uploadToOtherLocationLoad: function(){
	febeprt(null,null,0,true);	// Clear message window
	let srcFiles = [];
	let dstFiles = [];
	let dest = window.arguments[0];
	let source = window.arguments[1];
	if(source == dest){
		this.febeAlert(this.febeMsg[506],"red");
		return false;
	}
	let d, dst, src, entry, entries, dSize = sSize = dCnt = sCnt = 0;
	let dDir = sDir = overWritten = 0, tmp, arg;
	d = document.getElementById("otherLocationSourcePath");
	d.value = source;
	d = document.getElementById("otherLocationDestPath");
	d.value = dest;
	d = document.getElementById("otherLocationSourceBtn");
	arg = encodeURIComponent(source);
	d.onclick = function(event){FEBE.showFolder(arg,true)};
	d = document.getElementById("otherLocationDestBtn");
	arg = encodeURIComponent(dest);
	d.onclick = function(event){FEBE.showFolder(arg,true)};
	
	let clear = document.getElementById("clearDestID").checked;
	let overwrite = document.getElementById("overwriteID").checked;
	
	srcFiles = [];
	dstFiles = [];
	
	// Init source directory
	src = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
	src.initWithPath(source);
	entries = src.directoryEntries; 

	// Get source information
	while(entries.hasMoreElements()){
		entry = entries.getNext();
		entry.QueryInterface(Ci.nsIFile);
		if(entry.isDirectory()){
			sDir++;
			continue;	// Skip directories
		}else{
			sCnt++;
			sSize += entry.fileSize;
			srcFiles[entry.name] = null;
		}
	}
	tmp = this.febeMsg[507].replace('%SIZE%',parseInt(sSize/1024));
	tmp = tmp.replace('%CNT%',sCnt);
	febeprt(tmp,"green");
	if(sDir > 0){
		tmp = this.febeMsg[508].replace('%DIR%',sDir);
		febeprt(tmp,"green");
	}
	febeprt("");
	
	// Init destination directory
	dst = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
	dst.initWithPath(dest);
	entries = dst.directoryEntries; 
	
	// Get destination information
	overWritten = 0;
	while(entries.hasMoreElements()){
		entry = entries.getNext();
		entry.QueryInterface(Ci.nsIFile);
		if(entry.isDirectory()){
			dDir++;
			continue;	// Skip directories
		}else{
			dCnt++;
			dSize += entry.fileSize;
			dstFiles[entry.name] = null;
			if((entry.name in srcFiles) && (overwrite == true)) overWritten++;
		}
	}
	tmp = this.febeMsg[509].replace('%SIZE%',parseInt(dSize/1024));
	tmp = tmp.replace('%CNT%',dCnt);
	febeprt(tmp,"blue");
	if(dDir > 0){
		tmp = this.febeMsg[510].replace('%DIR%',dDir);
		febeprt(tmp,"blue");
	}
	
	if(clear){
		tmp = this.febeMsg[511].replace('%CNT%',dCnt);
		febeprt(tmp,"darkblue");
		if(dDir > 0){
			tmp = this.febeMsg[512].replace('%DIR%',dDir);
			febeprt(tmp,"blue");
		}
	}else{
		if(overwrite){
			if(overWritten > 0){
				tmp = this.febeMsg[513].replace('%NUM%',overWritten);
				febeprt(tmp,"darkblue");
			}
		}else{
			if(dCnt-overWritten > 0){
				tmp = this.febeMsg[514].replace('%NUM%',dCnt-overWritten);
				febeprt(tmp,"blue");
			}
		}
	}
	febeprt("");
	
	function febeprt(txt,color,numBlankLines,clearAll){
		if(!color) color="black";
		if(!numBlankLines) numBlankLines = 0;
		let bold = false;
		if(color.indexOf('!') > 0){
			bold = true;
			color = color.replace('!','');
		}
		let box = document.getElementById('messages');
		
		let body = box.contentDocument.body;
		if(clearAll){
			let children = body.childNodes;
			let n = children.length;
			// Clear existing items
			for (var i = 0; i < n; i++) {
				body.removeChild(children[0]);
			}
			return true;
		}
		
		let msg = document.createTextNode(txt);
		let br = document.createElementNS(FEBE.febeNamespace,'br');
		let span = document.createElementNS(FEBE.febeNamespace,'span');
		span.style.color = color;
		span.style.fontWeight = "normal";
		if(bold) span.style.fontWeight = "bold"; 
		span.style.fontFamily = "Arial";
		span.style.fontSize = "12px";
		span.appendChild(msg)
		body.appendChild(span);
		body.appendChild(br);
		
		for(let i=0; i<numBlankLines; i++){
			let br = document.createElementNS(FEBE.febeNamespace,'br');
			body.appendChild(br);
		}
		
		// Scroll to bottom after each write
		let scrollBox = box.contentWindow.document.body;
		scrollBox.scrollTop = scrollBox.scrollHeight - scrollBox.clientHeight;
		
		// Add contents to clipboard array
		FEBE.febeClipboard.push(txt);
		return true;
	}
	this.febePlaySound('message');
	return true;
},

uploadToOtherLocationStart: function(){
	let dest = window.arguments[0];
	let source = window.arguments[1];
	
	let clearDir = document.getElementById("clearDestID").checked;
	let overwrite = document.getElementById("overwriteID").checked;
	let skipped = overwritten = copied = cnt = 0, entry, entries, dFile, file2copy;
	
	// Init destination directory
	let dst = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
	dst.initWithPath(dest);
	
	// Clear destination if needed
	if(clearDir){
		let removed = dirCnt = 0;
		dFile = dst.clone();
		entries = dFile.directoryEntries;
		while(entries.hasMoreElements()){
			entry = entries.getNext();
			entry.QueryInterface(Ci.nsIFile);
			if(entry.isDirectory()){
				dirCnt++;
				continue;	// Skip directories
			}else{
				entry.remove(false);
				removed++;
			}
		}
		tmp = this.febeMsg[515].replace('%CNT%',removed);
		febeprt(tmp,"red");
		if(dirCnt > 0){
			tmp = this.febeMsg[516].replace('%CNT%',dirCnt);
			febeprt(tmp,"crimson");
		}
	}

	// Init source directory
	let src = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
	src.initWithPath(source);

	// Start copy
	entries = src.directoryEntries;
	while(entries.hasMoreElements()){
		entry = entries.getNext();
		entry.QueryInterface(Ci.nsIFile);
		if(entry.isDirectory()) continue;	// Skip directories
		cnt++;
		
		// Get pointer to source file
		file2copy = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
		file2copy.initWithPath(entry.path);
		
		// See if destination file already exists
		dFile = dst.clone();
		dFile.append(entry.leafName);
		if(dFile.exists()){
			if(overwrite == true){
				overwritten++;
				febeprt(this.febeMsg[517]+" "+file2copy.leafName,"lightcoral");
				file2copy.copyTo(dst,"");	
			}else{
				febeprt(this.febeMsg[518]+" "+file2copy.leafName,"lightsalmon");
				skipped++;
			}
		}else{
			febeprt(this.febeMsg[519]+" "+file2copy.leafName,"midnightblue");
			file2copy.copyTo(dst,"");	
			copied++;
		}
	}
	febeprt("");
	tmp = this.febeMsg[520].replace('%CNT%',cnt);
	tmp = tmp.replace('%COPIED%',copied);
	tmp = tmp.replace('%OVERWRITTEN%',overwritten);
	tmp = tmp.replace('%SKIPPED%',skipped);
	febeprt(tmp,"black!");
	
	function febeprt(txt,color,numBlankLines){
		if(!color) color="black";
		if(!numBlankLines) numBlankLines = 0;
		let bold = false;
		if(color.indexOf('!') > 0){
			bold = true;
			color = color.replace('!','');
		}
		let box = document.getElementById('messages');
		let body = box.contentDocument.body;
		let msg = document.createTextNode(txt);
		let br = document.createElementNS(FEBE.febeNamespace,'br');
		let span = document.createElementNS(FEBE.febeNamespace,'span');
		span.style.color = color;
		span.style.fontWeight = "normal";
		if(bold) span.style.fontWeight = "bold"; 
		span.style.fontFamily = "Arial";
		span.style.fontSize = "12px";
		span.appendChild(msg)
		body.appendChild(span);
		body.appendChild(br);
		
		// Scroll to bottom after each write
		let scrollBox = box.contentWindow.document.body;
		scrollBox.scrollTop = scrollBox.scrollHeight - scrollBox.clientHeight;
		
		// Add contents to clipboard array
		FEBE.febeClipboard.push(txt);
		return true;
	}
	return true;
},

febeBuildExtensionRestoreWin: function (){
	var restoreList = window.arguments[0];
	var msgBox = document.getElementById("febeMsgBox");
	document.getElementById("header").value = this.febeMsg[341]+"\n\n";
	var oLabel = document.createElement('label');
	var oHbox = document.createElement('hbox');
	var oMenulist = document.createElement('menulist');
	var oMenupopup = document.createElement('menupopup');
	var oMenuitem = document.createElement('menuitem');

	for(var i=0;i<restoreList.length;i++){	
		var item = JSON.parse(restoreList[i]);
		switch(item.type){
			case "Multipack":
				var hbox = oHbox.cloneNode(false);
				hbox.setAttribute("class","multipack");		
				var label = oLabel.cloneNode(false);
				label.value = item.name;
				hbox.appendChild(label);
				var menulist = oMenulist.cloneNode(false);
				menulist.onselect = function(event){this.selectedIndex = 0};

				hbox.appendChild(menulist);
				var menupopup = oMenupopup.cloneNode(false);
				menupopup.setAttribute("class","multipacklistitem");
				for(var j = -1;j<item.cnt;j++){	
					var mitem = JSON.parse(restoreList[i+j+1]);
					var menuitem = oMenuitem.cloneNode(false);	
					if(j == -1){
						menuitem.label = "Cleopack";
						menuitem.setAttribute("class","multipacklistitem");
					}else{
						if(mitem.type == "MultipackExtension"){
							menuitem.setAttribute("class","multipackextensionitem");
						}else{
							menuitem.setAttribute("class","multipackthemeitem");
						}
						menuitem.label = mitem.name;
					}
		
					menupopup.appendChild(menuitem);
				}
				menulist.appendChild(menupopup);
				hbox.appendChild(menulist);
				i += j;
				msgBox.appendChild(hbox);
				break;;
			case "Extension":
				var label = oLabel.cloneNode(false);
				label.value = item.name;
				label.setAttribute("class","extensionitem");
				msgBox.appendChild(label);
				break;;
			case "Theme":
				var label = oLabel.cloneNode(false);
				label.value = item.name;
				label.setAttribute("class","themeitem");
				msgBox.appendChild(label);
				break;;
			case "Multipackpack":
				var label = oLabel.cloneNode(false);
				label.value = item.name;
				label.setAttribute("class","multipack");
				msgBox.appendChild(label);
				break;;

		}//switch
	}
	this.febePlaySound('message');
},

febeRestoreThemes: function (){
	if(!this.febeInitDir()){return false;}
	this.febePickFiles("*.jar",24);
	
	var restored = [];
	var listener = {
		onDownloadFailed: installCompleted,
		onDownloadCancelled: installCompleted,
		onInstallFailed: installCompleted,
		onInstallCancelled: installCompleted,
		onInstallEnded: installCompleted
	};
	function installCompleted(aInstall) {
    aInstall.removeListener(listener);
		restored.push(aInstall.name);
		if(FEBE.febeETinstall.length == restored.length){
			var tmp = "<class>purple</class>";
			tmp += FEBE.febeMsg[341]+"\n\n";
			tmp += "<class>themeitem</class>";
			tmp += restored.join("\n<class>themeitem</class>");
			tmp += "\n<class>red</class>"+FEBE.febeMsg[342];
			var ok = FEBE.febeConfirm(tmp);
			if(ok == true){
				FEBE.febeRestartFx();
			}
		}
		//if (getAddonTestType(aInstall.addon.name) == "userdisabled") {
			//aInstall.addon.userDisabled = true;
		//}
	}

	FEBE.febeETinstall.forEach(function(aFile) {
		AddonManager.getInstallForFile(aFile.nsFile, function(aInstall) {
			aInstall.addListener(listener);
			aInstall.install(aFile.nsFile);
		});
	});
	return true;
},

febeRestoreIndividualPersonas: function (){
	if(!this.febeInitDir()){return false;}
	this.febePickFiles("*.persona.json",24);
	if(this.febeETinstall.length == 0){
		this.febeAlert(this.febeMsg[46]);
		return true;
	}

	var personasInstalled = [];
	var personas = [];
	var prefName = "lightweightThemes.usedThemes";
	if(this.febePrefs.prefHasUserValue(prefName)){
		prefData = this.febeGetUnicharPref(prefName);
		personasInstalled = JSON.parse(prefData);
	}
	
	for(var i in personasInstalled){
		try{
			var pId = personasInstalled[i].id + "@personas.mozilla.org";
			personas[pId] = new Object(personasInstalled[i]);
		}catch(e){;;}
	}
	
	for(var i=0; i<this.febeETinstall.length; i++){
		var dFile = this.febeETinstall[i].nsFile;
		var fis = Cc["@mozilla.org/network/file-input-stream;1"].createInstance(Ci.nsIFileInputStream);
		fis.init(dFile, 0x01, 0x124, 0);
		fis.QueryInterface(Ci.nsILineInputStream);

		var cis = Cc["@mozilla.org/intl/converter-input-stream;1"].createInstance(Ci.nsIConverterInputStream);
		cis.init(fis,"UTF-8", 0, 0x0000);
		
		var lis = cis.QueryInterface(Ci.nsIUnicharLineInputStream);

		// read lines into array and parse into individual fields
		var line = {}, hasmore;	
		var personasInstalled = "";
		do {
			hasmore = lis.readLine(line);
			var persona = new Object(JSON.parse(line.value));
			var pId = persona[0].id + "@personas.mozilla.org";
			personas[pId] = persona[0];
		} while(hasmore);
		cis.close();
		fis.close();
	}
	var personasInstalled = "[";
	var cnt = 0;
	for(var i in personas){
		if(cnt != 0) personasInstalled += ",";
		personasInstalled += JSON.stringify(personas[i]);
		cnt++;
	}
	personasInstalled += "]";
	
	this.febeSetUnicharPref(prefName,personasInstalled);
	this.febeAlert(this.febeMsg[343]);
	return true;
},

febeRestoreAllPersonas: function (){
	if(!this.febeInitDir()){return false;}
	this.febePickFiles("*.personas.json",344);
	if(this.febeETinstall.length == 0){
		this.febeAlert(this.febeMsg[46]);
		return true;
	}

	for(var i=0; i<this.febeETinstall.length; i++){
		var dFile = this.febeETinstall[i].nsFile;
		var fis = Cc["@mozilla.org/network/file-input-stream;1"].createInstance(Ci.nsIFileInputStream);
		fis.init(dFile, 0x01, 0x124, 0);
		fis.QueryInterface(Ci.nsILineInputStream);

		var cis = Cc["@mozilla.org/intl/converter-input-stream;1"].createInstance(Ci.nsIConverterInputStream);
		cis.init(fis,"UTF-8", 0, 0x0000);
		
		var lis = cis.QueryInterface(Ci.nsIUnicharLineInputStream);

		// read lines into array and parse into individual fields
		var line = {}, hasmore;	
		do {
			hasmore = lis.readLine(line);
			var personasInstalled = line.value;
		} while(hasmore);
		cis.close();
		fis.close();
	}
	this.febeSetUnicharPref("lightweightThemes.usedThemes",personasInstalled);
	this.febeAlert(this.febeMsg[343]);
	return true;
},

febeRestoreBookmarksJSON: function (){
	FEBE.febeSetMsgs();
	if(FEBE.febePathName.length == 0){
		FEBE.febeAlert(FEBE.febeMsg[33]);
		return false;
	}
	
	var option = document.getElementById("febeBookmarksRestoreOption").value;
	var overwriteflag = ((option == "overwrite") ? true : false);
	if(!FEBE.febeInitDir()){return false;}
	let check = this.febePrName.match(/^bookmarks(.*)\.json$/ig);
	if(!check){
		var tmp = FEBE.febeStyle.purpleBold+FEBE.febeMsg[50].replace("%FILE%","'"+FEBE.febePrName+"'")+"\n";
		tmp += FEBE.febeStyle.orangeredBold+FEBE.febeMsg[46];
		FEBE.febeAlert(tmp);
		return false;
	}
	
	FEBE.febeBUdate = FEBE.febeGetBuDate(FEBE.febePathName);
	if(FEBE.febeConfirmRestore(37,FEBE.febeBUdate)){
		let path = OS.Path.join(this.febePfParent,this.febePfName);
		BookmarkJSONUtils.importFromFile(path, overwriteflag);
		FEBE.febeAlert(FEBE.febeMsg[42]);
	}else{
		FEBE.febeAlert(FEBE.febeMsg[46]);
	}
	window.close();
	return true;
},

febeRestoreBookmarksHTML: function (){
	FEBE.febeSetMsgs();
	if(FEBE.febePathName.length == 0){
		FEBE.febeAlert(FEBE.febeMsg[33]);
		return false;
	}
	
	var option = document.getElementById("febeBookmarksRestoreOption").value;
	var overwriteflag = ((option == "overwrite") ? true : false);
	if(!FEBE.febeInitDir()){return false;}
	let check = this.febePrName.match(/^bookmarks(.*)\.html$/ig);
	if(!check){
		var tmp = FEBE.febeStyle.purpleBold+FEBE.febeMsg[50].replace("%FILE%","'"+FEBE.febePrName+"'")+"\n";
		tmp += FEBE.febeStyle.orangeredBold+FEBE.febeMsg[46];
		FEBE.febeAlert(tmp);
		return false;
	}
	
	FEBE.febeBUdate = FEBE.febeGetBuDate(FEBE.febePathName);
	if(FEBE.febeConfirmRestore(37,FEBE.febeBUdate)){
		let path = OS.Path.join(this.febePfParent,this.febePfName);
		BookmarkHTMLUtils.importFromFile(path, overwriteflag);
		FEBE.febeAlert(FEBE.febeMsg[42]);
	}else{
		FEBE.febeAlert(FEBE.febeMsg[46]);
	}
	window.close();
	return true;
},

febeGetBookmarksRestoreFile: function (type){
	if(!this.febePickRestoreFile("bookmarks*."+type,33)){return false};
	var d = document.getElementById("febeBookmarksRestoreDir");
	d.setAttribute("value",this.febePathName);
},

febeRestorePreferences: function (){
	if(!this.febeInitDir()){return false;}
	this.febePathName = ""
	if(!this.febePickRestoreFile("prefs*.js",34)){return true};
	let check = this.febePrName.match(/^prefs(.*)\.js$/ig);
	if(!check){
		var tmp = FEBE.febeStyle.purpleBold+this.febeMsg[69].replace("%FILE%","'"+this.febePrName+"'")+"\n";
		tmp += FEBE.febeStyle.orangeredBold+this.febeMsg[46];
		this.febeAlert(tmp);
		return false;
	}

	this.febeBUdate = this.febeGetBuDate(this.febePathName);
	if(this.febeConfirmRestore(38,this.febeBUdate,true)){
		
		// Pointer to preferences
		var oldPrefs = Cc["@mozilla.org/preferences-service;1"].getService(Ci.nsIPrefBranch);
		
		// Pointer to new (restored) preferences
		var newPrefs = Cc["@mozilla.org/preferences-service;1"].getService(Ci.nsIPrefService);
					
		// Pointer to backed up preferences file
		var newPrefFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
		
		// Get pointer to "Prefs.js"
		var PrefsFile = this.febeProfDir.clone();
                   
		PrefsFile.append("prefs.js")
		newPrefFile.initWithPath(this.febePathName); 	// Initialize backed up prefs file
		oldPrefs.deleteBranch("");					// Delete old preferences
		newPrefs.readUserPrefs(newPrefFile);		// Read in backed up preferences
		newPrefs.savePrefFile(PrefsFile);			// Save the restored preferences file
		
		alert(this.febeMsg[43]);
		this.febeRestartFx();							// Restart Firefox
	}else{
		this.febeAlert(this.febeMsg[46]);
	}
	return true;
},

febeRestoreCookies: function (){
	this.febeSetMsgs();
	if(!this.febeInitDir()){return false;}
	this.febePathName = ""
	if(!this.febePickRestoreFile("cookies*.json",35)){return true};
	let check = this.febePrName.match(/^cookies(.*)\.json$/ig);
	if(!check){
		var tmp = this.febeStyle.purpleBold+this.febeMsg[71].replace("%FILE%","'"+this.febePrName+"'")+"\n";
		tmp += this.febeStyle.orangeredBold+this.febeMsg[46];
		this.febeAlert(tmp);
		return false;
	}

	this.febeBUdate = this.febeGetBuDate(this.febePathName);
	if(this.febeConfirmRestore(39,this.febeBUdate)){
				
		var dFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
		dFile.initWithPath(this.febePathName);
		
		var fis = Cc["@mozilla.org/network/file-input-stream;1"].createInstance(Ci.nsIFileInputStream);
		fis.init(dFile, 0x01, 0x124, 0);
		fis.QueryInterface(Ci.nsILineInputStream);

		var cis = Cc["@mozilla.org/intl/converter-input-stream;1"].createInstance(Ci.nsIConverterInputStream);
		cis.init(fis,"UTF-8", 0, 0x0000);
		
		var lis = cis.QueryInterface(Ci.nsIUnicharLineInputStream);
		
		var wm = Cc["@mozilla.org/appshell/window-mediator;1"].getService(Ci.nsIWindowMediator);
		var win = wm.getMostRecentWindow("navigator:browser");
		var file = win.FileUtils.getFile('ProfD', ['cookies.sqlite']);
		var DB = win.Services.storage.openDatabase(file);	
		
		// read lines into array and parse into individual fields
		var line = {}, hasmore;	
		var cnt = 0;
		var cnt2 = 0;
		var props;
		var stmt;
		var sqliteFile = "cookies";
		var tableName = "moz_cookies";
		var result;
		var createStatement;	// A SQL 'Create table statement for 'moz_cookies'
		
		// Save the current schema structure
		stmt = "SELECT 'moz_cookies', sql from sqlite_master WHERE type = 'table'"
		result = DB.createStatement(stmt);
		result.executeAsync({
			handleResult: function(aResultSet){
				let row = aResultSet.getNextRow();
				createStatement = row.getResultByName("sql");				
//FEBE.logMsg(createStatement)
				// Drop the table (deletes all cookies)
				let dropResult = DB.createStatement("DROP TABLE "+tableName);
				dropResult.executeAsync({
					handleResult: function(aResultSet){
						// Create table from saved schema
						createStatement.executeAsync({
							handleResult: function(aResultSet){
								writeCookies(DB);
							}
						});
					},
					handleError: function(aError) {
						FEBE.logMsg(aError)
						FEBE.databaseReadError('cookies',aError);
					}

				});
			}
		});
		writeCookies(DB);
		cis.close();
		fis.close();
		DB.asyncClose();
		alert(this.febeMsg[44]+" ("+cnt+")");
		this.febeRestartFx();							// Restart Firefox
	}else{
		this.febeAlert(this.febeMsg[46]);
	}
	
	function writeCookies(DB){
		// Start asynchronous batch transaction
		DB.beginTransactionAs(DB.TRANSACTION_IMMEDIATE);
		
		// Insert the cookies
		do {
			hasmore = lis.readLine(line);
			let cookie = JSON.parse(line.value);
			if(cnt == 0){
				if(!FEBE.objIsInstanceOf(cookie,DB,tableName)){
					let tmp = FEBE.febeMsg[548]+"\n\n"+FEBE.febeMsg[546];
					FEBE.febeAlert(tmp);
					return false;
				}
				props = FEBE.getPropertyNamesFromSqlite(DB,tableName);
			}

			stmt = "INSERT INTO "+tableName+" VALUES(";
			for(let i=0; i<props.length; i++){
				stmt = stmt+":"+[props[i]];
				if(i<props.length-1){
					stmt = stmt+", ";
				}else{
					stmt = stmt+")";
				}
			}
			
			try{
				result = DB.createStatement(stmt);
				for(let i=0; i<props.length; i++){
					result.params[props[i]] = FEBE.sqliteEscape(cookie[props[i]]);
				}
				result.executeAsync();
			}catch(e){
				FEBE.logMsg("Error writing cookie item: "+cookie.id+"\n"+e)
			}finally{
				result.finalize();
			}
			cnt++;
		} while(hasmore);
		
		DB.commitTransaction();
	}
	return true;
},

febeRestoreUserChrome: function (){
	if(!this.febeInitDir()){return false;}
	this.febePathName = ""
	var chromeDir = this.febeProfDir.clone();
	chromeDir.append("chrome");
	if(!this.febePickRestoreFile("userChrome*.fbu",78)){return true};
	let check = this.febePrName.match(/^userChrome(.*)\.fbu$/ig);
	if(!check){
		var tmp = FEBE.febeStyle.purpleBold+this.febeMsg[83].replace("%FILE%","'"+this.febePrName+"'")+"\n";
		tmp += FEBE.febeStyle.orangeredBold+this.febeMsg[46];
		this.febeAlert(tmp);
		return false;
	}

	this.febeBUdate = this.febeGetBuDate(this.febePathName);
	if(this.febeConfirmRestore(393,this.febeBUdate)){
		var sourceDir = this.febePfParent;
		var destDir = chromeDir.path;
		var zipName = this.febePfName;
		this.febeUnzip(sourceDir,destDir,zipName);
		this.febeChmod(destDir);
		this.febeAlert(this.febeMsg[79]);
	}else{
		this.febeAlert(this.febeMsg[46]);
	}
	return true;
},

febeRestorePasswords: function (){
	if(!this.febeInitDir()){return false;}
	this.febePathName = ""
	if(!this.febePickRestoreFile("usernames-passwords*.json",80)){return true};	
	let check = this.febePrName.match(/^usernames-passwords(.*)\.json$/ig);
	if(!check){
		var tmp = FEBE.febeStyle.purpleBold+this.febeMsg[125].replace("%FILE%","'"+this.febePrName+"'")+"\n";
		tmp += FEBE.febeStyle.orangeredBold+this.febeMsg[46];
		this.febeAlert(tmp);
		return false;
	}
	
	this.febeBUdate = this.febeGetBuDate(this.febePathName);

	if(this.febeConfirmRestore(70,this.febeBUdate)){

		// Clear existing paswords
		var hostname, formSubmitURL, httprealm, username, password, usernameField, passwordField, login, dFile;
		var loginManager = Cc["@mozilla.org/login-manager;1"].getService(Ci.nsILoginManager);
		var logins = loginManager.getAllLogins({}); 
		for (var i = 0; i < logins.length; i++) {
			login = {};
		  login.hostname = logins[i].hostname;
			login.formSubmitURL = logins[i].formSubmitURL;
			login.httpRealm = logins[i].httpRealm;
			login.username = logins[i].username;
		  login.usernameField = logins[i].usernameField;
			login.password = logins[i].password; 
			login.passwordField = logins[i].passwordField;
			loginManager.removeLogin(login);
		}
		
		dFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
		dFile.initWithPath(this.febePathName);
		
		var fis = Cc["@mozilla.org/network/file-input-stream;1"].createInstance(Ci.nsIFileInputStream);
		fis.init(dFile, 0x01, 0x124, 0);
		fis.QueryInterface(Ci.nsILineInputStream);

		var cis = Cc["@mozilla.org/intl/converter-input-stream;1"].createInstance(Ci.nsIConverterInputStream);

		cis.init(fis,"UTF-8", 0, 0x0000);
		var lis = cis.QueryInterface(Ci.nsIUnicharLineInputStream);
		var nsLoginInfo = new Components.Constructor("@mozilla.org/login-manager/loginInfo;1",Ci.nsILoginInfo,"init");

		var line = {}, hasmore;	
		var cnt = 0;
		do {
			hasmore = lis.readLine(line);
			var data = JSON.parse(line.value)
			login = new nsLoginInfo(hostname, formSubmitURL, httprealm, username, password, usernameField, passwordField);
			login.hostname = data.hostname;
			login.formSubmitURL = data.formSubmitURL;
			login.httpRealm = data.httpRealm;
			login.username = data.username;
		    login.usernameField = data.usernameField;
			login.password = this.febeObfuscate(false,data.password);
			login.passwordField = data.passwordField;
			try{
				loginManager.addLogin(login);
				cnt++;
			}catch(e){
				var err = e;
				var tmp = FEBE.febeStyle.orangeredBold10+err+"\n";
				tmp += "Host: "+login.hostname+"\n"
				tmp += "Username: "+login.username+"\n\n";
				tmp += FEBE.febeStyle.blackBold
				tmp += "Login entry skipped";
				this.febeAlert(tmp);
			}
		} while(hasmore);
		this.febeAlert(this.febeMsg[81]);
	}else{
		this.febeAlert(this.febeMsg[46]);
	}
	cis.close();
	fis.close();
	return true;
},

febeRestoreSearchPlugins: function (){
	if(!this.febeInitDir()){return false;}
	this.febePathName = ""
	if(!this.febePickRestoreFile("searchPlugins*.mozlz4",84)){return true};
	let check = this.febePrName.match(/^searchPlugins(.*)\.mozlz4$/ig);
	if(!check){
		var tmp = FEBE.febeStyle.purpleBold+this.febeMsg[55].replace("%FILE%","'"+this.febePrName+"'")+"\n";
		tmp += FEBE.febeStyle.orangeredBold+this.febeMsg[46];
		this.febeAlert(tmp);
		return false;
	}

	this.febeBUdate = this.febeGetBuDate(this.febePathName);
	if(this.febeConfirmRestore(72,this.febeBUdate)){
		var profileDir = this.febeProfDir.clone();
		this.febeCopyFile(this.febePathName,profileDir.path,"search.json.mozlz4");
		this.febeAlert(this.febeMsg[85]);
	}else{
		this.febeAlert(this.febeMsg[46]);
	}
	return true;
},

febeRestoreBrowserHistory: function (){
	if(!this.febeInitDir()){return false;}
	this.febePathName = ""
	if(!this.febePickRestoreFile("history*.json",86)){return true};
	let check = this.febePrName.match(/^history(.*)\.json$/ig);
	if(!check){
		var tmp = FEBE.febeStyle.purpleBold+this.febeMsg[63].replace("%FILE%","'"+this.febePrName+"'")+"\n";
		tmp += FEBE.febeStyle.orangeredBold+this.febeMsg[46];
		this.febeAlert(tmp);
		return false;
	}

	this.febeBUdate = this.febeGetBuDate(this.febePathName);
	if(this.febeConfirmRestore(73,this.febeBUdate)){
		
		// Delete current history
		var bh = Cc["@mozilla.org/browser/nav-history-service;1"].getService(Ci.nsIBrowserHistory);
		bh.removeAllPages();
		try {
			var os = Cc["@mozilla.org/observer-service;1"].getService(Ci.nsIObserverService);
			os.notifyObservers(null, "browser:purge-session-history", "");
		}
		catch (e) { }
		
		// Clear last URL of the Open Browser Location dialog
		var prefs = Cc["@mozilla.org/preferences-service;1"].getService(Ci.nsIPrefBranch2);
		try {
			prefs.clearUserPref("general.open_location.last_url");
		}
		catch (e) { }

		// Restore browser history
		var ios = Cc["@mozilla.org/network/io-service;1"].getService(Ci.nsIIOService);
		var cookieSvc = Cc["@mozilla.org/cookieService;1"].getService(Ci.nsICookieService);

		var dFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
		dFile.initWithPath(this.febePathName);
		
		var fis = Cc["@mozilla.org/network/file-input-stream;1"].createInstance(Ci.nsIFileInputStream);
		fis.init(dFile, 0x01, 0x124, 0);
		fis.QueryInterface(Ci.nsILineInputStream);

		var cis = Cc["@mozilla.org/intl/converter-input-stream;1"].createInstance(Ci.nsIConverterInputStream);
		cis.init(fis,"UTF-8", 0, 0x0000);
		
		var lis = cis.QueryInterface(Ci.nsIUnicharLineInputStream);

		// read lines into array and parse into individual fields
		var line = {}, hasmore;	
		var cnt = 0;
		var aPlaces = [];
		do {
			hasmore = lis.readLine(line);
			var histObj = JSON.parse(line.value);
			// create an nsIURI 
			var uri = Cc["@mozilla.org/network/io-service;1"].getService(Ci.nsIIOService).newURI(histObj.aURI, null, null);
			var place = {
				uri: uri,
				title: histObj.aTitle,
				visits: [{
					visitDate: histObj.aLastVisited,
					transitionType: Ci.nsINavHistoryService.TRANSITION_LINK
				}]
			};
			aPlaces.push(place);
			cnt++;
		} while(hasmore);

			try{
				PlacesUtils.asyncHistory.updatePlaces(aPlaces,{
					handleError: function() {},
					handleResult: function() {},
					handleCompletion: function() {
						FEBE.febeAlert(FEBE.febeMsg[106]+" ("+cnt+")");
					}
				});
			}catch(e){
				var msg = "\n\naURI: "+histObj.aURI+"\naTitle: "+histObj.aTitle+"\naLastVisited: "+histObj.aLastVisited;
				this.febeRestoreError(e, msg)
				return false;
			}
	}else{	
		this.febeAlert(this.febeMsg[46]);
	}
	cis.close();
	fis.close();
	return true;
},

febeRestoreFormFillHistory: function (){
	this.febeSetMsgs();
	if(!this.febeInitDir()){return false;}
	this.febePathName = ""
	if(!this.febePickRestoreFile("ffhistory*.json",88)){return true};

	let check = this.febePrName.match(/^ffhistory(.*)\.json$/ig);
	if(!check){
		var tmp = FEBE.febeStyle.purpleBold+this.febeMsg[82].replace("%FILE%","'"+this.febePrName+"'")+"\n";
		tmp += FEBE.febeStyle.orangeredBold+this.febeMsg[46];
		this.febeAlert(tmp);
		return false;
	}

	this.febeBUdate = this.febeGetBuDate(this.febePathName);
	if(this.febeConfirmRestore(74,this.febeBUdate)){
				
		let dFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
		dFile.initWithPath(this.febePathName);
		
		let fis = Cc["@mozilla.org/network/file-input-stream;1"].createInstance(Ci.nsIFileInputStream);
		fis.init(dFile, 0x01, 0x124, 0);
		fis.QueryInterface(Ci.nsILineInputStream);

		let cis = Cc["@mozilla.org/intl/converter-input-stream;1"].createInstance(Ci.nsIConverterInputStream);
		cis.init(fis,"UTF-8", 0, 0x0000);
		
		let lis = cis.QueryInterface(Ci.nsIUnicharLineInputStream);
		
		let wm = Cc["@mozilla.org/appshell/window-mediator;1"].getService(Ci.nsIWindowMediator);
		let win = wm.getMostRecentWindow("navigator:browser");
		let file = win.FileUtils.getFile('ProfD', ['formhistory.sqlite']);
		let DB = win.Services.storage.openDatabase(file);	
		
		// read lines into array and parse into individual fields
		let line = {}, hasmore;	
		let cnt = cnt2 = 0, props, stmt;
		let sqliteFile = "formhistory";
		let tableName = "moz_formhistory";
		let result;
		DB.beginTransactionAs(DB.TRANSACTION_IMMEDIATE); 
		do {
			hasmore = lis.readLine(line);
			let ffObj = JSON.parse(line.value);
			if(cnt == 0){
				if(!this.objIsInstanceOf(ffObj,DB,tableName)){
					let tmp = this.febeMsg[548]+"\n\n"+this.febeMsg[546];
					this.febeAlert(tmp);
					return false;
				}else{
					result = DB.createStatement("DROP TABLE moz_deleted_formhistory");
					result.executeAsync();			
					
					result = DB.createStatement("DROP TABLE moz_formhistory");
					result.executeAsync();					
					
					stmt = "CREATE TABLE moz_deleted_formhistory (id INTEGER PRIMARY KEY, timeDeleted INTEGER, guid TEXT)";
					result = DB.createStatement(stmt);
					result.executeAsync();					

					
					stmt = "CREATE TABLE moz_formhistory (id INTEGER PRIMARY KEY, fieldname TEXT NOT NULL, value TEXT NOT NULL, timesUsed INTEGER, firstUsed INTEGER, lastUsed INTEGER, guid TEXT)";
					result = DB.createStatement(stmt);
					result.executeAsync();					
				}
				props = this.getPropertyNamesFromSqlite(DB,tableName);
			}

			stmt = "INSERT INTO "+tableName+" VALUES(";
			for(let i=0; i<props.length; i++){
				stmt = stmt+":"+[props[i]];
				if(i<props.length-1){
					stmt = stmt+", ";
				}else{
					stmt = stmt+")";
				}
			}
			
			try{
				result = DB.createStatement(stmt);
				for(let i=0; i<props.length; i++){
					result.params[props[i]] = FEBE.sqliteEscape(ffObj[props[i]]);
				}
				result.executeAsync();
			}catch(e){
				FEBE.logMsg("Error writing formfill item: "+ffObj.id+"\n"+e)
			}finally{
				result.finalize();
			}
			cnt++;
		} while(hasmore);
		
		DB.commitTransaction();
		cis.close();
		fis.close();
		DB.asyncClose();
		this.febeAlert(this.febeMsg[89]+" ("+cnt+")");
	}else{
		this.febeAlert(this.febeMsg[46]);
	}
	return true;
},

sqliteEscape: function(val){
	// Replace all single quotes with two single quotes so that the value can be inserted into sqlite
	let str = new String(val);
	let retVal = str.replace(/'/g,"''");
	return retVal;
},

febeMakeGUID: function (){
	var rg = Cc["@mozilla.org/security/random-generator;1"]
						.createInstance(Ci.nsIRandomGenerator);
	var bytes = rg.generateRandomBytes(12);
	var str = chr = byte = "";
	for(var b in bytes){
		byte = bytes[b];
		chr = String.fromCharCode(byte);
		str += chr;
	}
	return btoa(str);
},

febeRestorePermissions: function (){
	this.febeSetMsgs();
	if(!this.febeInitDir()){return false;}
	this.febePathName = ""
	if(!this.febePickRestoreFile("permissionsFx*.fbu",35)){return true};

	let check = this.febePrName.match(/^permissionsFx(.*)\.fbu$/ig);
	if(!check){
		var tmp = FEBE.febeStyle.purpleBold+this.febeMsg[96].replace("%FILE%","'"+this.febePrName+"'")+"\n";
		tmp += FEBE.febeStyle.orangeredBold+this.febeMsg[46];
		this.febeAlert(tmp);
		return false;
	}

	this.febeBUdate = this.febeGetBuDate(this.febePathName);
	if(this.febeConfirmRestore(118,this.febeBUdate)){	
		var sourceDir = this.febePfParent;
		var destDir = this.febeProfDir.path;
		var zipName = this.febePfName;
		this.febeUnzip(sourceDir,destDir,zipName);		
		this.febeAlert(this.febeMsg[119]+"\n\n"+this.febeMsg[129],true);
		this.febeRestartFx();
	}else{
		this.febeAlert(this.febeMsg[46]);
	}
	return true;
},

febeInitInputFile: function(filename){
	var ios = Cc["@mozilla.org/network/io-service;1"].getService(Ci.nsIIOService);
	var inFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
	inFile.initWithPath(filename);
	
	var fis = Cc["@mozilla.org/network/file-input-stream;1"].createInstance(Ci.nsIFileInputStream);
	fis.init(inFile, 0x01, 0x124, 0);
	fis.QueryInterface(Ci.nsILineInputStream);

	var cis = Cc["@mozilla.org/intl/converter-input-stream;1"].createInstance(Ci.nsIConverterInputStream);
	cis.init(fis,"UTF-8", 0, 0x0000);
	var lis = cis.QueryInterface(Ci.nsIUnicharLineInputStream);
	return lis;
},

febeRestoreUDBU: function (index){
	var udbuLabel = this.febeUDBuList[index].Label;
	var udbuDescription = this.febeUDBuList[index].Description;
	var udbuType = parseInt(this.febeUDBuList[index].Type);
	var udbuPath = this.febeUDBuList[index].Path; 
	this.febePathName = ""
	if(!this.febeInitDir()){return false;}
	var fMask = udbuLabel.replace(/ /g,"?")+"*";
	if(udbuType == 1){fMask = udbuLabel.replace(/ /g,"?")+"*.fbu";}
	if(!this.febePickRestoreFile(fMask,161)){return false;};
	this.febeBUdate = this.febeGetBuDate(this.febePathName);
	this.febeMsg = FEBEstorage.getItem("febeMsg", this.febeMsg);
	this.febeMsg[163] = this.febeMsg[163].replace(/%fname%/,udbuDescription);
	this.febeMsg[164] = this.febeMsg[164].replace(/%fname%/,udbuDescription);
	if(udbuType == 0){
	  // File restore is a straight copy
		if(this.febeConfirmRestore(163,this.febeBUdate)){
			this.febeCopyFile(this.febePathName,this.febeParent(udbuPath),this.febeLeafname(udbuPath));
			this.febeAlert(this.febeMsg[164]);
		}else{
			this.febeAlert(this.febeMsg[46]);
		}
	}else{
	  // Restore backed up folder
		if(this.febeConfirmRestore(163,this.febeBUdate)){
			var zipFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
			zipFile.initWithPath(udbuPath);
		
			var sourceDir = this.febePfParent;
			this.febeGetPrefs();
			var destDir = "";
			if(this.febePlatform == 1){destDir = udbuPath.substr(0,3)};	// e.g., "C:\\"
			if(this.febePlatform == 2){destDir = "/";}
			if(this.febePlatform == 3){destDir = "/";}

			var zipName = this.febePrName;
			var OK = true;
			OK = this.febeUnzip(sourceDir,destDir,zipName);
			if(OK){
				this.febeChmod(destDir);
				this.febeAlert(this.febeMsg[164].replace("%fname%",udbuLabel));
			}else{
				this.febeAlert(this.febeMsg[46]);
			}
		}
	}
	return true;
},

// ------------------ End of Restore Functions ------------

completionFailed: function(which,reason){
	// reason = 1 = The statement stopped executing because it was canceled.
	// reason = 2 = The statement stopped executing because an error occurred.
	if(reason == 1){	// If an error occured, it would already be handled in the 'databaseReadError' routine, so only show 'canceled' message
		let tmp = "The reading of the "+which+" database was cancelled";
		FEBE.febeAlert(tmp,true);
	}
	return true;
},

databaseReadError: function(which,err){
	let tmp = "databaseReadError() - An error occured reading the "+which+" database.\n\n";
	tmp += err.message;
	febeDebug(tmp)
	//FEBE.febeAlert(tmp,true);  	// This window opens behind other windows and cannot be seen - don't display it, just note it on the results report
	switch(which){
		case 'cookies':
			if(FEBE.febeBuCookies) FEBE.selectedItemsList['cookies'].error = tmp;			break;;
		case 'formfill history':
			if(FEBE.febeBuFormFillHistory) FEBE.selectedItemsList['formfillHistory'].error = tmp;
			break;;
		case 'permissions':
			if(FEBE.febeBuPermissions) FEBE.selectedItemsList['permissions'].error = tmp;
			break;;
	}
	return true;
},

objIsInstanceOf: function(jsonObj,sqliteDB,tableName){
	// Determine if jsonObj has the same number/names of properties as there are columns in the tableName of database file sqliteFile
	// Data types are not considered, only property names
	// sqliteDB must already be open
	let DB = sqliteDB;
	let stmt = "SELECT * FROM "+tableName+" LIMIT 1";
	let result = DB.createStatement(stmt);
	let sqliteObj = {};
	for(let i=0; i<result.columnCount; i++){
		let propName = result.getColumnName(i);
		sqliteObj[propName] = "";
	}
	
	let ok = true;
	for(let prop in jsonObj){
		if(typeof sqliteObj[prop] === "undefined"){
			ok = false;
			break;
		}
	}
	if(!ok) return false;
	for(let prop in sqliteObj){
		if(typeof jsonObj[prop] === "undefined"){
			ok = false;
			break;
		}
	}
	return ok;
},

getPropertyNamesFromSqlite: function(sqliteFile,tableName){
	// Return an array of column names from a sqlite table
	// sqliteFile must already be open
	
	let DB = sqliteFile;

	let stmt = "SELECT * FROM "+tableName+" LIMIT 1";
	let result = DB.createStatement(stmt);
	let sqliteObj = {};
	let props = [];
	for(let i=0; i<result.columnCount; i++){
		let propName = result.getColumnName(i);
		props.push(propName);
	}
	//DB.close();
	return props;
},

febeReturnList: function (){
	return this.febeBuItemVerifiedList;
},

febeGotNewInstall: function (aInstall) {
	var name = aInstall.file.leafName;
	(function() {
	if(aInstall.error == 0){this.febeBuItemVerifiedList[name].verified = true;} 
	}).call(this.febeBuItemVerifiedList);
},

febeVerifyBackup: function (){
	this.febeBuItemVerifiedList = {};
	this.febeVerifyExtList = [];

	if(this.febeVerifyBackups == false) return true;
	this.febeGetBUList();
	this.febeVerifyBackup2();
	return true;
},

showProfileFolder: function(){
	let currProfD = Services.dirsvc.get("ProfD", Ci.nsIFile);
	let profileDir = currProfD.path;
	this.showFolder(profileDir);
},

showFolder: function(folder,encoded){
	// Open a folder outside of the browser
	if(folder == ""){
		FEBE.febeAlert(FEBE.febeMsg[525]);
		return false;
	}
	if(encoded) folder = decodeURIComponent(folder);
	let nsLocalFile = Components.Constructor("@mozilla.org/file/local;1","nsILocalFile", "initWithPath");
	new nsLocalFile(folder).reveal();
	return true;
},

showQuickBuFolder: function(){
	let folder = document.getElementById('febeQuickBuDir').value;
	this.showFolder(folder);
},

showDropboxFolder: function(){
	let folder = document.getElementById('db.rootdir').value;
	this.showFolder(folder);
	return true;
},

showLastBuFolder: function(){
	let prefName = "extensions.febe.lastbackup.folder";
	let febeBuDestDir = "";
	if(this.febePrefs.prefHasUserValue(prefName)){
		febeBuDestDir = this.febeGetUnicharPref(prefName);
		FEBE.showFolder(febeBuDestDir,false);
	}else{
		FEBE.febeAlert(FEBE.febeMsg[524]);
		return false;
	}
	return true;
},

febeGetBUList: function (){
	var buDir = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
	if (!buDir) return false;

	buDir.initWithPath(this.febeExBuDir);
	var entries = buDir.directoryEntries;
	while(entries.hasMoreElements()){
		var entry = entries.getNext();
		entry.QueryInterface(Ci.nsIFile);
		var type = this.febeGetEntryType(entry);
		var name = entry.leafName;
		this.febeBuItemVerifiedList[name] = new Object;
		this.febeBuItemVerifiedList[name].verified = false;
		this.febeBuItemVerifiedList[name].file = entry;
		if(type == "extension"){this.febeVerifyExtList.push(entry);}
	}
	return true;		
},

febeVerifyBackup2: function (){
	var listener = {onNewInstall: FEBE.febeGotNewInstall};
	AddonManager.addInstallListener(listener);
	var xpiCount = this.febeVerifyExtList.length;
	this.febeVerifyExtList.forEach(function(aFile) {
		AddonManager.getInstallForFile(aFile, function(aInstall) {
			if (--xpiCount == 0) {
				AddonManager.removeInstallListener(listener);
			}
		});
	});
	return true;
},

febeVerifyExtension: function (ext){
	var listener = {onNewInstall: FEBE.febeGotNewInstall};
	AddonManager.addInstallListener(listener);
	AddonManager.getInstallForFile(aFile, function(aInstall) {
			AddonManager.removeInstallListener(listener);
	});
},

febeDoVerify: function (list){
	var xpiCount = list.length;
	list.forEach(function(aFile) {
		AddonManager.getInstallForFile(aFile, function(aInstall) {
			if (--xpiCount == 0) {
				AddonManager.removeInstallListener(listener);
			}
		});
	});
},

febeGetEntryType: function (entry){
	var type = "";
	var name = entry.leafName;
	if(name == "AllInstalledLightweightThemes.personas.json"){
		type = "AllInstalledLightweightThemes";
		return type;
	}
	var p = name.lastIndexOf(".");
	var ext = name.substring(p);
	switch(ext){
		case ".xpi":
			type = "extension";
			break;
		case ".jar":
			type = "theme";
			break;
		case ".fbu":
			if(name.match(/^profileFx[\d+].*\{.*\}\.fbu$/) != null){
				type = "profile";
			}
			if(name.substr(0,14) == "searchPlugins{"){
				type = "searchPlugin";
			}
			break;
		case ".html":
			if(name.substr(0,10) == "bookmarks{"){
				type = "bookmarksHTML";
			}
			if(name.substr(0,14) == "Results - FEBE"){
				type = "resultspage";
			}
			break;
		case ".js":
			if(name.substr(0,6) == "prefs{"){
				type = "prefs";
			}
			break;
		case ".json":
			if(name.substr(-13,13) == ".persona.json"){
				type = "persona";
			}
			if(name.substr(0,10) == "bookmarks{"){
				type = "bookmarksJSON";
			}
			if(name.substr(0,8) == "cookies{"){
				type = "cookies";
			}
			if(name.substr(0,8) == "history{"){
				type = "history";
			}
			if(name.substr(0,10) == "FEBE data{"){
				type = "febedata";
			}
			break;
		default:
			type="unknown";
			break;
	}//switch
	return type;
},

// FEBE Options routines	
febeBuSelectAll: function (bool) {
	let box = document.getElementById("additionalItemsID");
	let checkboxes = box.getElementsByTagName("checkbox");
	let id, prefname;
	for(let i=0; i<checkboxes.length; i++){
		if(!checkboxes[i].disabled){
			checkboxes[i].setAttribute("checked",bool);
			id = checkboxes[i].id;	// The ID is the same as the preference name.  Clever, eh?
			prefname = id.replace(/_/g,".");
			this.febePrefs.setBoolPref(prefname,bool);
		}
	}
	for(let i in FEBE.selectedItemsList){
		//let which = FEBE.selectedItemsList[i];
		FEBE.febeCheckAdditional(i,true);
	}
	this.febeBuProfileCheck();
	return true;
},

febeAddEventListeners: function (){
	var butype = document.getElementById("febeBackupType");
	butype.addEventListener("RadioStateChange", FEBE.febeBuDisableSelective, false);
},

febeBuDisableSelective: function() {
	var type = document.getElementById("febeBackupType").selectedItem.value;
	var bool = false;
	if(type == "profile") bool = true;
	document.getElementById("buExtensions_id").disabled = bool;
	document.getElementById("buThemes_id").disabled = bool;
	var box = document.getElementById("additionalItemsID");
	var checkboxes = box.getElementsByTagName("checkbox");
	for(var i=0; i<checkboxes.length; i++){
		checkboxes[i].disabled = bool;
	}
	document.getElementById("buSelectAll").disabled = bool;
	document.getElementById("buDeselectAll").disabled = bool;
	
	FEBE.febeBuProfileCheck();
	return true;
},

febeOptPrefInit: function() {	
	var box = document.getElementById("additionalItemsID");
	var checkboxes = box.getElementsByTagName("checkbox");
	for(var i=0; i<checkboxes.length; i++){
		if(!checkboxes[i].disabled){
			var id = checkboxes[i].id;
			var prefname = id.replace(/_/g,".");
			var bool = this.febePrefs.getBoolPref(prefname);
			checkboxes[i].setAttribute("checked",bool);
		}
	}
	return true;
},

febeBuProfileCheck: function (){
	this.febeSetMsgs();
	let attrb = "disabled";
	try{  	
		let buType = this.febePrefs.getCharPref("extensions.febe.buType");

		if(buType == "profile"){  // Disable options if profile backup is checked
			document.getElementById("febeBuExtensions_id").setAttribute(attrb,true);
			document.getElementById("febeBuThemes_id").setAttribute(attrb,true);
			document.getElementById("extensions_febe_buBookmarks_json").setAttribute(attrb,true);
			document.getElementById("extensions_febe_buBookmarks_html").setAttribute(attrb,true);
			document.getElementById("extensions_febe_buPreferences").setAttribute(attrb,true);
			document.getElementById("extensions_febe_buCookies").setAttribute(attrb,true);
			document.getElementById("extensions_febe_buUserChrome").setAttribute(attrb,true);
			document.getElementById("extensions_febe_buUserPwd").setAttribute(attrb,true);
			document.getElementById("extensions_febe_buSearchPlugins").setAttribute(attrb,true);
			document.getElementById("extensions_febe_buBrowserHistory").setAttribute(attrb,true);
			document.getElementById("extensions_febe_buFormFillHistory").setAttribute(attrb,true);
			document.getElementById("extensions_febe_buPermissions").setAttribute(attrb,true);
			document.getElementById("extensions_febe_buUDBu").setAttribute(attrb,true);
		} else {
			document.getElementById("febeBuExtensions_id").setAttribute(attrb,false);
			document.getElementById("febeBuThemes_id").setAttribute(attrb,false);
			document.getElementById("extensions_febe_buBookmarks_json").setAttribute(attrb,false);
			document.getElementById("extensions_febe_buBookmarks_html").setAttribute(attrb,false);
			document.getElementById("extensions_febe_buPreferences").setAttribute(attrb,false);
			document.getElementById("extensions_febe_buCookies").setAttribute(attrb,false);
			document.getElementById("extensions_febe_buUserChrome").setAttribute(attrb,false);
			document.getElementById("extensions_febe_buUserPwd").setAttribute(attrb,false);
			document.getElementById("extensions_febe_buSearchPlugins").setAttribute(attrb,false);
			document.getElementById("extensions_febe_buBrowserHistory").setAttribute(attrb,false);
			document.getElementById("extensions_febe_buFormFillHistory").setAttribute(attrb,false);
			document.getElementById("extensions_febe_buPermissions").setAttribute(attrb,false);
			document.getElementById("extensions_febe_buUDBu").setAttribute(attrb,false);
			febeOptionsCheck();
		}
	}catch(e){;}
	window.removeEventListener("load",this.febeBuProfileCheck,true);
	return true;
},	

febeSelExt: function (){
  // Select extensions to backup
  var uri = "chrome://febe/content/febeSelExt.xul";
	window.open(uri, 'FEBE Select Extensions','chrome,alwaysRaised,centerscreen,resizable');
},

febeSelTheme: function (){
  // Select extensions to backup
  var uri = "chrome://febe/content/febeSelTheme.xul";
	window.open(uri, 'FEBE Select Themes', 'chrome,alwaysRaised,centerscreen,resizable');
},

febeSelBUDestDir: function (){
  // Select backup destinaton directory
	const nsIFilePicker = Ci.nsIFilePicker;
	var fp = Cc["@mozilla.org/filepicker;1"].createInstance(nsIFilePicker);
	fp.init(window, FEBE.febeMsg[5], nsIFilePicker.modeGetFolder);
	fp.appendFilters(nsIFilePicker.filterAll | nsIFilePicker.filterText);

    // Set default directory to current backup directory
	if(FEBE.febePrefs.prefHasUserValue("extensions.febe.extBUdir")){
		var extBUdir = FEBE.febeGetUnicharPref("extensions.febe.extBUdir");
		if(extBUdir != ""){
			var dd = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
			try{
				dd.initWithPath(extBUdir);
				fp.displayDirectory = dd;
			}catch(e){;;}
		}
	}
	var rv = fp.show();
	if (rv == nsIFilePicker.returnOK){
		rv = fp.file;
		extBUdir = rv.path;
		FEBE.febeSetUnicharPref("extensions.febe.extBUdir", extBUdir);
		document.getElementById("DestDirID").value = extBUdir;
		var d = document.getElementById("DestDirID");
		d.setAttribute("value",extBUdir);
	}
	FEBE.febeCheckBuDestDir();
	return true;
},

febeSetStatusbarVisibility: function(hide){
	let wm = Cc["@mozilla.org/appshell/window-mediator;1"].getService(Ci.nsIWindowMediator);
	let enumerator = wm.getEnumerator("navigator:browser");
	while(enumerator.hasMoreElements()) {
		let win = enumerator.getNext();
		let febestatusbar = win.document.getElementById("febestatusbar");
		if(Boolean(febestatusbar)){febestatusbar.hidden = febestatusbar.collapsed = hide;}	
	}
	return true;
},

febeSetStatus: function (){
 // Set statusbar icon
	let windowtype = document.documentElement.getAttribute("windowtype");
	let OK = false;
	if(windowtype == "navigator:browser") OK = true;
	if(windowtype == "febe:options") OK = true;
	if(windowtype == "febe:progress") OK = true;
	if(!OK) return true;
	
	if(!Boolean(FEBE.febeControllerWindow)){FEBE.febeScheduleController();}
	
	let statusbar = FEBE.febeControllerWindow.document.getElementById("febestatusbar");
	if(!Boolean(statusbar)){return false;}
	statusbar.hidden = statusbar.collapsed = FEBE.febeHideIcons;
	
	FEBE.febeSetMsgs();
	FEBE.setDelayedBuVars(null);
	if(FEBE.febeDelayedBu.initiated){
		statusbar.setAttribute('status',"delayed");
		statusbar.tooltipText = FEBE.febeDelayedBu.tooltip;
		return true;
	}
	FEBE.febeSetIsScheduled();
	FEBE.febeNextBackup = FEBE.febePrefs.getCharPref("extensions.febe.schedule.next.backup");
	
	let tmp;
	if(FEBE.febeIsScheduled){
		statusbar.setAttribute('status',"normal");
		tmp = FEBE.febeMsg[114] + FEBE.febeNextBackup;
	}else{
		statusbar.setAttribute('status',"nobackup");
		tmp = FEBE.febeMsg[113];
	}
	statusbar.tooltipText = tmp;
	return true;
},

febeClearPrefs: function (){
	FEBE.setStyles();
	let tmp = FEBE.febeMsg[126]+"\n"+FEBE.febeMsg[127]+"\n\n";
	let style = FEBE.febeStyle.orangeredBold;
	tmp += style+FEBE.febeMsg[183]+"\n\n";
	tmp += FEBE.febeMsg[128]
	let ok = FEBE.febeConfirm(tmp);
	if(!ok){return false;}
	
	// Clear Box.net credentials	
	try {
		// delete the user-defined data file if it exists
		FEBE.febeDataFile = Cc["@mozilla.org/file/directory_service;1"].getService(Ci.nsIProperties).get("ProfD", Ci.nsIFile);
		FEBE.febeDataFile.append(FEBE.FEBEDATAFILE);
		if(FEBE.febeDataFile.exists()){FEBE.febeDataFile.remove(false);}
		
		// delete the ignore list data file if it exists then reuild it
		FEBE.febeDataFile = Cc["@mozilla.org/file/directory_service;1"].getService(Ci.nsIProperties).get("ProfD", Ci.nsIFile);
		FEBE.febeDataFile.append(FEBE.FEBEIGNORELISTDATAFILE);
		if(FEBE.febeDataFile.exists()){FEBE.febeDataFile.remove(false);}
		FEBE.febeGetAddonList();

		// clear FEBE preferences
		let prefCount = {value:0}; 
		let prefService = Cc["@mozilla.org/preferences-service;1"].getService(Ci.nsIPrefService); 
		let prefBranch = prefService.getBranch(null); 
		let prefArray = prefBranch.getChildList("extensions.febe." , prefCount); 
		for (let i = 0; i < prefCount.value; i++){
			if(prefBranch.prefHasUserValue(prefArray[i])){prefBranch.clearUserPref(prefArray[i]);}
		}
		prefBranch.deleteBranch("extensions.febe.");
		
	}catch (e) {
		alert(e);
		return false;
  }
	let version = FEBE.febeGetVersion();
	FEBE.febePrefs.setCharPref("extensions.febe.previousversion",version);
	alert(FEBE.febeMsg[129]);
	FEBE.febeRestartFx();
	return true;
},

febeViewPrefs: function (){
		let prefCount = {value:0}; 
		let prefService = Cc["@mozilla.org/preferences-service;1"].getService(Ci.nsIPrefService); 
		let prefBranch = prefService.getBranch(null); 
		let prefArray = prefBranch.getChildList("extensions.febe." , prefCount); 
		prefArray.sort(); 
		for (let i = 0; i < prefCount.value; i++){
			let pref = prefArray[i];
			let type = prefBranch.getPrefType(pref);
			let value = "";
			let color = "red";
			let status = (prefBranch.prefHasUserValue(pref)) ? "(user set value)" : "(default value)";
			
			switch(type){
				case 32:
					color = "green";
					value = prefBranch.getCharPref(pref);
					if(value == ""){
						value = "[blank]";
					}else{
						value = "'"+value+"'";				
					}
					break;
				case 64:
					color = "crimson";
					value = prefBranch.getIntPref(pref).toString();
					break;
				case 128:
					color = "purple";
					value = prefBranch.getBoolPref(pref).toString();
					break;
			}
			febeprt(prefArray[i]+" : "+value+"   :: "+status+" ::",color,0,null);
		}
		febeprt("",null,0,null);
		let msg = FEBE.febeMsg[543].replace("%CNT%",prefCount.value);
		febeprt(msg,"black!",1,null);
		FEBE.febePlaySound('success');

	function febeprt(txt,color,numBlankLines,img){
		if(!color) color="black";
		if(!numBlankLines) numBlankLines = 0;
		if(!img) img = false;
		let bold = false;
		if(color.indexOf('!') > 0){
			bold = true;
			color = color.replace('!','');
		}
		let box = document.getElementById('messages');
		let body = box.contentDocument.body;
		
		let span = document.createElementNS(FEBE.febeNamespace,'span');
		span.style.color = color;
		span.style.fontWeight = "normal";
		if(bold) span.style.fontWeight = "bold"; 
		span.style.fontFamily = "Arial";
		span.style.fontSize = "12px";
		
		if(img != false){
			let image = document.createElementNS(FEBE.febeNamespace,'img');
			image.src = img;
			image.style='border: 0px solid ; width: 16px; height: 16px;'
			span.appendChild(image);
			txt += " ";
		}
		
		let msg = document.createTextNode(txt);
		span.appendChild(msg);
		body.appendChild(span);
		body.appendChild(document.createElementNS(FEBE.febeNamespace,'br'));
		
		for(let i=0; i<numBlankLines; i++){
			let br = document.createElementNS(FEBE.febeNamespace,'br');
			body.appendChild(br);
		}
		
		// Scroll to bottom after each write
		let scrollBox = box.contentWindow.document.body;
		scrollBox.scrollTop = scrollBox.scrollHeight - scrollBox.clientHeight;
		
		// Add contents to clipboard array
		FEBE.febeClipboard.push(txt);
		return true;
	}
	return true;
},

febeExportPrefs: function (){
	let dir = FEBE.febeGetUnicharPref("extensions.febe.exportprefs.directory");
	let fname = FEBE.febeGetUnicharPref("extensions.febe.exportprefs.fname");
	if(dir == "" || fname == ""){
		FEBE.febeError(FEBE.febeMsg[367]);
		return false;
	}
	let uri = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
	try{
		uri.initWithPath(dir);
	}catch(e){
		let tmp = FEBE.febeMsg[329].replace("%DIR%",dir);
		tmp += "\n\n"+e.toString();
		FEBE.febeError(tmp);
		return false;
	}
	uri.append(fname+".json");
	if(uri.exists()){
		let tmp = FEBE.febeMsg[331].replace("%DIR%",uri.path);
		tmp+= "\n\n"+FEBE.febeMsg[332];
		if(!FEBE.febeConfirm(tmp)){return true;}
	}

	let fos, cos, cnt = 0;
	
	fos = Cc["@mozilla.org/network/file-output-stream;1"].createInstance(Ci.nsIFileOutputStream);
	fos.init(uri, 0x02 | 0x08 | 0x20, 0x1ED, 0); // write, create, truncate
	
	cos = Cc["@mozilla.org/intl/converter-output-stream;1"].createInstance(Ci.nsIConverterOutputStream);
	cos.init(fos, "UTF-8", 0, 0x0000);
	
	let prefCount = {value:0}; 
	let prefService = Cc["@mozilla.org/preferences-service;1"].getService(Ci.nsIPrefService); 
	let prefBranch = prefService.getBranch(null); 
	let prefArray = prefBranch.getChildList("extensions.febe." , prefCount); 
	let prefs = Cc["@mozilla.org/preferences-service;1"].getService(Ci.nsIPrefBranch);

	for (i = 0; i < prefCount.value; i++){
		let prefName = prefArray[i];
		let type = prefBranch.getPrefType(prefName);
		let prefObj = new Object;
		prefObj.name = prefName;
		switch (type){
			case prefs.PREF_BOOL:	
				prefObj.type = "BOOL";
				prefObj.value = prefs.getBoolPref(prefName);
				break;
			case prefs.PREF_INT:
				prefObj.type = "INT";	
				prefObj.value = prefs.getIntPref(prefName);				
				break;
			case prefs.PREF_STRING:
				prefObj.type = "STRING";
				prefObj.value = prefs.getComplexValue(prefName, Ci.nsISupportsString).data;
				break;
		}//switch
		let jstr = JSON.stringify(prefObj);
		cos.writeString(jstr+"\n"); 
		cnt++;
	}

	cos.close();
	fos.close();
	let tmp = FEBE.febeMsg[330].replace("%NUM%",cnt);
	tmp = tmp.replace("%DIR%","\n"+uri.path);
	FEBE.febeAlert(tmp);
},

febeBrowseForExportDir: function (){
	let d = document.getElementById("exportprefsdirID");
	let dir = FEBE.febePickDir(d.value,328);
	if(dir == false) return false;
	d.setAttribute("value",dir);
	FEBE.febeSetUnicharPref("extensions.febe.exportprefs.directory",dir);
	return true;
},

febeImportPrefs: function (){
	let file = FEBE.febeBrowseForImportFile();
	if(file == false) return true;
	FEBE.febeBUdate = FEBE.febeGetBuDate(file);
	if(FEBE.febeConfirmRestore(334,FEBE.febeBUdate)){
		//let JSON = Cc["@mozilla.org/dom/json;1"].createInstance(Ci.nsIJSON);

		let ios = Cc["@mozilla.org/network/io-service;1"].getService(Ci.nsIIOService);

		let dFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
		dFile.initWithPath(file);
		
		let fis = Cc["@mozilla.org/network/file-input-stream;1"].createInstance(Ci.nsIFileInputStream);
		fis.init(dFile, 0x01, 0x124, 0);
		fis.QueryInterface(Ci.nsILineInputStream);

		let cis = Cc["@mozilla.org/intl/converter-input-stream;1"].createInstance(Ci.nsIConverterInputStream);
		cis.init(fis,"UTF-8", 0, 0x0000);
		
		let lis = cis.QueryInterface(Ci.nsIUnicharLineInputStream);

		// Only import prefs that are currently used.  Ignore old, deprecated prefs
		let line = {}, hasmore, cnt = 0;
		let badPrefs = [];
		do {
			hasmore = lis.readLine(line);
			let pref = JSON.parse(line.value);
			let type = pref.type;
			let prefName = pref.name;
			let prefValue = pref.value
			switch(type){
				case "BOOL":	
					try{
						let v = FEBE.febePrefs.getBoolPref(prefName);	// Try reading the value first.  If it doesn't exist, an error will occur
						FEBE.febePrefs.setBoolPref(prefName,prefValue);
						cnt++;
					}catch(e){badPrefs.push(prefName+" : "+type+" : "+prefValue);}
					break;
				case "INT":
					try{
						let v = FEBE.febePrefs.getIntPref(prefName);
						FEBE.febePrefs.setIntPref(prefName,prefValue);
						cnt++;
					}catch(e){badPrefs.push(prefName+" : "+type+" : "+prefValue);}
					break;
				case "STRING":
					try{
						let v = FEBE.febeGetUnicharPref(prefName);
						FEBE.febeSetUnicharPref(prefName, prefValue);
						cnt++;
					}catch(e){badPrefs.push(prefName+" : "+type+" : '"+prefValue+"'");}
					break;
			}//switch
		} while(hasmore);

		FEBE.setStyles();
		let tmp = FEBE.febeMsg[335].replace("%NUM%",cnt)+"\n\n";
		let l = badPrefs.length;
		if(l != 0){
			tmp += FEBE.orangered+FEBE.febeMsg[337].replace("%CNT%",l)+"\n";
			for(let i=0; i<l; i++){
				tmp+= FEBE.febeStyle.black+badPrefs[i]+"\n";
			}
		}
		FEBE.febeAlert(tmp);
	}else{
		FEBE.febeAlert(FEBE.febeMsg[336]);
	}
	return true;
},

febeBrowseForFolder: function(id,prefID){
	let d = document.getElementById(id);
	let pref = document.getElementById(prefID);
	let dir = this.febePickDir(d.value,328);
	if(dir == false) return false;
	d.setAttribute('value',dir);
	this.febeSetUnicharPref(pref.name, dir);
	return true;
},

febeOptionsSanityCheck: function(){
	// Check options for valid entries
},

febeBrowseForImportFile: function (){
	let extportdir = FEBE.febeGetUnicharPref("extensions.febe.exportprefs.directory");
	let file = FEBE.febePickFile("*.json",333,extportdir);
	if(file == false) return false;
	return file;
},

febeViewBuDir: function (id){
	let dir = document.getElementById(id).value;
	FEBE.febeOpenLink("file:///"+dir);
	return true;
},

verifyBuDirOpen: function(id){
	let opts = this.febeSetWinOpts(false);
	this.febeWin = window.openDialog('chrome://febe/content/febeVerifyBuDir.xul','FEBE Verify',opts,id);	
	this.febeWin.focus();
	return true;
},

verifyBuDir: function(){
	let id = window.arguments[0];
	let optWin = Cc["@mozilla.org/appshell/window-mediator;1"].getService(Ci.nsIWindowMediator).getMostRecentWindow("febe:options");

	let buDestDir = optWin.document.getElementById(id).value;
	let flag = frOK = fwOK = fdOK = drOK = dwOK = dcOK = ddOK = dsOK = false;
	let dir, dte, fname, dname, testFile, testDir, buDir;
	let rng, bytes, wData, rData="", fos, cos, fis, cis, line, lis, hasmore;
	
	// Generate a string of random data
	rng = Cc["@mozilla.org/security/random-generator;1"]
					.createInstance(Ci.nsIRandomGenerator);
	bytes = rng.generateRandomBytes(65536);
	for(let i=0;i<bytes.length;i++) wData += String.fromCharCode(bytes[i]); 
	wData = btoa(wData);

	// Verify the directory exists
	buDir = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
	buDir.initWithPath(buDestDir);
	if(!buDir.exists()){
		febeprt(this.febeMsg[432].replace('%DIR%',buDestDir),"red");
		this.febePlaySound('failure');
		return false;
	}else{
		febeprt(this.febeMsg[433].replace('%DIR%',buDestDir),"green");
	}
	if(!buDir.isWritable()){
		febeprt(this.febeMsg[434],"red");
		flag = true;
	}else{
		febeprt(this.febeMsg[435],"green");
		fwOK = true;
	}
	if(!buDir.isReadable()){
		febeprt(this.febeMsg[436],"red");
		flag = true;
	}else{
		febeprt(this.febeMsg[437],"green");
		frOK = true;
	}
	febeprt(this.febeMsg[438].replace('%PERMS%',getPerms(buDir)),"purple");
	if(flag){
		buDir.permissions = 0x1FF;	// '0777' - read, write

		if(!buDir.isWritable()){
			febeprt(this.febeMsg[439],"red");
		}else{
			febeprt(this.febeMsg[440],"green");
			fwOK = true;
		}
		if(!buDir.isReadable()){
			febeprt(this.febeMsg[441],"red");
		}else{
			febeprt(this.febeMsg[442],"green");
			frOK = true;
		}
	}
	
	// See if we can create, read, write and delete a file in the directory
	dte = new Date();
	fname = "febeTmpFile-"+dte.getTime();
	dir = buDir.clone();
	dir.append(fname);
	dir.create(Ci.nsIFile.NORMAL_FILE_TYPE, 0x1FF);	// 0x1ED = 0755, 0x1FF = 0777
	testFile = dir;
	
	// Write the data to the file
	fos = Cc["@mozilla.org/network/file-output-stream;1"].createInstance(Ci.nsIFileOutputStream);
	fos.init(testFile, 0x02 | 0x08 | 0x20, 0x1ED, 0); // write, create, truncate with 0777 permissions
	cos = Cc["@mozilla.org/intl/converter-output-stream;1"].createInstance(Ci.nsIConverterOutputStream);
	cos.init(fos, "UTF-8", 0, 0x0000);
		
	try{
		cos.writeString(wData); 
		febeprt(this.febeMsg[443],"green");
		fwOK = true;
	}catch(err){
		febeprt(this.febeMsg[444].replace('%ERR%',err),"red");
		fwOK = false;
	}
	cos.close();
	fos.close();
	febeprt(this.febeMsg[464].replace('%PERMS%',getPerms(dir)),"purple");
		
	// Read from file
	fis = Cc["@mozilla.org/network/file-input-stream;1"].createInstance(Ci.nsIFileInputStream);
	fis.init(testFile, 0x01, 0x124, 0);
	fis.QueryInterface(Ci.nsILineInputStream);

	cis = Cc["@mozilla.org/intl/converter-input-stream;1"].createInstance(Ci.nsIConverterInputStream);
	cis.init(fis,"UTF-8", 0, 0x0000);
	
	lis = cis.QueryInterface(Ci.nsIUnicharLineInputStream);
	line = {};	
	do {
		try{
			hasmore = lis.readLine(line);			
		}catch(err){
			febeprt(this.febeMsg[445].replace('%ERR%',err),"red");
		}
		rData += line.value;
	} while(hasmore);
	cis.close();
	fis.close();
	
	if(rData == wData){
		febeprt(this.febeMsg[446],"green");
		frOK = true;
	}else{
		febeprt(this.febeMsg[447],"red");
		frOK = false;
	}
	
	try{
		testFile.remove(false);
		febeprt(this.febeMsg[448],"green");
		fdOK = true;
	}catch(err){
		febeprt(this.febeMsg[449].replace('%ERR%',err),"red");
		fdOK = false;
	}
	
	// See if we can create, read, write and delete a newly created sub-directory in the directory
	dname = "febeTmpDir-"+dte.getTime();
	dir = buDir.clone();
	dir.append(dname);
	dir.create(Ci.nsIFile.DIRECTORY_TYPE, 0x1FF);	// 0x1ED = 0755, 0x1FF = 0777
	testDir = dir;
	
	if(!testDir.exists()){
		febeprt(this.febeMsg[450],"red");
	}else{
		febeprt(this.febeMsg[451],"green");
		dcOK = true;	
	}
	febeprt(this.febeMsg[466].replace('%PERMS%',getPerms(dir)),"purple");
	
	// Create a file in sub-directory
	testFile = testDir.clone();
	testFile.append(fname);
	testFile.create(Ci.nsIFile.NORMAL_FILE_TYPE, 0x1FF);	// 0x1ED = 0755, 0x1FF = 0777
	febeprt(this.febeMsg[465].replace('%PERMS%',getPerms(testFile)),"purple");
	
	// Write the data to the sub-directory file
	fos = Cc["@mozilla.org/network/file-output-stream;1"].createInstance(Ci.nsIFileOutputStream);
	fos.init(testFile, 0x02 | 0x08 | 0x20, 0x1ED, 0); // write, create, truncate with 0777 permissions
	
	cos = Cc["@mozilla.org/intl/converter-output-stream;1"].createInstance(Ci.nsIConverterOutputStream);
		cos.init(fos, "UTF-8", 0, 0x0000);
		
	try{
		cos.writeString(wData); 
		febeprt(this.febeMsg[452],"green");
		dwOK = true;
	}catch(err){
		febeprt(this.febeMsg[453].replace('%ERR%',err),"red");
		dwOK = false;
	}
	cos.close();
	fos.close();
		
	// Read data from sub-directory file
	fis = Cc["@mozilla.org/network/file-input-stream;1"].createInstance(Ci.nsIFileInputStream);
	fis.init(testFile, 0x01, 0x124, 0);
	fis.QueryInterface(Ci.nsILineInputStream);

	cis = Cc["@mozilla.org/intl/converter-input-stream;1"].createInstance(Ci.nsIConverterInputStream);
	cis.init(fis,"UTF-8", 0, 0x0000);
	
	lis = cis.QueryInterface(Ci.nsIUnicharLineInputStream);
	line = {}, rData = "";	
	do {
		try{
			hasmore = lis.readLine(line);			
		}catch(err){
			febeprt(this.febeMsg[456],"red");
		}
		rData += line.value;
	} while(hasmore);
	cis.close();
	fis.close();

	if(rData == wData){
		febeprt(this.febeMsg[455],"green");
		drOK = true;
	}else{
		febeprt(this.febeMsg[463],"red");
		drOK = false;
	}
		
	try{	// Remove sub-directory file
		testFile.remove(false);
		febeprt(this.febeMsg[457],"green");
		ddOK = true;
	}catch(err){
		febeprt(this.febeMsg[458].replace('%ERR%',err),"red");
		ddOK = false;
	}
	
	try{	// Remove sub-directory
		testDir.remove(true);
		febeprt(this.febeMsg[459],"green");
		dsOK = true;
	}catch(err){
		febeprt(this.febeMsg[460].replace('%ERR%',err),"red");
		dsOK = false;
	}

	if(frOK && fwOK && fdOK && drOK && dwOK && dcOK && ddOK && dsOK){
		febeprt(this.febeMsg[461],"purple!");
		this.febePlaySound('success');
	}else{
		febeprt(this.febeMsg[462],"red!");
		this.febePlaySound('failure');
	}
	
	function getPerms(file){
		let perm = file.permissions.toString(8);	// Convert decimal to octal
		let perms = [], mask = "", prefix;
		perms[0] = "---";
		perms[1] = "--x";
		perms[2] = "-w-";
		perms[3] = "-wx";
		perms[4] = "r--";
		perms[5] = "r-x";
		perms[6] = "rw-";
		perms[7] = "rwx";
		for(let i=0; i<3; i++){
			let index = parseInt(perm[i],10)
			mask += perms[index];
		}
		prefix = (file.isDirectory() ? "d" : "-");
		return prefix + mask + " (Octal "+perm+")";
	}
	
	function febeprt(txt,color,numBlankLines){
		if(!color) color="black";
		if(!numBlankLines) numBlankLines = 0;
		let bold = false;
		if(color.indexOf('!') > 0){
			bold = true;
			color = color.replace('!','');
		}
		let box = document.getElementById('messages');
		let body = box.contentDocument.body;
		let msg = document.createTextNode(txt);
		let br = document.createElementNS(FEBE.febeNamespace,'br');
		let span = document.createElementNS(FEBE.febeNamespace,'span');
		span.style.color = color;
		span.style.fontWeight = "normal";
		if(bold) span.style.fontWeight = "bold"; 
		span.style.fontFamily = "Arial";
		span.style.fontSize = "12px";
		span.appendChild(msg)
		body.appendChild(span);
		body.appendChild(br);
		
		for(let i=0; i<numBlankLines; i++){
			let br = document.createElementNS(FEBE.febeNamespace,'br');
			body.appendChild(br);
		}
		
		// Scroll to bottom after each write
		let scrollBox = box.contentWindow.document.body;
		scrollBox.scrollTop = scrollBox.scrollHeight - scrollBox.clientHeight;
		
		// Add contents to clipboard array
		FEBE.febeClipboard.push(txt);
		return true;
	}
	return true;
},

listAddonsLoad: function(){
	let opts = "chrome,dialog=yes,alwaysRaised,resizable,titlebar=no,popup=yes";
	this.febeWin = window.openDialog('chrome://febe/content/febeListAddons.xul','FEBE List Addons',opts);	
	this.febeWin.focus();
	return true;
},

listAddons: function(){
	let cnt = [], tot = 0;
	let list = [];
	for(let i in FEBE.febeAddons){
		tot++;
		let item = FEBE.febeAddons[i];
		let name = item.name;
		let version = "v"+item.version;
		let type = "("+item.type+")";
		let types = item.type+"s";
		if(cnt[types] == undefined){
			cnt[types] = {};
			cnt[types].count = 0;
		}
		cnt[types].count++;
		let disabled = (item.userDisabled ? "(disabled)" : "");
		let txt = name + " " + version + " " + type + " " + disabled;
		list.push(txt);
	}
	list.sort();
	for(let i=0; i<list.length; i++){
		febeprt(list[i]);
	}
	febeprt("");
	txt = FEBE.febeMsg[13].replace('%NUM%',tot);
	for(let i in cnt){
		txt += ", "+cnt[i].count+" "+i;
	}
	febeprt(txt);
	FEBE.febePlaySound('success');
	
	function febeprt(txt,color){
		if(!color) color="black";
		let bold = false;
		if(color.indexOf('!') > 0){
			bold = true;
			color = color.replace('!','');
		}
		let box = document.getElementById('messages');
		let body = box.contentDocument.body;
		let msg = document.createTextNode(txt);
		let br = document.createElementNS(FEBE.febeNamespace,'br');
		let span = document.createElementNS(FEBE.febeNamespace,'span');
		span.style.color = color;
		span.style.fontWeight = "normal";
		if(bold) span.style.fontWeight = "bold"; 
		span.style.fontFamily = "Arial";
		span.style.fontSize = "12px";
		span.appendChild(msg)
		body.appendChild(span);
		body.appendChild(br);
		
		// Scroll to bottom after each write
		let scrollBox = box.contentWindow.document.body;
		scrollBox.scrollTop = scrollBox.scrollHeight - scrollBox.clientHeight;
		
		// Add contents to clipboard array
		FEBE.febeClipboard.push(txt);
		return true;
	}
	return true;
},

febeViewInstallDir: function (){
	var febeInstallDir = document.getElementById("febeInstallPath").value;
	FEBE.febeOpenLink("file:///"+febeInstallDir);
	return true;
},

febeCheckBDD: function (){
	var d = document.getElementById("febeWherePaneTitleID");
	d.setAttribute("warning", "true");
},

febeCheckBuDestDir: function (){
	if(document.getElementById("DestDirID") && document.getElementById("DestDirID").value != ""){
		document.getElementById("febeviewbudirbtnID").disabled = false;
	}else{
		document.getElementById("febeviewbudirbtnID").disabled = true;
	}
	return true;
},

febeDisableOpts: function (){
	try{	// Use a try blocks because statements refer to different preference windows which may not be loaded
		document.getElementById("clearwarn_id").disabled = !document.getElementById("clearDestDir_id").checked;
	}catch(e){;}
	try{
		document.getElementById("maxBuDirsLabelID").disabled = !document.getElementById("useTimestampedDir_id").checked;
	}catch(e){;}
	try{
		document.getElementById("maxBuDirsID").disabled = !document.getElementById("useTimestampedDir_id").checked;
	}catch(e){;}
	try{
		document.getElementById("febeTimestampFormatLabelID").disabled = !document.getElementById("useTimestampedDir_id").checked;
	}catch(e){;}
	try{
		document.getElementById("febeTimestampFormat1ID").disabled = !document.getElementById("useTimestampedDir_id").checked;
	}catch(e){;}
	try{
		document.getElementById("febeTimestampFormat2ID").disabled = !document.getElementById("useTimestampedDir_id").checked;
	}catch(e){;}
	try{
		document.getElementById("febeclearbuinprogresstbtn").disabled = !this.febeBuInProgress();
	}catch(e){;}
	this.febePlatform = this.febeGetPlatform();
	return true;
},

febeCloseButtonEtc: function (){
	// if no backup directory is set, make the field stand out
	let destDir = document.getElementById("DestDirID");
	if(destDir){
		let empty = destDir.emptyText;
		let value = destDir.value;
		if(value == ""){
			destDir.className = "warnOn";
		}else{
			destDir.className = "warnOff";
		}
	}

	let wherePane = document.getElementById("febeWherePaneTitleID");
	if(wherePane._loaded){	
		this.febeExBuDir = this.febePrefs.getCharPref("extensions.febe.extBUdir");	
		if(this.febeExBuDir == ""){
			wherePane.setAttribute("style.list-style-image","url('chrome://febe/skin/febe_pref.png')");
			wherePane.setAttribute("nobudir","true");
		}else{
			wherePane.setAttribute("style.-moz-image-region","rect(0px, 64px, 32px, 32px)");
			wherePane.setAttribute("nobudir","false");
		}
	}

	// Show close button for Mac OS X users because they don't get buttons for <prefwindow>
	// Looks like Fx3 doesn't show for *nix either	  
	let platform = this.febeGetPlatform();
	if(platform == 2 || platform == 3){
		document.getElementById("febeMacAcceptBtn").hidden = false;
	}

	let howPane = document.getElementById("febeHowPaneTitleID");
	if(howPane._loaded){		
		// Set text direction
		let textdir = document.getElementById("dispResultsOrientation").value;
		if(!textdir){textdir = "ltr";}
		this.febePrefs.setCharPref("extensions.febe.orientation",textdir);
	}

	wherePane = document.getElementById("febeWherePaneTitleID");
	if(wherePane._loaded){	
		// Add event listeners
		let d = document.getElementById("febeTimestampFormatID");
		d.addEventListener("RadioStateChange", FEBE.febeTimestampDirCheck, false);
	}
	return true;
},
	
febeOptionsCheck: function(){
	FEBE.setStyles();
  // Enable/disable options
	// Create pointer to profile directory
	this.febeProfDir = Cc["@mozilla.org/file/directory_service;1"].getService(Ci.nsIProperties).get("ProfD", Ci.nsIFile);
	let tmp = ""; 
	
	// Disable "Ignore cache and phishing DB" checkbox if cache directory is not located in the current profile folder
	let cache = this.febeProfDir.clone();
	cache.append("Cache");
	let cache2 = this.febeProfDir.clone();
	cache2.append("cache2");
	
	let cacheExists = Boolean(cache.exists() || cache2.exists());
	let d = document.getElementById("ignoreCache_id");
	if(cacheExists){
		if(d) d.setAttribute('disabled',false);
	}else{
		if(d) d.setAttribute('disabled',true);
		this.febePrefs.setBoolPref("extensions.febe.ignorecache",true);
	}
	
	let buType = this.febePrefs.getCharPref("extensions.febe.buType");
	if(buType == "profile"){return true;}
	FEBE.initBackupItemList();
	for(let i in FEBE.selectedItemsList){
		let which = FEBE.selectedItemsList[i];
		let id = which.id;
		FEBE.febeCheckAdditional(which,false);
	}
	
	return true;
},

febeCheckAdditional: function(that,interactive){
	febeDebug("febeCheckAdditional("+that.id+", "+interactive)
	let willBeChecked = false;
	if(interactive){
		willBeChecked = !that.checked;
		if(!willBeChecked) return true;
	}
	let which = that.id;
	let elm = document.getElementById(which);
	let msg;
	let item;
	let file;
	let DB;
	let cnt;
	let result;
	let profileDir;
	let stmt;
	let wm = Cc["@mozilla.org/appshell/window-mediator;1"].getService(Ci.nsIWindowMediator);
	let win = wm.getMostRecentWindow("navigator:browser");

	switch(which){
		case "extensions_febe_buBookmarks_json":
		case "extensions_febe_buBookmarks_html":
		case "bookmarks":
			// There should always be entries in the bookmarks file (places.sqlite > moz_bookmarks) even if they are only headers
			FEBE.selectedItemsList['bookmarks'].exists = true;
			break;
		case "extensions_febe_buPreferences":
		case "preferences":
			// There should always be something in about:config otherwise Fx wouldn't work
			FEBE.selectedItemsList['preferences'].exists = true;
			break;
		case "extensions_febe_buCookies":
		case "cookies":
			// See if there is at least one cookie on file
			if(!FEBE.febeBuCookies && !interactive) break;
			file = win.FileUtils.getFile('ProfD', ['cookies.sqlite']);
			try{
				FEBE.selectedItemsList['cookies'].exists = file.exists();
				FEBE.selectedItemsList['cookies'].size = file.fileSize;
			}catch(err){
				FEBE.selectedItemsList['cookies'].exists = false;
				FEBE.selectedItemsList['cookies'].size = 0;
				if(elm) elm.className = "translucent";
			}
			try{
				DB = win.Services.storage.openDatabase(file);	
			
				stmt = "SELECT * FROM moz_cookies LIMIT 1";
				result = DB.createAsyncStatement(stmt);
				
				cnt = 0;	
				result.executeAsync({
					handleResult: function(aResultSet){
						cnt++;
					},

					handleError: function(aError) {
						FEBE.databaseReadError('cookies',aError);
					},

					handleCompletion: function(aReason) {
						if (aReason != Components.interfaces.mozIStorageStatementCallback.REASON_FINISHED){
							FEBE.completionFailed('cookies',aReason);
						}else{
							FEBE.selectedItemsList['cookies'].exists = (cnt == 0) ? false: true;
							if(!FEBE.selectedItemsList['cookies'].exists){
								if(elm) elm.className = (FEBE.selectedItemsList['cookies'].exists) ? "solid" : "translucent";
								if(interactive) FEBE.febeAlert(FEBE.febeMsg[551]);
							}
							result.finalize();
						}
					}
				});	
				}catch(err){
					febeDebug("Error in febeCheckAdditional - could not process cookies.sqlite: "+err);
					FEBE.selectedItemsList['cookies'].error = err;
				}
			break;
		case "extensions_febe_buUserChrome":
		case "userChrome":
			profileDir = FEBE.febeProfDir.clone();
			profileDir.append("chrome");
			profileDir.append("userChrome.css");
			FEBE.selectedItemsList['userChrome'].exists = (profileDir.exists()) ? true : false;
			if(interactive && !FEBE.selectedItemsList['userChrome'].exists){
				if(elm) elm.className = (FEBE.selectedItemsList['userChrome'].exists) ? "solid" : "translucent";
				FEBE.febeAlert(FEBE.febeMsg[552]);
			}
			break;
		case "extensions_febe_buUserPwd":
		case "usernamePasswords":
			let loginManager = Cc["@mozilla.org/login-manager;1"].getService(Ci.nsILoginManager);	
			let logins = loginManager.getAllLogins({});
			FEBE.selectedItemsList['usernamePasswords'].exists = (logins.length > 1) ? true : false;
			if(interactive && !FEBE.selectedItemsList['usernamePasswords'].exists){
				if(elm) elm.className = (FEBE.selectedItemsList['usernamePasswords'].exists) ? "solid" : "translucent";
				FEBE.febeAlert(FEBE.febeMsg[553]);
			}
			break;
		case "extensions_febe_buSearchPlugins":
		case "searchPlugins":
			profileDir = FEBE.febeProfDir.clone();
			profileDir.append("search.json.mozlz4");
			FEBE.selectedItemsList['searchPlugins'].exists = (profileDir.exists()) ? true : false;
			if(interactive && !FEBE.selectedItemsList['searchPlugins'].exists){
				if(elm) elm.className = (FEBE.selectedItemsList['searchPlugins'].exists) ? "solid" : "translucent";
				FEBE.febeAlert(FEBE.febeMsg[554]);
			}
			break;
		case "extensions_febe_buBrowserHistory":
		case "browserHistory":
			let historyService = Cc["@mozilla.org/browser/nav-history-service;1"].getService(Ci.nsINavHistoryService);
			FEBE.selectedItemsList['browserHistory'].exists = (historyService.hasHistoryEntries) ? true : false;
			if(interactive && !FEBE.selectedItemsList['browserHistory'].exists){
				if(elm) elm.className = (FEBE.selectedItemsList['browserHistory'].exists) ? "solid" : "translucent";
				FEBE.febeAlert(FEBE.febeMsg[555]);
			}
			break;
		case "extensions_febe_buFormFillHistory":
		case "formfillHistory":
			// See if there is at least one formfill history item on file
			if(!FEBE.febeBuFormFillHistory && !interactive) break;
			file = win.FileUtils.getFile('ProfD', ['formhistory.sqlite']);
			try{
				FEBE.selectedItemsList['formfillHistory'].exists = file.exists();
				FEBE.selectedItemsList['formfillHistory'].size = file.fileSize;
			}catch(err){
				FEBE.selectedItemsList['formfillHistory'].exists = false;
				FEBE.selectedItemsList['formfillHistory'].size = 0;
				if(elm) elm.className = "translucent";
				break;
			}
			try{
				DB = win.Services.storage.openDatabase(file);	
				
				stmt = "SELECT * FROM moz_formhistory LIMIT 1";
				result = DB.createAsyncStatement(stmt);
				
				cnt = 0;	
				result.executeAsync({
					handleResult: function(aResultSet){
						cnt++;
					},

					handleError: function(aError) {
						FEBE.databaseReadError('formfill history',aError);
					},

					handleCompletion: function(aReason) {
						if (aReason != Components.interfaces.mozIStorageStatementCallback.REASON_FINISHED){
							FEBE.completionFailed('formfill history',aReason);
						}else{
							FEBE.selectedItemsList['formfillHistory'].exists = (cnt == 0) ? false: true;
							if(!FEBE.selectedItemsList['formfillHistory'].exists){
								if(elm) elm.className = (FEBE.selectedItemsList['formfillHistory'].exists) ? "solid" : "translucent";
								if(interactive) FEBE.febeAlert(FEBE.febeMsg[556]);
							}
							result.finalize();
						}
					}
				});	
			}catch(err){
				febeDebug("Error in febeCheckAdditional - could not process formhistory.sqlite: "+err);
				FEBE.selectedItemsList['formfillHistory'].error = err;
			}
			break;
		case "extensions_febe_buPermissions":
		case "permissions":
			// See if permissions.sqlite or content-prefs.sqlite exists.  If so, there are permissions to backup
			if(!FEBE.febeBuPermissions && !interactive) break;
			let file1 = win.FileUtils.getFile('ProfD', ['permissions.sqlite']);
			let file2 = win.FileUtils.getFile('ProfD', ['content-prefs.sqlite']);
			
			try{
				FEBE.selectedItemsList['permissions'].exists = file1.exists() || file2.exists();
				//FEBE.selectedItemsList['permissions'].size = 999;
				if(elm) elm.className = (FEBE.selectedItemsList['permissions'].exists) ? "solid" : "translucent";
			}catch(err){
				FEBE.selectedItemsList['permissions'].exists = false;
				//FEBE.selectedItemsList['permissions'].size = 0;
				if(elm) elm.className = "translucent";
			}
			if(interactive && !FEBE.selectedItemsList['permissions'].exists) FEBE.febeAlert(FEBE.febeMsg[557]);
			break;
		case "extensions_febe_buUDBu":
		case "userDefinedBackups":
			FEBE.selectedItemsList['userDefinedBackups'].exists = (FEBE.febeUDBuInit()) ? true: false;
			if(interactive && !FEBE.selectedItemsList['userDefinedBackups'].exists){
				if(elm) elm.className = (FEBE.selectedItemsList['userDefinedBackups'].exists) ? "solid" : "translucent";
				FEBE.febeAlert(FEBE.febeMsg[558]);
			}
			break;
	}
	febeDebug("Returning from febeCheckAdditional("+that.id+", "+interactive)
	return true;
},

febeCheckAdditionalAsync: function(){
	febeDebug("febeCheckAdditionalAsync() - cookies");
	// Cookies, formfill history and permissions must be checked asychronously
	let file;
	let DB;
	let cnt;
	let result;
	let stmt;
	let wm = Cc["@mozilla.org/appshell/window-mediator;1"].getService(Ci.nsIWindowMediator);
	let win = wm.getMostRecentWindow("navigator:browser");
	// See if there is at least one cookie on file
	file = win.FileUtils.getFile('ProfD', ['cookies.sqlite']);
	try{
		FEBE.selectedItemsList['cookies'].exists = file.exists();
		FEBE.selectedItemsList['cookies'].size = file.fileSize;
	}catch(err){
		FEBE.selectedItemsList['cookies'].exists = false;
		FEBE.selectedItemsList['cookies'].size = 0;
		FEBE.completionFailed('cookies',"File does not exist or is empty");
	}
	try{
		DB = win.Services.storage.openDatabase(file);	
		
		stmt = "SELECT * FROM moz_cookies LIMIT 1";
		result = DB.createAsyncStatement(stmt);
		
		cnt = 0;	
		result.executeAsync({
			handleResult: function(aResultSet){
				cnt++;
			},

			handleError: function(aError) {
				FEBE.databaseReadError('cookies',aError);
				result.finalize();
				FEBE.checkFFhistory();
			},

			handleCompletion: function(aReason) {
				if (aReason != Components.interfaces.mozIStorageStatementCallback.REASON_FINISHED){
					FEBE.completionFailed('cookies',aReason);
				}else{
					FEBE.selectedItemsList['cookies'].exists = (cnt == 0) ? false: true;
					result.finalize();
					FEBE.checkFFhistory();
				}
			}
		});	
	}catch(err){
		febeDebug("febeCheckAdditionalAsync() - Error opening cookies.sqlite: "+err)
		if(FEBE.febeBuCookies) FEBE.selectedItemsList['cookies'].error = err;
		FEBE.checkFFhistory();
	}
	febeDebug("Returning from febeCheckAdditionalAsync()");
	return true;
},

checkFFhistory: function(){
	febeDebug("checkFFhistory()");
	// See if there is at least one formfill history item on file
	let file;
	let DB;
	let cnt;
	let result;
	let stmt;
	let wm = Cc["@mozilla.org/appshell/window-mediator;1"].getService(Ci.nsIWindowMediator);
	let win = wm.getMostRecentWindow("navigator:browser");
	file = win.FileUtils.getFile('ProfD', ['formhistory.sqlite']);
	try{
		FEBE.selectedItemsList['formfillHistory'].exists = file.exists();
		FEBE.selectedItemsList['formfillHistory'].size = file.fileSize;
	}catch(err){
		FEBE.selectedItemsList['formfillHistory'].exists = false;
		FEBE.selectedItemsList['formfillHistory'].size = 0;
		FEBE.completionFailed('formfill history',"File does not exist or is empty");
	}
	try{
		DB = win.Services.storage.openDatabase(file);	
		
		stmt = "SELECT * FROM moz_formhistory LIMIT 1";
		result = DB.createAsyncStatement(stmt);
		
		cnt = 0;	
		result.executeAsync({
			handleResult: function(aResultSet){
				cnt++;
			},

			handleError: function(aError) {
				FEBE.databaseReadError('formfill history',aError);
				//result.finalize();
				//FEBE.checkPermissions('handleError');
			},

			handleCompletion: function(aReason) {
				if (aReason != Components.interfaces.mozIStorageStatementCallback.REASON_FINISHED){
					FEBE.completionFailed('formfill history',aReason);
				}else{
					FEBE.selectedItemsList['formfillHistory'].exists = (cnt == 0) ? false: true;
				}
				result.finalize();
				FEBE.checkPermissions('handleCompletion');					
			}
		});	
	}catch(err){
		febeDebug("checkFFhistory() - Error opening formhistory.sqlite: "+err)
		if(FEBE.febeBuFormFillHistory) FEBE.selectedItemsList['formfillHistory'].error = err;
		FEBE.checkPermissions('DB error');
	}
	febeDebug("Returning from checkFFhistory()");
	return true;
},

checkPermissions: function(msg){
	febeDebug("checkPermissions() "+msg);
	// See if permissions.sqlite or content-prefs.sqlite exists.  If so, there are permissions to backup
	let file1, file2;
	let wm = Cc["@mozilla.org/appshell/window-mediator;1"].getService(Ci.nsIWindowMediator);
	let win = wm.getMostRecentWindow("navigator:browser");
	file1 = win.FileUtils.getFile('ProfD', ['permissions.sqlite']);
	file2 = win.FileUtils.getFile('ProfD', ['content-prefs.sqlite']);
	try{
		FEBE.selectedItemsList['permissions'].exists = file1.exists() || file2.exists();
	}catch(err){
		FEBE.selectedItemsList['permissions'].exists = false;
	}
	FEBE.doBackup();	// End of async callbacks - the perform backup
	febeDebug("Returning from checkPermissions()");
	return true;
},

febeProfileWizard: function (){
	let wizard = "chrome://mozapps/content/profile/createProfileWizard.xul";
	window.open(wizard, 'FEBE Create Profile', 'chrome,alwaysRaised,centerscreen,resizable');
},

febeTimestampDirCheck: function (event){
	let selected = document.getElementById("febeTimestampFormatID").selectedItem.value;
	let current = FEBE.febePrefs.getCharPref("extensions.febe.timestamp.format");
	if(current == selected){return true;}
	if(!FEBE.febeGetBDD()){return false;}		// Get backup destination directory

	let tags = ["ISO8601","European"];
	let masks = [/^FEBE \d\d\d\d \d\d\.\d\d \d\d\.\d\d\.\d\d$/,/^FEBE \d\d\d\d \d\d-\d\d \d\d\.\d\d\.\d\d$/];
	let which = document.getElementById("febeTimestampFormatID").selectedIndex;
	let mask = masks[which];
	let dirArray = {};
	let numDirsToRename = 0;
	let buDirRoot = FEBE.febeBuDesDir.clone();
	let entries = buDirRoot.directoryEntries;
	
	// Count the number of directories that need to be renamed
	while(entries.hasMoreElements()){
		let entry = entries.getNext();
		entry.QueryInterface(Ci.nsIFile);
		let dirName = entry.leafName;
		if(!entry.isDirectory()){continue;}
		if(!dirName.match(mask)){continue;}
		numDirsToRename++;
		
		dirArray[dirName] = FEBE.febeNewDirName(which,dirName);
	}
	if(numDirsToRename == 0){return true;}
	
	FEBE.setStyles();
	let newformat,oldformat;
	switch(which){
		case 0:	
			oldformat = tags[1];
			newformat = tags[0];
			break;
		case 1:	
			oldformat = tags[0];
			newformat = tags[1];
			break;
	}//switch
	let tmp = FEBE.febeMsg[204].replace("%NUMDIR%",numDirsToRename);
	tmp = tmp.replace("%FORMT%",oldformat)+"\n";
	tmp += FEBE.febeMsg[205].replace("%NEWFORMAT%",newformat)+"\n\n"+FEBE.febeMsg[41];
	tmp=FEBE.febeStyle.orangeredBold+tmp;
	if(!FEBE.febeConfirm(tmp)){
		switch(which){ // Switch it back to where it was
		case 0:	
			document.getElementById("febeTimestampFormatID").selectedIndex = 1;
			break;
		case 1:	
			document.getElementById("febeTimestampFormatID").selectedIndex = 0;
			break;
	}//switch
		FEBE.febePrefs.setCharPref("extensions.febe.timestamp.format",current);
		FEBE.febeAlert(FEBE.febeMsg[206]);
		return false;
	}

	// Rename the directories
	for(let i in dirArray){
		let rnDir = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
		rnDir.initWithPath(buDirRoot.path);
		rnDir.append(i);
		rnDir.moveTo(null, dirArray[i]);
	}
	tmp = FEBE.febeMsg[207].replace("%NUMDIR%",numDirsToRename);
	tmp = tmp.replace("%NEWFORMAT%",newformat);
	FEBE.febeAlert(tmp);
	FEBE.febePrefs.setCharPref("extensions.febe.timestamp.format",selected)
},

febeClearBuInProgressFlag: function (){
	this.febePrefs.setBoolPref("extensions.febe.backupInProgress",false);
	document.getElementById("febeclearbuinprogresstbtn").disabled = true;
},

febeDisplayOnlineRestoreMenu: function (){
  // Enable/disable online restore popups
	return true;
},

febeResultsFormat: function (){
	let bool = this.febePrefs.getBoolPref("extensions.febe.displayresultspage");
	let d = document.getElementById("dispResultsFormat");
	if(d) d.setAttribute("hidden",!bool);
	d = document.getElementById("dispResultsOrientation");
	if(d) d.setAttribute("hidden",!bool);
},

febeGetNextBackup: function (){
	FEBE.febeSetMsgs();
	FEBE.febeSetIsScheduled();
	var tmp;
	var nbu = FEBE.febeGetUnicharPref("extensions.febe.schedule.next.backup");
	if(FEBE.febeIsScheduled == true){
		tmp = FEBE.febeSetDateString(nbu,FEBE.febeMsg[267]);
	}else{
		tmp = FEBE.febeMsg[113];
	}
	document.getElementById("nextbackupdate").value = tmp;
	return true;
},

febeSetDateString: function(dte,dftVal){
	FEBE.febeSetMsgs();
	if(dte == "") return dftVal;
	if(dte == FEBE.febeMsg[113]) return dte;
	let d= new Date(dte);
	let dd = d.toDateString(); 				// ex: 'Sat Jan 10 2015'
	let dt = d.toLocaleTimeString();	//ex: '12:00:00 AM'
	let ds = dd+" "+dt;								//ex: 'Sat Jan 10 2015 12:00:00 AM'
	return ds;
},

febeSchedulePrompts: function (){
  // Enable/disable prompts
	let d1, d2, d3, d4, d5, d6, d7, d8, lastbu, lastbustr;

	d1 = document.getElementById("backupOnStartup_id");
	d2 = document.getElementById("backupOnStartupPrompt_id");
	d3 = document.getElementById("lastbackuponstartupwaitlabel");
	d4 = document.getElementById("backuponstartupwaitvaluedays");
	d5 = document.getElementById("lastbackuponstartuplabel");
	d6 = document.getElementById("lastbackuponstartupvalue");
	d7 = document.getElementById("startupgracesecondslabel");
	d8 = document.getElementById("startupgracesecondsvalue");
	d2.disabled = !d1.checked;
	d3.disabled = !d1.checked;
	d4.disabled = !d1.checked;
	d5.disabled = !d1.checked;
	d6.disabled = !d1.checked;
	d7.disabled = !d1.checked;
	d8.disabled = !d1.checked;
	
	lastbu = this.febePrefs.getCharPref("extensions.febe.lastbackuponstartup");
	lastbu = FEBE.febeSetDateString(lastbu,FEBE.febeMsg[397]);
	lastbustr = this.febeMsg[397];
	if(lastbu != "") lastbustr = lastbu;
	d6.value =lastbustr;
	
	d1 = document.getElementById("backupOnShutdown_id");
	d2 = document.getElementById("backupOnShutdownPrompt_id");
	d3 = document.getElementById("lastbackuponshutdownwaitlabel");
	d4 = document.getElementById("backuponshutdownwaitvalue");
	d5 = document.getElementById("lastbackuponshutdownlabel");
	d6 = document.getElementById("lastbackuponshutdownvalue");
	d7 = document.getElementById("shutdowngracesecondslabel");
	d8 = document.getElementById("shutdowngracesecondsvalue");
	d2.disabled = !d1.checked;
	d3.disabled = !d1.checked;
	d4.disabled = !d1.checked;
	d5.disabled = !d1.checked;
	d6.disabled = !d1.checked;
	d7.disabled = !d1.checked;
	d8.disabled = !d1.checked;
	
	lastbu = this.febePrefs.getCharPref("extensions.febe.lastbackuponshutdown");
	lastbu = FEBE.febeSetDateString(lastbu,FEBE.febeMsg[397]);
	lastbustr = this.febeMsg[397];
	if(lastbu != "") lastbustr = lastbu;
	d6.value = lastbustr;
	
	// Set schedule times
	let daily = document.getElementById("dailyTime");
	let weekly = document.getElementById("weeklyTime");
	let monthly = document.getElementById("monthlyTime");
	
	daily.value = FEBE.febePrefs.getCharPref("extensions.febe.schedule.daily.time");
	weekly.value = FEBE.febePrefs.getCharPref("extensions.febe.schedule.weekly.time");
	monthly.value = FEBE.febePrefs.getCharPref("extensions.febe.schedule.monthly.time");
	
	return true;
},

febeLoadFxPath: function (){
	let pref = "extensions.febe.FxExecutablePath";
	if(this.febePrefs.prefHasUserValue(pref)){return true;}
	//let app = this.febeGetEnvironmentVariableValue("MOZ_CRASHREPORTER_RESTART_ARG_0");
	let app = FileUtils.getFile('XREExeF', []);
	document.getElementById("fullFxPathID").value = app.path;
	FEBE.febePrefs.setCharPref(pref,app.path);
	if(this.febePlatform == 3 || app == ""){	// Disable "Verify" button on Mac (bug 322865)
		let d = document.getElementById("verifyFxPathID");
		d.disabled = true;
	}
},

febeCheckFxPath: function (){
	var fxPath = document.getElementById("fullFxPathID").value
	if(fxPath == ""){ return false;}
	var file = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
	file.initWithPath(fxPath);
	let tmp;
	if(!file.exists()){
		tmp = this.febeMsg[299].replace(/%EXECUTABLE%/,fxPath);
		this.febeAlert(tmp);
		return false;
	}
	if(!file.isExecutable() && this.febePlatform != 3){
		tmp = this.febeMsg[300].replace(/%EXECUTABLE%/,fxPath);
		this.febeAlert(tmp);
		return false;
	}
	this.febeSetUnicharPref("extensions.febe.FxExecutablePath",file.path);
	tmp = this.febeMsg[302];
	this.febeAlert(tmp);
	return true;
},

febeBrowseForFirefox: function (){
	let d = document.getElementById("fullFxPathID");
	let fxPath = d.value;

  // Select firefox executable
	const nsIFilePicker = Ci.nsIFilePicker;
	let fp = Cc["@mozilla.org/filepicker;1"].createInstance(nsIFilePicker);
	fp.init(window, this.febeMsg[301], nsIFilePicker.modeOpen);
	fp.appendFilters(nsIFilePicker.filterApps);
	fp.defaultString = "firefox";
	
	// Set the start directory 
	let aDir = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
	let startDir;
	if(fxPath != ""){
		aDir.initWithPath(fxPath);
		startDir = aDir.parent;
	}else{
		startDir = Cc["@mozilla.org/file/directory_service;1"]
						.getService(Ci.nsIProperties)
						.get("CurProcD", Ci.nsIFile);
	}
	fp.displayDirectory = startDir;

	let rv = fp.show();
	if (rv == nsIFilePicker.returnOK){
		d.value = fp.file.path;
		return true;
	}
	return false;
},

febeDirInfoLoad: function (){
	let d, dir, tmp, p;
	// Profile name and location
	d = document.getElementById("dirinfoprofilenameID");
	tmp = this.febeProfDir.leafName;
	p = tmp.indexOf(".")
	this.febeProfName = tmp.substr(p+1);
	d.value = this.febeProfName;
	d = document.getElementById("dirinfoprofilepathID");
	d.value = this.febeProfDir.path;

	// Cache location
	d = document.getElementById("dirinfocachepathID");
	d.value = this.febeGetCacheDirectory();
	
	// Firefox install path
	d = document.getElementById("dirinfoinstallpathID");
	dir = Cc["@mozilla.org/file/directory_service;1"].getService(Ci.nsIProperties).get("CurProcD", Ci.nsIFile);
	d.value = dir.parent.path;
	
	// Extensions directory
	d = document.getElementById("dirinfoextensionspathID");
	dir = this.febeProfDir.clone();
	dir.append("extensions");
	d.value = dir.path;
	return true;
},

febeGetCacheDirectory: function (){
	let cacheDir;
	try{
		cacheDir = Cc["@mozilla.org/preferences-service;1"]
						 .getService(ci.nsIPrefBranch)
						 .getComplexValue("browser.cache.disk.parent_directory",Ci.nsIFile);
		return cacheDir;
  }catch(er){
    let dirServ = Cc["@mozilla.org/file/directory_service;1"]
                  .getService(Ci.nsIProperties);
		try{
			cacheDir = dirServ.get("ProfLD",Ci.nsIFile);
		}catch(er){
			return this.febeMsg[267];	// "unknown"
		}
	}
	return cacheDir.path;
},

febeDirInfoView: function (id){
	let URL = document.getElementById(id).value;
	this.febeOpenLink(URL);
	return true;
},

febeProfileName: function (){
	this.febeProfDir = Cc["@mozilla.org/file/directory_service;1"].getService(Ci.nsIProperties).get("ProfD", Ci.nsIFile);
	let tmp = this.febeProfDir.leafName;
	let p = tmp.indexOf(".")
	this.febeProfName  = tmp.substr(p+1);
	return this.febeProfName;
},

getProfileDirSize:  function(){
	// Return the size of directory in MB
	let dir = Cc["@mozilla.org/file/directory_service;1"].getService(Ci.nsIProperties).get("ProfD", Ci.nsIFile);
	let entries = dir.directoryEntries;
	let cnt = 0;
	while(entries.hasMoreElements()){
		let entry = entries.getNext();
		entry.QueryInterface(Ci.nsIFile);
		cnt += entry.fileSize
	}
	let size = parseInt(((cnt/1048576)*100)+.5)/100
	return size;
},

febeLoadAndSaveAddonsData: function(){
	if(FEBE.febePreLoad()){
		FEBE.febeAlert(FEBE.febeMsg[499]);
	}else{
		FEBE.febeAlert(FEBE.febeMsg[500]);
	}
	return true
},

setFolderPermissionsLoad: function(){
	document.documentElement.getButton("extra2").disabled = true;
	return true;
},

setFolderPermissions: function(){
	// FEBE.febeFixList is a list of nsIFiles
	for(let i=0; i<FEBE.febeFixList.length; i++){
		let entry = FEBE.febeFixList[i];
		let decPerms = entry.permissions;
		let newPerms = 438;
		if(entry.isExecutable()) newPerms = 511;
		entry.permissions = newPerms;
		let tmp = FEBE.febeMsg[532].replace('%OLDPERMS%',FEBE.currentPermissions(decPerms));
		tmp = tmp.replace('%NEWPERMS%',FEBE.currentPermissions(newPerms));
		FEBE.febeprt(entry.leafName+" : "+tmp,'green')
	}
	FEBE.febeprt("____________");
	FEBE.febeprt(FEBE.febeMsg[537].replace('%CNT%',FEBE.febeFixList.length));
	FEBE.febePlaySound('message');
	return true;
},

setFolderPermDir: function (){
	let d = document.getElementById("setPermDirID");
	let dfltDir = d.value;
	if(dfltDir == ""){
		let prefName = "extensions.febe.extBUdir";
		dfltDir = FEBE.febeGetUnicharPref(prefName);
	}
	
	let folder = FEBE.febePickDir(dfltDir,531);
	if(folder == false) return false;
	d.value = folder;
	
	let aDir = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
	aDir.initWithPath(folder);
	
	let entry, decPerms, newPerms, tmp;
	let notReadable = FEBE.febeMsg[533];
	let notWritable = FEBE.febeMsg[534];
	FEBE.febeFixList = [];
	
	// First check the backup folder itself
	decPerms = aDir.permissions;
	if(decPerms == 438 || decPerms == 511){ 
		tmp = " ... OK";
		FEBE.febeprt(aDir.leafName+" : d"+FEBE.currentPermissions(decPerms)+tmp,'green');
	}else{
		tmp = aDir.leafName+" : d"+FEBE.currentPermissions(decPerms);
		if(!aDir.isReadable()) tmp += ", "+notReadable;
		if(!aDir.isWritable()) tmp += ", "+notWritable;
		FEBE.febeprt(tmp,'red');
		FEBE.febeFixList.push(aDir);
	}

	let entries = aDir.directoryEntries;
	
	while(entries.hasMoreElements()){
		entry = entries.getNext();
		entry.QueryInterface(Ci.nsIFile);
		if(entry.isDirectory()) continue;
		decPerms = entry.permissions;
		
		// 438 = 0666 = rw-rw-rw-,  511=0777=rwxrwxrwx
		if(decPerms == 438 || decPerms == 511){ 
			FEBE.febeprt(entry.leafName+" : "+FEBE.currentPermissions(decPerms)+" ... OK",'green')
			continue;
		}else{
			tmp = entry.leafName+" : "+FEBE.currentPermissions(decPerms);
			if(!entry.isReadable()) tmp += ", "+notReadable;
			if(!entry.isWritable()) tmp += ", "+notWritable;
			FEBE.febeprt(tmp,'red');
			FEBE.febeFixList.push(entry);
			continue;			
		}
	}
	
	FEBE.febeprt("____________");
	if(FEBE.febeFixList.length == 0){
		FEBE.febeprt(FEBE.febeMsg[535],'black',0,1);
		document.documentElement.getButton("extra2").disabled = true;
		FEBE.febePlaySound('success');
	}else{
		FEBE.febeprt(FEBE.febeMsg[536].replace('%CNT%',FEBE.febeFixList.length),'black',0,1);
		document.documentElement.getButton("extra2").disabled = false;
		FEBE.febePlaySound('failure');
	}
	return true;
		
},

currentPermissions: function(dec){
	// Return the permission mask:  Ex: "rwxrwxrwx"
	// 'dec' is the decimal representation of the permissions. Ex '438' = '0666' (octal) = '110110110' (binary)
	// 'Read' bit is positions 1, 4, 7, 'Write' is 2, 5, 8, 'Execute' is 3, 6, 9
	let num = dec.toString();
	let binary = parseInt(num, 10).toString(2);
	let mask = "---------";
	let set = [];
	
	// Break the permissions into 3 sets (owner, group, other)
	set['owner'] = masked(binary.substr(0,3));
	set['group'] = masked(binary.substr(3,3));
	set['other'] = masked(binary.substr(6,3));
	return "-"+set['owner']+set['group']+set['other'];
	
	function masked(bin){
		let mask = "---";
		if(bin.substr(0,1) == "1") mask = "r" + mask.substr(1);
		if(bin.substr(1,1) == "1") mask = mask.substr(0,1) + "w" + mask.substr(2);
		if(bin.substr(2,1) == "1") mask = mask.substr(0,2) + "x" + mask.substr(3);
		return mask;			
	}
},
	
febeFlashNode: function (id,stop){
	// Not currently used
	return true;
},

// Sounds
febeHideSoundOptions: function (){
	let d = document.getElementById("febePlaySoundsID");
	let checked = d.hasAttribute("checked");
	d = document.getElementById("febeSoundOptionGrid");
	d.hidden = !checked;
	this.febeGetPrefs();
	return true
},

febeBrowseSounds: function (which){
	const nsIFilePicker = Ci.nsIFilePicker;
	let fp = Cc["@mozilla.org/filepicker;1"].createInstance(nsIFilePicker);
	fp.init(window, this.febeMsg[370], nsIFilePicker.modeOpen);
	fp.filterAudio;
	let filter = "*.ogg";
	this.febeMsg[371] = this.febeMsg[371].replace('*.wav','*.ogg');	// For locales not yet translated
	fp.appendFilter(this.febeMsg[371],filter);
	
	// Set default directory to where the custom sound originated if it is set, otherwise just default
	let err = false;
	let dd = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
	try {
		let url = this.febeGetUnicharPref("extensions.febe.sounds.use"+which+"SoundLocation");
		dd.initWithPath(url);
	}catch(e){err = true;}
	if(!err){fp.displayDirectory = dd.parent;}

	
	let rv = fp.show();
	if (rv == nsIFilePicker.returnOK){
		this.febeSetUnicharPref("extensions.febe.sounds.use"+which+"SoundLocation", fp.file.path);
		let d = document.getElementById("febe"+which+"SoundTB");
		d.value = fp.file.leafName;
	}
	this.febeGetPrefs();
	return true;
},

febeDisplaySoundFilenames: function (){
	this.febeGetPrefs();
	let a = ['BuSuccess','BuFailure','Warning','Message','Help','Success','Failure'];
	for(let i in a){
		let url = this.febeGetUnicharPref("extensions.febe.sounds.use"+a[i]+"SoundLocation");
		let d = document.getElementById("febe"+a[i]+"SoundTB");
		let p = url.lastIndexOf("\\");
		d.value = url.substr(p+1);
	}
},

febeClearSounds: function (){
	let a = ['BuSuccess','BuFailure','Warning','Message','Help','Success','Failure'];
	for(let i in a){
		this.febeSetUnicharPref("extensions.febe.sounds.use"+a[i]+"SoundLocation","");
		this.febeSetUnicharPref("extensions.febe.sounds.use"+a[i]+"SoundType","default");
		let d = document.getElementById("febe"+a[i]+"SoundTB");
		d.value = "";
	}
	return true;
},

febePlaySoundCheck: function (which){
	this.febeHandleSounds();
	let type = this.febeGetUnicharPref('extensions.febe.sounds.use'+which+'SoundType');
	if(type == 'default'){
		this.febePlaySound(which.toLowerCase())
	}else{
		let uri = this.febeGetUnicharPref('extensions.febe.sounds.use'+which+'SoundLocation');
		if(uri.length != 0){	
			uri = 'file://'+uri;
			let audio = new Audio(uri); 
			audio.play();
		}else{
			this.febeAlert(this.febeMsg[369]);
		}
	}
	return true;
},

febeDisplayReportButtons: function (){
	let prefName, tmp, results = false, resultspageurl = "";
	this.febeInitDir();
	prefName = "extensions.febe.lastbackupresultspageurl";
	if(this.febePrefs.prefHasUserValue(prefName)){
		let febeResultsPage = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
		resultspageurl = this.febePrefs.getCharPref(prefName);
		try{
			febeResultsPage.initWithPath(resultspageurl);
			if(febeResultsPage.exists()) results = true;
		}catch(e){;;}
	}
	prefName = "extensions.febe.lastbackup";
	if(this.febePrefs.prefHasUserValue(prefName)){
		tmp = this.febePrefs.getCharPref(prefName);
		tmp = this.febeLocalizedDate(tmp);
		document.getElementById("viewlastbudir").disabled = false;
		document.getElementById("viewlastbupage").disabled = !results;
	}else{
		tmp = this.febeMsg[173];
		document.getElementById("viewlastbudir").disabled = true;
		document.getElementById("viewlastbupage").disabled = true;
	}
	return true;
},

febeDisplayLastBU: function (){
	FEBE.febeSetMsgs();
	let tmp, prefName;
	FEBE.febeInitDir();
	tmp = FEBE.febeMsg[397];
	prefName = "extensions.febe.lastbackup";
	if(FEBE.febePrefs.prefHasUserValue(prefName)){
		tmp = FEBE.febePrefs.getCharPref(prefName);
		tmp = FEBE.febeSetDateString(tmp,FEBE.febeMsg[397])
	}
	document.getElementById("febeLastBU").value = tmp;
	document.getElementById("febeLastBuType").value = FEBE.febeGetUnicharPref("extensions.febe.lastbackup.type.desc");
	return true;
},

febeViewLastBUdir: function (){
	let prefName = "extensions.febe.lastbackup.folder";
	if(this.febePrefs.prefHasUserValue(prefName)){
		let febeBuDestDir = this.febeGetUnicharPref(prefName);
		this.febeOpenLink("file:///"+febeBuDestDir);
	}
	return true;
},

febeViewLastBUpage: function (){
	let uri = FEBE.febeGetUnicharPref("extensions.febe.lastbackup.resultspage");
	if(uri == ""){
		FEBE.febeAlert(FEBE.febeMsg[467]);
		return false;
	}
	let url = "file://"+uri;
	this.febeOpenLink(url);
	return true;
},

febeViewBuHistory: function (){
	// Load history
	let history = this.febeGetHistoryData();
	if(!history) return true;
	
	// Pointer to history page html file
	this.febeProfDir = Cc["@mozilla.org/file/directory_service;1"].getService(Ci.nsIProperties).get("ProfD", Ci.nsIFile);
	let febeHistoryPage = this.febeProfDir.clone();
	febeHistoryPage.append("FEBEhistory.html");
		
  // Open history page for writing
	let historyFile = Cc["@mozilla.org/network/file-output-stream;1"].createInstance(Ci.nsIFileOutputStream);
	historyFile.init(febeHistoryPage, 0x02 | 0x08 | 0x20, 0x1ED, 0); // write, create, truncate
	
  // Get history template
	let historyTemplate=this.getReportTemplate("FEBEhistoryTemplate.html");
	let histDoc = document.implementation.createHTMLDocument(this.febeMsg[372]);
	let pageSource = historyTemplate.replace("%title%", this.febeMsg[372]);
	pageSource = pageSource.replace("%reportheading%", this.febeMsg[372]);
	pageSource = pageSource.replace("%version%", this.febeMsg[49]+" "+this.febePrefs.getCharPref("extensions.febe.currentversion"));
  pageSource = pageSource.replace("%table%", this.febeBuildHistory(history));
		
	// Create an UTF-8 output stream
	let charset = "UTF-8";
	let os = Cc["@mozilla.org/intl/converter-output-stream;1"].createInstance(Ci.nsIConverterOutputStream);

	os.init(historyFile, charset, 4096, 0x0000);
	os.writeString(pageSource);
	os.close();

	// Open and display results
	this.febeOpenResultsPage(febeHistoryPage.path);
	return true;
},

febeBuildHistory: function (historyData){
	let doc = document.implementation.createHTMLDocument(this.febeMsg[372]);
	let row, cell, txt, span, anchor, dFile, para, url, cellTxt;
	let oSpan = doc.createElementNS(this.febeNamespace,'span');
	let table = doc.createElementNS(this.febeNamespace,'table');
	let oTbody = doc.createElementNS(this.febeNamespace,'tbody');
	let oAnchor = doc.createElementNS(this.febeNamespace,'a');
	let oRow = doc.createElementNS(this.febeNamespace,'tr');
	let oCell = doc.createElementNS(this.febeNamespace,'td');
	let cellStyle = "vertical-align: top;";
	let numStyle = "vertical-align: top; text-align: right;";
	let oBR = doc.createElementNS(this.febeNamespace,'br');
	let oPara = doc.createElementNS(this.febeNamespace,'p');
	let ttime = 0;
	
	// Write notes
	para = oPara.cloneNode(false);
	span = oSpan.cloneNode(false);
	span.setAttribute("style","font-style: italic;");
	txt = doc.createTextNode(this.febeMsg[391]);
	span.appendChild(txt);
	para.appendChild(span);
	doc.body.appendChild(para);
	
	// Setup the table
	table.setAttribute("style","margin-left: auto; margin-right: auto; text-align: left;");
	table.setAttribute("border","1");
	table.setAttribute("cellpadding","2");
  table.setAttribute("cellspacing","2");
		
	// Create table headings
	row = oRow.cloneNode(false);
	for(let i=373; i<=378; i++){
		cell = oCell.cloneNode(false);
		span = oSpan.cloneNode(false);
		span.setAttribute("class","heading");
		txt = doc.createTextNode(this.febeMsg[i]);
		span.appendChild(txt);
		cell.appendChild(span);
		row.appendChild(cell);
	}
	table.appendChild(row);

	//Add history lines to table
	for(let i=0; i<historyData.length; i++){
		let histdata = new Object(historyData[i]);
		let date = histdata.date;
		let type = histdata.type;
		let time = histdata.time;
		let location = histdata.resultsurl;
		let runType = histdata.runtype;
		let resultsPageURL = histdata.resultspage;
		let runTypeDesc = [];
		runTypeDesc[0] = "(Unknown)"
		runTypeDesc[1] = this.febeMsg[382];
		runTypeDesc[2] = this.febeMsg[383];
		runTypeDesc[3] = this.febeMsg[384];
		runTypeDesc[4] = this.febeMsg[385];
		runTypeDesc[5] = this.febeMsg[386];
		runTypeDesc[6] = this.febeMsg[425];

		row = oRow.cloneNode(false);
		
		// Create the date cell
		cell = oCell.cloneNode(false);
		cell.setAttribute("style",cellStyle);
		txt = doc.createTextNode(date);
		cell.appendChild(txt);
		row.appendChild(cell);
		
		// Create the backup type cell
		cell = oCell.cloneNode(false);
		cell.setAttribute("style",cellStyle);
		txt = doc.createTextNode(type);
		cell.appendChild(txt);
		row.appendChild(cell);
		
		// Create the backup time cell
		cell = oCell.cloneNode(false);
		cell.setAttribute("style",numStyle);
		txt = doc.createTextNode(time.toFixed(3));
		ttime += time;
		cell.appendChild(txt);
		row.appendChild(cell);
		
		// Create the backup location cell
		url = "";
		dFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
		dFile.initWithPath(location);
		if(dFile.exists() && dFile.isDirectory()){url = dFile.path;}
		cell = oCell.cloneNode(false);
		cell.setAttribute("style",cellStyle);
		txt = doc.createTextNode(location);
		if(url){
			anchor = oAnchor.cloneNode(false);
			anchor.setAttribute("href","file:///"+url);
			anchor.appendChild(txt);
			cell.appendChild(anchor);
			row.setAttribute("class","exists");
		}else{
			cell.appendChild(txt);
			row.setAttribute("class","notexists");
		}
		row.appendChild(cell);
		
		// Create the run type cell
		cell = oCell.cloneNode(false);
		cell.setAttribute("style",cellStyle);
		txt = doc.createTextNode(runTypeDesc[runType]);
		cell.appendChild(txt);
		row.appendChild(cell);

		// Create the results page cell
		url = "";
		cellTxt = this.febeMsg[388];
		if(resultsPageURL){
			cellTxt = this.febeMsg[387];
			dFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
			dFile.initWithPath(resultsPageURL);
			if(dFile.exists()){url = dFile.path;}
		}
		cell = oCell.cloneNode(false);
		cell.setAttribute("style",cellStyle);
		txt = doc.createTextNode(cellTxt);
		if(url){
			anchor = oAnchor.cloneNode(false);
			anchor.setAttribute("href","file:///"+url);
			anchor.appendChild(txt);
			cell.appendChild(anchor);
		}else{
			cell.appendChild(txt);
		}
		row.appendChild(cell);
		
		table.appendChild(row);
	}
	doc.body.appendChild(table);
	
	// Write totals
	para = oPara.cloneNode(false);
	let br = oBR.cloneNode(false);

	para.appendChild(br);
	para.appendChild(br);

	cellTxt = this.febeMsg[389].replace("%TOTAL%",historyData.length);
	txt = doc.createTextNode(cellTxt);
	para.appendChild(txt);
	para.appendChild(br);
	
	ttime = ttime / historyData.length;
	ttime +=0.0005;
	ttime = ttime * 1000;
	ttime = parseInt(ttime) / 1000;
	cellTxt = this.febeMsg[390].replace("%AVG%",ttime.toFixed(3));
	txt = doc.createTextNode(cellTxt);
	para.appendChild(txt);
	
	doc.body.appendChild(para);
	
	return doc.body.innerHTML;

},

febeGetHistoryData: function (){
	this.febeSetMsgs();
	this.febeDataFile = Cc["@mozilla.org/file/directory_service;1"].getService(Ci.nsIProperties).get("ProfD", Ci.nsIFile);
	this.febeDataFile.append(this.FEBEBUHISTORYFILE);
	let dFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
	dFile.initWithPath(this.febeDataFile.path);
	if(!dFile.exists() || dFile.fileSize == 0){
		this.febeAlert(this.febeMsg[381]);
		return false;
	}
	
	//let JSON = Cc["@mozilla.org/dom/json;1"].createInstance(Ci.nsIJSON);	
	let fis = Cc["@mozilla.org/network/file-input-stream;1"].createInstance(Ci.nsIFileInputStream);
	fis.init(dFile, 0x01, 0x124, 0);
	fis.QueryInterface(Ci.nsILineInputStream);

	let cis = Cc["@mozilla.org/intl/converter-input-stream;1"].createInstance(Ci.nsIConverterInputStream);
	cis.init(fis,"UTF-8", 0, 0x0000);
		
	let lis = cis.QueryInterface(Ci.nsIUnicharLineInputStream);

	let line = {}, hasmore, cnt = 0;
	let historyData = [];
	do {
		hasmore = lis.readLine(line);
		let histdata = JSON.parse(line.value);
		let date = histdata.date;
		let type = histdata.type;
		let time = histdata.time;
		let location = histdata.location;
		let runType = histdata.runType;
		historyData[cnt] = new Object(histdata);
		cnt++;
	} while(hasmore);
	return historyData;
},

febeClearBuHistory: function (){
	this.febeSetMsgs();
	let OK = FEBE.febeConfirm(this.febeMsg[379]);
	if(OK){
		this.febeDataFile = Cc["@mozilla.org/file/directory_service;1"].getService(Ci.nsIProperties).get("ProfD", Ci.nsIFile);
		this.febeDataFile.append(this.FEBEBUHISTORYFILE);
		let dFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
		dFile.initWithPath(this.febeDataFile.path);
		if(dFile.exists()){
			dFile.remove(false);
			this.febeAlert(this.febeMsg[380]);
		}
	}
	return true;
},

febeAddToIgnoreList: function(which){
	let ignoreName, item;
	for(let i in FEBE.febeAddons){
		item = FEBE.febeAddons[i];
		if(item.buname == which){
			// Strip file extension from name (i.e., '.xpi', '.jar')
			for(let j=which.length; j>1; j--){
				if(which.charAt(j) == "."){
					ignoreName = which.substr(0,j);
					break;
				}
			}
			break;
		}
	}

	// Write ignore list to file
	try{
		let fos, cos;
		
		// Get data from file
		this.febeDataFile = Cc["@mozilla.org/file/directory_service;1"].getService(Ci.nsIProperties).get("ProfD", Ci.nsIFile);
		this.febeDataFile.append(this.FEBEIGNORELISTDATAFILE);

		fos = Cc["@mozilla.org/network/file-output-stream;1"].createInstance(Ci.nsIFileOutputStream);
		fos.init(this.febeDataFile, 0x02 | 0x10, 0x1ED, 0); // write, append
		
		cos = Cc["@mozilla.org/intl/converter-output-stream;1"].createInstance(Ci.nsIConverterOutputStream);
		cos.init(fos, "UTF-8", 0, 0x0000);
		
		let ignoreItem = {};
		ignoreItem.id = item.guid;
		ignoreItem.name = ignoreName;
		
		let jstr = JSON.stringify(ignoreItem);
		cos.writeString(jstr+"\n"); 
		
		cos.close();
		fos.close();

		let d = document.getElementById("febeIgnoreListMsg");
		d.className = "purple";
		d.collapsed = false;
		d.value = FEBE.febeMsg[428].replace("%ITEM%",ignoreName);
		document.documentElement.getButton("extra2").disabled = true;
		
		FEBE.febeMainWindow.FEBE.febeAddedToIgnoreList.push(item.guid);
		FEBE.febePlaySound('message');
	}catch(err){
		let d = document.getElementById("febeIgnoreListMsg");
		d.className = "red";
		d.collapsed = false;
		d.value = FEBE.febeMsg[429].replace("%ITEM%",ignoreName);
		document.documentElement.getButton("extra2").disabled = false;
		FEBE.febePlaySound('failure');
	}
	return true;
},

setAsyncMode: function(){
	let async = FEBE.febePrefs.getBoolPref("extensions.febe.runAsync");
	// If "backup on shutdown", run synchronously
	if(this.febeBackupRunType == 3) async = false;
	return async;
},

// Cloud routines
cloudCheckEnabled: function(index){
	let elm, id, prefix = "febeCloudOther", name, uri;
	
	id = prefix+index.toString()+"Name";
	elm = document.getElementById(id);
	name = elm.value;
	
	id = prefix+index.toString()+"Location";
	elm = document.getElementById(id);
	uri = elm.value;
	
	if(name == "" || uri == ""){
		FEBE.febeAlert(FEBE.febeMsg[522]);
		id = prefix+index.toString()+"Enabled";
		elm = document.getElementById(id);
		elm.checked = false;
	}
	return true;
},

cloudLoad: function(){
	FEBE.febeOtherCloudServices = JSON.parse(FEBE.febeGetUnicharPref("extensions.febe.othercloudservices"));	
	
	let elm, id, location, prefix = "febeCloudOther";
	for(let i=1; i<4; i++){
		location = "location"+i.toString();
		id = prefix+i.toString();
		
		if(FEBE.febeOtherCloudServices[location].name !=""){
			elm = document.getElementById(id+"Name");
			elm.value = FEBE.febeOtherCloudServices[location].name;
		}
		if(FEBE.febeOtherCloudServices[location].uri !=""){
			elm = document.getElementById(id+"Location");
			elm.value = FEBE.febeOtherCloudServices[location].uri;
			elm.setAttribute('tooltiptext', elm.value);
		}
		elm = document.getElementById(id+"Enabled");
		elm.checked = FEBE.febeOtherCloudServices[location].enabled;
	}
	return true;	
},

cloudBrowse: function(id){
	let elm = document.getElementById(id);
	let dfltDir = "";
	if(elm.value != dfltDir) dfltDir = elm.value;
	let dir = this.febePickDir(dfltDir,328);
	if(dir != false) elm.value = dir;
	return true;
},

cloudTest: function(id){
	if(document.getElementById(id).value == "") return false;
	this.verifyBuDirOpen(id);
	return true;
},

cloudRemove: function(index){
	let elm, id, prefix = "febeCloudOther";
	
	id = prefix+index.toString()+"Name";
	elm = document.getElementById(id);
	elm.value = "";
	
	id = prefix+index.toString()+"Location";
	elm = document.getElementById(id);
	elm.value = "";

	id = prefix+index.toString()+"Enabled";
	elm = document.getElementById(id);
	elm.checked = false;
	return true;
},

cloudExplore: function(index){
	let location, folder, prefix = "febeCloudOther";
	location = "location"+index.toString();
	
	if(FEBE.febeOtherCloudServices[location].uri !=""){
		folder = encodeURIComponent(FEBE.febeOtherCloudServices[location].uri);
		FEBE.showFolder(folder,true);
	}else{
		FEBE.febeAlert(FEBE.febeMsg[530]);
	}
	return true;
},

cloudSave: function(save){
	// If 'save' is true, save the data.  Else just check for duplicates
	FEBE.febeOtherCloudServices = {};
	let elm, id, location, prefix = "febeCloudOther";
	let names = [], locations = [];
	for(let i=1; i<4; i++){
		location = "location"+i.toString();
		FEBE.febeOtherCloudServices[location] = {};
		
		id = prefix+i.toString()+"Name";
		elm = document.getElementById(id);
		if(elm){
			FEBE.febeOtherCloudServices[location].name = elm.value;
			names.push(elm.value);
		}
		
		id = prefix+i.toString()+"Location";
		elm = document.getElementById(id);
		if(elm){
			FEBE.febeOtherCloudServices[location].uri = elm.value;
			locations.push(elm.value);
		}

		id = prefix+i.toString()+"Enabled";
		elm = document.getElementById(id);
		if(elm) FEBE.febeOtherCloudServices[location].enabled = elm.checked;
	}

	// Make sure name and location are unique
	let OK = true;
	for(let i=0; i<names.length; i++){
		let n = names[i];
		if(n == "") continue;
		let index = names.indexOf(n);
		delete names[index];
		index = names.indexOf(n);
		if(index != -1){
			OK = false;
			break;
		}
	}
	
	let backupDestinationDirectory = FEBE.febeGetUnicharPref("extensions.febe.extBUdir");	
	let dropboxDir = FEBE.febeGetUnicharPref("extensions.febe.dropbox.rootdir");
	for(let i=0; i<locations.length; i++){
		let l = locations[i];
		if(l == "") continue;
		let index = locations.indexOf(l);
		delete locations[index];
		index = locations.indexOf(l);
		if(index != -1) OK = false;			
		if(l == backupDestinationDirectory) OK = false;
		if(l == dropboxDir) OK = false;
		if(!OK) break;
	}
	if(!OK){
		FEBE.febeAlert(FEBE.febeMsg[538]);
		return false;
	}else{
		let jstr = JSON.stringify(FEBE.febeOtherCloudServices);
		if(save) FEBE.febeSetUnicharPref("extensions.febe.othercloudservices",jstr);	
	}
	return true;
},

hideBox: function(cbid,boxid){
	let hide = !document.getElementById(cbid).checked;
	document.getElementById(boxid).hidden = hide;
	if(!hide){
		// Check dropbox local folder against backup destination folder
		let backupDestinationDirectory = FEBE.febeGetUnicharPref("extensions.febe.extBUdir");	
		let dropboxDir = document.getElementById('db.rootdir').value;
		if(dropboxDir == backupDestinationDirectory && dropboxDir != ""){
			FEBE.febeAlert(FEBE.febeMsg[539]);
		}
	}
	return true;
},

doZip: function(sourceDir,destDirs,zipName,absolutePath,append,async){
	// Create backups in all directories listed in destDirs
	for(let i=0; i<destDirs.length; i++){
		this.febeZip(sourceDir,destDir[i],zipName,absolutePath,append,async);	
	}
	return true;
},

febeZip: function (sourceDir,destDir,zipName,absolutePath,append,async){
  // Zip the contents of sourceDir (including all subdirectories) into destDir as zipName
  // If absolutePath is true, include the full pathname for each entry added to zipName
  // If append is false, create a new zipfile, otherwise append to the existing zipfile
	  
	var msg = "In febeZip:";
	msg += "\n   sourceDir: "+sourceDir;
	msg += "\n   destDir: "+destDir;
	msg += "\n   zipName: "+zipName;
	msg += "\n   absolutePath: "+absolutePath;
	msg += "\n   append: "+append;
	msg += "\n   async: "+async;
	febeDebug(msg);
	FEBE.setStyles();
		
	// Initialize
	FEBE.febeProgressWin = FEBE.getProgressWinPointer();

	let src;
	let root = src = sourceDir;
	let zipW;
	let febeZipFinished = false;
	let ignoreCache = this.febePrefs.getBoolPref("extensions.febe.ignorecache")
	
	// If true, zip the files asynchronously (fast), if false, process synchronously (slower by factor of 10)
	// If this.febeVerifyBackups is true, async should be false as the verify routine requires the zipping to be completed.
	//let async = !this.febeVerifyBackups;	
	
	const PR_RDONLY      = 0x01
	const PR_WRONLY      = 0x02
	const PR_RDWR        = 0x04
	const PR_CREATE_FILE = 0x08
	const PR_APPEND      = 0x10
	const PR_TRUNCATE    = 0x20
	const PR_SYNC        = 0x40
	const PR_EXCL        = 0x80
	const COMPRESSION_NONE    = 0;
	const COMPRESSION_FASTEST = 1;
	const COMPRESSION_DEFAULT = 6;
	const COMPRESSION_BEST    = 9;
	
	let ZipWriter = Components.Constructor("@mozilla.org/zipwriter;1","nsIZipWriter");
	let ZipReader = Components.Constructor("@mozilla.org/libjar/zip-reader;1","nsIZipReader", "open");

	// Init routine
	let init = function (destDir,zipName){
		febeZipFinished = false;	// Set to 'true' when zipping is completed

		let zipFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
		zipFile.initWithPath(destDir);
		if(!zipFile.exists() || !zipFile.isDirectory()){
			zipFile.create(Ci.nsIFile.DIRECTORY_TYPE, 0x1ED);
		}		
		zipFile.append(zipName);
		if (zipFile.exists() && !append){
			try{
				zipFile.remove(true);
			}catch(err){
				let style = FEBE.orangeread12;
				let tmp = style+FEBE.febeMsg[225].replace(/%FILE%/,zipFile.leafName);
				tmp = tmp.replace(/%DIR%/,zipFile.path)+"\n\n";
				style = FEBE.febeStyle.black12;
				tmp += style+err.toString()+"\n\n";
				style = FEBE.febeStyle.orangeredBold;
				tmp += style+FEBE.febeMsg[211]+"\n\n";
				FEBE.febeAlert(tmp);
				FEBE.febeErr = "abort";
				FEBE.febePrefs.setBoolPref("extensions.febe.backupInProgress",false);
				return false;
			}
		}
		zipW = new ZipWriter();
		if(append){
			zipW.open(zipFile, PR_RDWR | PR_CREATE_FILE | PR_APPEND);
		}else{
			zipW.open(zipFile, PR_RDWR | PR_CREATE_FILE | PR_TRUNCATE);
		}
	}//init()
	
	// Define the zip routine
	let zip = function (src){
		let isDir = false, oldPerms, changedPerms = false;
		let aFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
		if (!aFile) return false;
		aFile.initWithPath(src);
		FEBE.febeErr = "";
		if(!aFile.exists()){
			FEBE.febex = zipName;
			let style = FEBE.febeStyle.orangeredBold;
			let tmp = style+FEBE.febeMsg[61].replace(/%SRC%/,zipName)+"\n\n"
			style = FEBE.febeStyle.black12;
			tmp += style+FEBE.febeMsg[350]+"\n\n";
			style = FEBE.febeStyle.purple12;
			tmp += style+FEBE.febeMsg[349];
			let rv = FEBE.febeCantFind(tmp);
			if(!rv){
				FEBE.febeErr = "abort";
				FEBE.febePrefs.setBoolPref("extensions.febe.backupInProgress",false);
				return false;
			}
			FEBE.febeErr = "skip";
			return true;
		}else{
			oldPerms = aFile.permissions;
			changedPerms = false;
			if(oldPerms != 511){
				//aFile.permissions = 0x1FF;	// Change permissions to 0777 = -rwxrwxrwx (dec 511)
				aFile.permissions = 511;
				changedPerms = true;
			}
		}
		let entries = aFile.directoryEntries;
		while(entries.hasMoreElements()){
			let entry = entries.getNext();
			entry.QueryInterface(Ci.nsIFile);
			let file = entry.leafName;
			febeDebug("zipping: "+file);
			if(ignoreCache){
				let isDir = false;
				try{
					isDir = entry.isDirectory();
				}catch(err){
					let msg = FEBE.febeMsg[540].replace("%FILE%","'"+file+"'")+"\n";
					msg += entry.parent.path+"\n\n";
					msg += FEBE.febeMsg[541]+"\n";
					msg += FEBE.febeMsg[542]+"\n\n";
					let style = FEBE.febeStyle.orangeredBold;
					msg += style+FEBE.febeMsg[211];
					FEBE.febeFatal(err,msg,true);
					return false;
				}
				if(isDir){
					if(file == "Cache") continue;
					if(file == "cache2") continue;
					if(file == "startupCache") continue;
					if(file == "OfflineCache") continue;				
				}else{
					if(file == "urlclassifier3.sqlite") continue;
					if(file == "urlclassifierkey3.txt") continue;
					if(file == "XUL.mfl") continue;
					if(file == "XUL.mfasl") continue;
					if(file == "XPC.mfl") continue;
					if(file == "XPC.mfasl") continue;
				}
			}
			
			let src = entry.path;
			if(entry.isDirectory()){
				zip(src);	// Recurse!
			}else{
				let file = src.substring(root.length+1);;
				if(absolutePath) file = src;
				file = file.replace(/\\/g,"/");
				
				// Ignore locked files
				if(file == "parent.lock"){continue;}
				if(file == "lock"){continue;}
				if(file == "places.sqlite-journal"){continue;}
				if(file == "places.sqlite-stmtjrnl"){continue;}
				if(file == "places.sqlite-shm"){continue;}
				if(file == "places.sqlite-wal"){continue;}
				if(file == "cookies.sqlite-journal"){continue;}
				if(file == "cookies.sqlite-stmtjrnl"){continue;}
				if(file == "cookies.sqlite-shm"){continue;}
				if(file == "cookies.sqlite-wal"){continue;}

				try{
					zipW.addEntryFile(file, Ci.nsIZipWriter.COMPRESSION_BEST, entry, async);
				}catch(e){
					FEBE.febeSetMsgs();
					if(e.toString().indexOf("NS_BASE_STREAM_CLOSED") != -1){continue;}
					if(e.toString().indexOf("NS_ERROR_FILE_ALREADY_EXISTS") != -1){
						zipW.removeEntry(file, false);
						zipW.addEntryFile(file, Ci.nsIZipWriter.COMPRESSION_BEST, entry, async);
						continue;
					}
					if(e.toString().indexOf("NS_ERROR_NOT_INITIALIZED") != -1){
						let style = FEBE.febeStyle.orangered10;
						let tmp = style+FEBE.febeMsg[276]+"\n\n";
						style = FEBE.febeStyle.black8;
						tmp += style+src+"\n\n"
						tmp += FEBE.febeMsg[277];
						if(FEBE.febeConfirm(tmp)){continue;}
						setTimeout(function(){FEBE.febeCloseProgressWindow();},500);
					}

					let msg = FEBE.febeMsg[53].replace(/%FILE%/,file);
					FEBE.febeFatal(e,msg,true);
					return false;
				}
			}
		}
		if(changedPerms){
			aFile.permissions = oldPerms;
		}
	}//zip()
	
	// nsIRequestObserver methods
	let observer = {
		onStartRequest: function(request, context){
			if(FEBE.febeDispProgress == true){
				//FEBE.febeProgressWin.focus();
				//FEBE.febeUpdateProgressWindow(zipName,true);
			}
		},
		onStopRequest:  function(request, context, status){
			zipW.close();
			febeZipFinished = true;
		}	  
	};
	init(destDir,zipName);
	zip(src);
	zipW.processQueue(observer,null);
	return true;
},

febeUnzip: function (sourceDir,destDir,zipName){
//FEBE.logMsg("Unzip: "+sourceDir+", "+destDir+", "+zipName)
  // Unzip the contents of zipName (located in sourceDir) into destDir overwriting existing entries
	let zipFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
    zipFile.initWithPath(sourceDir);
	zipFile.append(zipName);
	let zipR = Cc["@mozilla.org/libjar/zip-reader;1"].createInstance(Ci.nsIZipReader);
  zipR.open(zipFile);
	FEBE.setStyles();
	let entries = zipR.findEntries("*");
  while (entries.hasMore()) {
		let entry = entries.getNext();
		let zEntry = zipR.getEntry(entry)
		let outFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
	    outFile.initWithPath(destDir);
		let subDirs = entry.split("/");
		let end = subDirs.length;
		if(zEntry.isDirectory){--end;}
		
	    for (let i = 0; i < end; ++i) {
	      if(!this.febeIsDrive(subDirs[i])) outFile.append(subDirs[i]);
	      if (!(outFile.exists() || this.febeIsDrive(subDirs[i]))) {
				try{
					outFile.create(Ci.nsIFile.DIRECTORY_TYPE, 0x1ED);
				}catch(e){
					let style = FEBE.febeStyle.orangered9;
					let tmp = style+e.toString()+"\n\n";
					style = FEBE.febeStyle.black9;
					tmp += style+"sourceDir: "+sourceDir+"\n\n";
					tmp += style+"destDir: "+destDir+"\n\n";
					tmp += style+"zipName: "+zipName+"\n\n";
					tmp += style+"outFile: "+outFile.path+"\n\n";
					tmp += style+"length: "+outFile.path.length+"\n\n";
					
					this.febeAlert(tmp);
					return false;
				}
			}
	    }

	    if(!zEntry.isDirectory){
	      outFile.append(subDirs[end]);
	      zipR.extract(entry,outFile);
	    }
	}
	return true;
  },
  
febeIsDrive: function (path){
  // Is path a drive disignator?  ("C:", etc)
	if(path.match(":")) return true
	return false;
},
  
febeAddToZip: function (sourceNames,destDir,zipName){
  // Zip the files listed in sourceNames array into destDir as zipName -  sourceNames contains full pathnames of files only.  Directories are ignored, zipName is overwriten
	// Initialize
	let zipW;
	
	const PR_RDONLY      = 0x01
	const PR_WRONLY      = 0x02
	const PR_RDWR        = 0x04
	const PR_CREATE_FILE = 0x08
	const PR_APPEND      = 0x10
	const PR_TRUNCATE    = 0x20
	const PR_SYNC        = 0x40
	const PR_EXCL        = 0x80
	const COMPRESSION_NONE    = 0;
	const COMPRESSION_FASTEST = 1;
	const COMPRESSION_DEFAULT = 6;
	const COMPRESSION_BEST    = 9;
	
	let ZipWriter = Components.Constructor("@mozilla.org/zipwriter;1",
                                       "nsIZipWriter");
	let ZipReader = Components.Constructor("@mozilla.org/libjar/zip-reader;1",
                                       "nsIZipReader", "open");

	// Init routine
	let init = function (destDir,zipName){
		febeZipFinished = false;	// Set to 'true' when zipping is completed
		let zipFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
		zipFile.initWithPath(destDir);
		if(!zipFile.exists() || !zipFile.isDirectory()){
			zipFile.create(Ci.nsIFile.DIRECTORY_TYPE, 0x1ED);
		}		
		zipFile.append(zipName);
		if (zipFile.exists()){zipFile.remove(true);}
		zipW = new ZipWriter();
		zipW.open(zipFile, PR_RDWR | PR_CREATE_FILE | PR_TRUNCATE);
	}//init()
	
	// Define the zip routine
	let zip = function (){
		for(let i in sourceNames){
			let aFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
			if (!aFile) return false;
			let entry = sourceNames[i];
			aFile.initWithPath(entry.path);
			aFile.append(entry.name);
			if(aFile.isDirectory()){
				continue;
			}else{
				try{
					zipW.addEntryFile(entry.name, Ci.nsIZipWriter.COMPRESSION_BEST, aFile, async);
				}catch(e){
					let msg = this.febeMsg[53].replace(/%FILE%/,entry.name)
					this.febeFatal(e,msg,true)
				}

			}
		}
	}//zip()
	
	// nsIRequestObserver methods
	let observer = {
		onStartRequest: function(request, context){},
		onStopRequest:  function(request, context, status){
			zipW.close();
			febeZipFinished = true;
		}	  
	};
	init(destDir,zipName);
	zip();
	zipW.processQueue(observer,null);
	return true;
},

febeAdvancedLoad: function (){
	return true;
},

febeVerifyExtensions: function (){
  // All valid extensions must be listed in the addon manager.
	// Also check for pending installs
	document.documentElement.getButton("extra2").hidden = true;
	let VEDfebeAddons = FEBEstorage.getItem("febeAddons","");
	window.document.title = this.febeMsg[237];
	let errCnt = 0;
	let extCnt = 0;

	for(let i in VEDfebeAddons){
		let item = VEDfebeAddons[i];
		let eType = item.type;
		if(item.ignore == true) continue;
		if(item.isValid == false){
			if(item.name == "staged"){
				tmp = this.febeMsg[203];
			}else{
				tmp = this.febeMsg[226]+" "+item.guid+" "+this.febeMsg[220];
			}
			
			febeprt(tmp,"red");
			errCnt++;
			continue;
		}

		let extIsDisabled = item.userDisabled;
		let extIcon = item.iconURL;

		let tmp = item.guid+" "+item.name;
		if(extIsDisabled) tmp += " (disabled)";
		tmp += " - OK";

		switch(eType){
			case "extension":
				febeprt(tmp,"blue",0,extIcon);
				//febeprt(item.installlocation,"black")
				extCnt++;
				break;
			case "theme":
				febeprt(tmp,"green",0,extIcon);
				extCnt++;
				break;
			default:
				break;
		}//switch

	}
	febeprt(" ",null,2);
	if(errCnt != 0){
		document.documentElement.getButton("extra2").hidden = false;
		febeprt(this.febeMsg[224],"red!");
		this.febePlaySound('failure');		
	}else{
		let tmp = this.febeMsg[223].replace("%CNT%",extCnt);  // All OK
		febeprt(tmp,"purple!");
		this.febePlaySound('success');
	}
	
	function febeprt(txt,color,numBlankLines,img){
		if(!color) color="black";
		if(!numBlankLines) numBlankLines = 0;
		if(!img) img = false;
		let bold = false;
		if(color.indexOf('!') > 0){
			bold = true;
			color = color.replace('!','');
		}
		let box = document.getElementById('messages');
		let body = box.contentDocument.body;
		
		let span = document.createElementNS(FEBE.febeNamespace,'span');
		span.style.color = color;
		span.style.fontWeight = "normal";
		if(bold) span.style.fontWeight = "bold"; 
		span.style.fontFamily = "Arial";
		span.style.fontSize = "12px";
		
		if(img != false){
			let image = document.createElementNS(FEBE.febeNamespace,'img');
			image.src = img;
			image.style='border: 0px solid ; width: 16px; height: 16px;'
			span.appendChild(image);
			txt += " ";
		}
		
		let msg = document.createTextNode(txt);
		span.appendChild(msg);
		body.appendChild(span);
		body.appendChild(document.createElementNS(FEBE.febeNamespace,'br'));
		
		for(let i=0; i<numBlankLines; i++){
			let br = document.createElementNS(FEBE.febeNamespace,'br');
			body.appendChild(br);
		}
		
		// Scroll to bottom after each write
		let scrollBox = box.contentWindow.document.body;
		scrollBox.scrollTop = scrollBox.scrollHeight - scrollBox.clientHeight;
		
		// Add contents to clipboard array
		FEBE.febeClipboard.push(txt);
		return true;
	}
	return true;
},

febeFixVerifyErrors: function(){
	let VEDfebeAddons = FEBEstorage.getItem("febeAddons","");
	febeprt(" ",null,2);
	let tmp = this.febeMsg[221];
	febeprt(tmp,"green");
	for(let i in VEDfebeAddons){
		let item = VEDfebeAddons[i];
		if(item.ignore == true) continue;
		if(item.isValid == true) continue;
		if(this.febeDeleteInvalidExt(item.installlocation)){
			if(item.name == "staged"){
				tmp = this.febeMsg[239];
			}else{
				tmp = item.guid+" "+this.febeMsg[220]+" "+this.febeMsg[227];
			}
			febeprt(tmp,"purple");
			continue;
		}else{
			let tmp = this.febeMsg[222]+" "+item.guid;
			febeprt(tmp,"red");
		}
	}
	febeprt(" ",null,2);
	febeprt(this.febeMsg[305],"black!");
	this.febePlaySound('message');
	
	function febeprt(txt,color,numBlankLines){
		if(!color) color="black";
		if(!numBlankLines) numBlankLines = 0;
		let bold = false;
		if(color.indexOf('!') > 0){
			bold = true;
			color = color.replace('!','');
		}
		let box = document.getElementById('messages');
		let body = box.contentDocument.body;
		
		let span = document.createElementNS(FEBE.febeNamespace,'span');
		span.style.color = color;
		span.style.fontWeight = "normal";
		if(bold) span.style.fontWeight = "bold"; 
		span.style.fontFamily = "Arial";
		span.style.fontSize = "12px";
				
		let msg = document.createTextNode(txt);
		span.appendChild(msg);
		body.appendChild(span);
		body.appendChild(document.createElementNS(FEBE.febeNamespace,'br'));
		
		// Scroll to bottom after each write
		let scrollBox = box.contentWindow.document.body;
		scrollBox.scrollTop = scrollBox.scrollHeight - scrollBox.clientHeight;
		
		// Add contents to clipboard array
		FEBE.febeClipboard.push(txt);
		return true;
	}
	return true;
},

febeDeleteInvalidExt: function (path){
	let aFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
	if (!aFile) return false;
	aFile.initWithPath(path);
	try{
		aFile.remove(true);
	}catch(e){
		FEBEstorage.setItem("alertsound", "failure");
		this.febeFatal(e,this.febeMsg[306]+"\n"+path,true);
		return false;
	}
	return true;	
},

febeprt: function (txt,color,size,numBlankLines){
	// Display content in log window (iframes only, not XUL windows)
	if(!color) color="black";
	if(!size || size == 0) size = 12;
	var box = document.getElementById("messages").contentDocument.body;
	if(!box) return false;
	let text = document.createTextNode(txt);
	let span = document.createElementNS(this.febeNamespace,'span');
	span.style.fontFamily = 'Courier New,Courier,monospace';
	span.style.fontWeight = 'normal';
	span.style.fontSize = size.toString()+'px';
	span.style.color = color;
	span.appendChild(text);
	let br = document.createElementNS(this.febeNamespace,'br');
	span.appendChild(br);
	box.appendChild(span);
	
	for(let i=0; i<numBlankLines; i++){
		let br = document.createElementNS(FEBE.febeNamespace,'br');
		box.appendChild(br);
	}
	
	
	let scrollBox = box;
	scrollBox.scrollTop = scrollBox.scrollHeight - scrollBox.clientHeight;
	
	// Add contents to clipboard array
	this.febeClipboard.push(txt);
	return true;
},

// FEBE Quick Backup routines
febeBuildList3: function (){
	this.febeNameGuidxref = {};
	this.febeItemsSelectedCount = 0;
	this.febeItemsListedCount = 0;

	// Clear the list
	let theList = document.getElementById("febeIgnoreList");
	let children = theList.childNodes;
	let n = children.length;
	// Clear existing items
	for (let i = 0; i < n; i++) {
		theList.removeChild(children[0]);
	}
	
	this.febeQuBuList();
	
	// Sort the list
	let sortArray = [];
	for(let i in this.febeExtensionsList){
		if(this.febeExtensionsList[i].ignore == true) continue;
		if(this.febeExtensionsList[i].isPersona == true) continue;
		if(this.febeExtensionsList[i].isGlobal == true) continue;
		let type = this.febeExtensionsList[i].type;
		if(type != "extension" && type != "theme") continue;
		sortArray.push(this.febeExtensionsList[i].name);
	}
	sortArray.sort();

	for(let i in sortArray){
		let data = this.febeExtensionsList[this.febeNameGuidxref[sortArray[i]]];
		if(data.ignore == true) continue;
		let row = document.createElement('listitem');
		
		row.setAttribute('id', data.guid );
		row.setAttribute('type', "checkbox" );
		row.onclick = function(event){FEBE.febeCountSelectedQbu(this)};
		let fxver = "";
		row.setAttribute('label', data.name+"{"+data.version+"}  "+fxver );
		row.setAttribute('checked', "false" );
		if(data.type == "extension"){
			if(data.userDisabled){
				row.setAttribute('style', "color: grey;" );
			}else{
				row.setAttribute('style', "color: blue;" );
			}
		}else{
			row.setAttribute('style', "color: green;" );
		}
		if(data.isCompatible == false) row.setAttribute('style', "color: red;" );
		
		theList.appendChild( row );
		this.febeItemsListedCount++;
	}
	document.getElementById("febeSelectAllID").disabled = false;
	document.getElementById("febeDeselectAllID").disabled = false;
	this.febeItemsSelectedCount = 0;
	document.getElementById("febeQbuSelectedValueID").value = this.febeItemsSelectedCount;
	document.getElementById("febeQbuListedValueID").value = this.febeItemsListedCount;
	return true;
},

febeSelectIL: function (bool){
  // Select/deselect all
	this.febeItemsSelectedCount = 0;
	for(let i in this.febeExtensionsList){
		let item = document.getElementById(i);
		if(!item) continue;
		item.setAttribute("checked",bool);
		if(bool) this.febeItemsSelectedCount++;
	}
	let d = document.getElementById("febeIlSelectedValueID");
	d.value = this.febeItemsSelectedCount;
},

febeCountSelectedIL: function (which){
	let bool = which.checked;
	if(bool){
		this.febeItemsSelectedCount++;
	}else{
		this.febeItemsSelectedCount--;
	}
	let d = document.getElementById("febeIlSelectedValueID");
	d.value = this.febeItemsSelectedCount;		
	return true;
},

// Quick Backup routines
febeQuBuList: function (){
  //Get a list of all installed extensions/themes
	this.febeExtensionsList = {};

	for(let guid in this.febeAddons){
			let ext = this.febeAddons[guid];
			this.febeExtensionsList[guid] = ext;
			this.febeNameGuidxref[ext.name] = guid; 
	}
},

febeMakeTmpDir: function(dName){
	this.febeTmpDir = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
	this.febeTmpDir.initWithPath(this.febeExBuDir);
	this.febeTmpDir.append(dName);
	if((this.febeTmpDir.exists() && this.febeTmpDir.isDirectory())){this.febeTmpDir.remove(true);}
	this.febeTmpDir.create(Ci.nsIFile.DIRECTORY_TYPE, 0x1FF);
	return true;
},

febeQuickBu: function (){	
	this.febeDispProgress = false;
	let combined = document.getElementById("febeCreateSingleXPI").checked;
	let combinedName = document.getElementById("febeCreateSingleXPIname").value +".xpi";
	this.febeExBuDir = document.getElementById("febeQuickBuDir").value;
	if(combined) this.febeMakeTmpDir("QBuTmp")
	let cnt = 0;
	for(let i in this.febeExtensionsList){
		let item = this.febeExtensionsList[i];
		if(item.ignore) continue;
		if(item.isGlobal) continue;
		if(item.isPersona) continue;
		let type = item.type;
		if(type != "extension" && type != "theme") continue;

		let which = document.getElementById(i);
		if(which.getAttribute("checked") != "true"){continue;}		
		let srcName = item.installlocation;
		let destDir = this.febeExBuDir;
		if(combined){destDir = this.febeTmpDir.path;}
		this.febeExtBuName = item.buname;
		
		if(item.isXpi == true){	// Perform a straight copy for xpis
			this.febeCopyFile(item.installlocation,destDir,item.buname);
		}else{
			this.febeZip(item.installlocation,destDir,item.buname,false,false);	
		}
		cnt++;
	}
	if(cnt == 0){
		this.febeAlert(this.febeMsg[326]);
		return true;
	}
	if(combined){
		this.febeProfDir = Cc["@mozilla.org/file/directory_service;1"]
			.getService(Ci.nsIProperties)
			.get("ProfD", Ci.nsIFile);
		this.febeProfDir.append("extensions");
		this.febeProfDir.append(this.FEBE_GUID);
		this.febeProfDir.append("!install.rdf");
		let sourcefile = this.febeProfDir.path;
		let destDir = this.febeTmpDir.path;
		let dName = "install.rdf";
		this.febeCopyFile(sourcefile,destDir,dName);	// Copy the install.rdf for the combined package
		this.febeZip(this.febeTmpDir.path,this.febeExBuDir,combinedName);

		let tmp = this.febeMsg[218].replace(/%NUM%/,cnt);
		tmp = tmp.replace(/%FNAME%/,combinedName);
		this.febeAlert(tmp);
		this.febeTmpDir.remove(true);
	}else{
		let tmp = this.febeMsg[217].replace(/%NUM%/,cnt);
		this.febeAlert(tmp);
	}
	this.febeDispProgress = this.febePrefs.getBoolPref("extensions.febe.displayprogresswin");

	return true;
},

febeCountSelectedQbu: function (which){
	let bool = which.checked;
	if(bool){
		this.febeItemsSelectedCount++;
	}else{
		this.febeItemsSelectedCount--;
	}
	let d = document.getElementById("febeQbuSelectedValueID");
	d.value = this.febeItemsSelectedCount;		
	return true;
},

febeQuickBuLoad: function (){
	this.febeGetPrefs();
	this.febeSetMsgs();
	
	// FEBE options window must be closed
	let optWin = Cc["@mozilla.org/appshell/window-mediator;1"].getService(Ci.nsIWindowMediator).getMostRecentWindow("febe:options");
	if(!!optWin){
		this.febeAlert(this.febeMsg[347]);
		return false;
	}
	
	FEBE.febeGetAddonList();
	let qbuDir = this.febeMsg[216];
	let prefName;
	prefName = "extensions.febe.quickBuDir";
	if(this.febePrefs.prefHasUserValue(prefName)){
		qbuDir = this.febeGetUnicharPref(prefName);
	}else{
		prefName = "extensions.febe.extBUdir";
		if(this.febePrefs.prefHasUserValue(prefName)){
			qbuDir =this.febeGetUnicharPref(prefName);
		}
	}
	document.getElementById("febeQuickBuDir").value = qbuDir;
	return true;
},

febeCreateSingleXPIcheck: function (that){
	document.getElementById("febeCreateSingleXPIbox").hidden = !that.checked;
},

febeQuickBuBrowse: function (){
  // Select Quick backup destinaton directory
	const nsIFilePicker = Ci.nsIFilePicker;
	let fp = Cc["@mozilla.org/filepicker;1"]
			 .createInstance(nsIFilePicker);
	fp.init(window, this.febeMsg[216], nsIFilePicker.modeGetFolder);
	fp.appendFilters(nsIFilePicker.filterAll | nsIFilePicker.filterText);

    // Set default directory to current backup directory
	let qbuDir = document.getElementById("febeQuickBuDir").value;
	if(qbuDir == "") qbuDir = this.febeGetUnicharPref("extensions.febe.extBUdir");
	let dd = Cc["@mozilla.org/file/local;1"]
			 .createInstance(Ci.nsIFile);
	dd.initWithPath(qbuDir);
	fp.displayDirectory = dd;

	let rv = fp.show();
	if (rv == nsIFilePicker.returnOK){
		rv = fp.file;
		qbuDir = rv.path;
		this.febeSetUnicharPref("extensions.febe.quickBuDir", qbuDir);
		document.getElementById("febeQuickBuDir").value = qbuDir;
	}
	return true;
},

febeWhenLoad: function(){
	FEBE.febeLoad();
	FEBE.febeHideHelpIcons();
	FEBE.febeDisplayLastBU();
	FEBE.febeGetNextBackup();
	FEBE.febeSchedulePrompts();
	FEBE.febeCheckForMissedScheduledBackup(false);
	let msg = FEBE.febeMsg[544];	// Scheduled backup was missed!
	let d = document.getElementById("scheduledbackupmissedmsg");
	d.value = msg;
	d.hidden = (FEBE.febeLastSheduledBackupMissed)? false : true;
	return true;
},

febeWhatLoad: function(){
	FEBE.febeGetAddonList(); 
	FEBE.febeOptPrefInit(); 
	FEBE.febeBuProfileCheck();
	FEBE.febeGetPrefs(); 
	FEBE.febeOptionsCheck();
	FEBE.febeAddEventListeners();
	FEBE.febeBuDisableSelective();
	FEBE.febeHideHelpIcons();
	FEBE.febeUDBuInit();
	FEBE.febeUDBuDisableAll();
	let d = document.getElementById("febeGetIListID");
	d.disabled = false;
	
	return true;
},

febeCheckForMissedScheduledBackup: function (prompt){
	FEBE.setStyles();
	// This routine is run each time the window DOM is loaded
	this.febeLastSheduledBackupMissed = false;
	if(!this.febeIsScheduleController) return false;	// Is this window the controller?

	// No backup scheduled	
  if(this.febePrefs.getCharPref("extensions.febe.schedule.frequency") == "none") return true;
	
	// This is the date/time the last scheduled backup occured
	let lastBu = this.febePrefs.getCharPref("extensions.febe.schedule.last.backup");
	if(lastBu == "") return true;		// If there was no last scheduled backup, no need to check if it was missed
	lastBu = Date.parse(lastBu);
	
	// This is the date that the next scheduled backup is supposed to occur
	let nextBu = this.febePrefs.getCharPref("extensions.febe.schedule.next.backup");
	if(isNaN(Date.parse(nextBu))) return true;	// Is probably the string 'No backup is scheduled'
	nextBu = Date.parse(nextBu);
	
	// If the next scheduled backup is scheduled for sometime in the future, it hasn't been missed
	let now = Date.parse(Date());
	if(nextBu >= now) return true;

	// At this point, it seems a scheduled backup did occur.  Make sure is occured within the tolerance window
	let tolerance = this.febePrefs.getIntPref("extensions.febe.schedule.tolerance")*1000;

	let nextBuLowRange = nextBu - tolerance;
	let nextBuHighRange = nextBu + tolerance;
	if((lastBu >= nextBuLowRange) && (lastBu <= nextBuHighRange)) return true; 
	
	// If we've gotton this far, the scheduled backup was missed.  Prompt the user every waitMinutes minutes (unless they opted out)
	this.febeLastSheduledBackupMissed = true;
	if(this.febePrefs.getBoolPref("extensions.febe.dontaskagain")) return true; // Opted out
	
	let waitMinutes = this.febePrefs.getIntPref("extensions.febe.missedscheduledbackupreminderminutes");
	let waitMs = waitMinutes * 60 * 1000; // Ex: 900,000 milliseconds is 15 minutes

	if ((now - waitMs) < this.febeSkippedScheduledLastChecked) return true;	
	this.febeSetMsgs();
	if(typeof this.febeMsg[234] === "undefined") return false; // Probably just restarted - it will check again after everything gets loaded
	if(this.febeBuInProgress()) return false;	// A backup is in progress, check later
	
	// Show the prompt
	let remind = this.febePrefs.getBoolPref("extensions.febe.remindmissedscheduledbackuponstartup");
	if(prompt && remind){
		let tmp = FEBE.febeStyle.orangeredBold+this.febeMsg[234]+"\n";
		tmp += FEBE.febeStyle.blackMargin+this.febeMsg[235]+"\n";
		tmp += FEBE.febeStyle.purpleMargin+new Date(nextBu)+"\n";
		tmp += FEBE.febeStyle.blackMargin+this.febeMsg[236]+"\n";
		tmp += FEBE.febeStyle.blackBold+this.febeMsg[233]+"\n\n";
		tmp += FEBE.febeStyle.black+this.febeMsg[273]+" "+this.febePrefs.getCharPref("extensions.febe.schedule.last.backup")+" ("+lastBu+")\n";
		tmp += FEBE.febeStyle.black+this.febeMsg[274]+" "+this.febePrefs.getCharPref("extensions.febe.schedule.next.backup")+" ("+nextBu+")\n";
		tmp += FEBE.febeStyle.black+this.febeMsg[275]+" "+new Date(now)+"\n";
		if(FEBE.febeConfirmAsk(tmp)){
			this.febePrefs.setBoolPref("extensions.febe.backupInProgress",false);
			if(this.febeScheduledBuTimer.hasOwnProperty("cancel")){
				this.febeScheduledBuTimer.cancel();
			}
			this.febeScheduledBuTimer = Cc['@mozilla.org/timer;1'].createInstance(Ci.nsITimer);
			this.febeScheduledBuTimer.cancel();	// Cancel any previously set timers

			this.febeBackupRunType = 4	// 'Scheduled'
			setTimeout(function(){FEBE.initBackup();},3000);
		}
	}
	this.febeSkippedScheduledLastChecked = Date.parse(Date());

	function numStr(num){
		return parseInt(num,10).toString();
	}
	return true;
},
	
febeScheduleBackup: function(save){
	febeDebug("febeScheduleBackup: save = "+save);
	// Schedule a backup - If save is true, write next backup date/time to preferences
	let windowtype = document.documentElement.getAttribute("windowtype");
	febeDebug("febeScheduleBackup: windowtype = '"+windowtype+"'");
	let OK = false;
	if(windowtype == "navigator:browser"){
		if(!Boolean(this.febeControllerWindow)){this.febeScheduleController();}
		if(this.febeSetIsScheduled()){OK = true;}	// No backup is scheduled?
		if(!this.febeIsScheduleController){OK = false}	// This window is not the controller
	}
	if(windowtype == "febe:options") OK = true;
	if(windowtype == "febe:progress") OK = true;
	febeDebug("febeScheduleBackup: OK = "+OK);
	if(!OK) return true;
	
  // Determine when (or if) a scheduled backup will take place and put it in the queue
	if(this.febeBuInProgress()){
		if(!this.febeBuInProgressCheck()) {return false;}
	}
	this.febeSetTimeoutIDs = [];
	if(!this.febeScheduleInit()){return;}
	
	let now = new Date().getTime();	// Current time in milliseconds	
	let oneDay = 24 * 60 * 60 * 1000;	// One day in milliseconds
	let oneMinute = 60 * 1000;
	let tmp;
	let febeNB = new Date();
	febeNB.setSeconds(0);
	let waitTime = 0;	// Number of milliseconds until next scheduled backup
	let dte = new Date();
	switch(this.febeSchedule){
		case "daily":
			febeNB.setHours(this.febeDailyHour);
			febeNB.setMinutes(this.febeDailyMinute);
			waitTime = febeNB.getTime() - now;
			if(waitTime <= 0){			// Scheduled time already passed
				tmp = febeNB.getTime();
				tmp += oneDay;		// Add a day
				febeNB.setTime(tmp);	
				waitTime = febeNB.getTime() - now;
			}
			break;
		case "weekly":
			let today = dte.getDay();
			tmp = today * oneDay;
			dte.setTime(now-tmp);
			dte.setHours(0,0,0);		// Last Sunday, Midnight
			let sunday = dte.getTime();
			tmp = this.febeWeeklyDay * oneDay;
			febeNB.setTime(sunday + tmp);
			febeNB.setHours(this.febeWeeklyHour);
			febeNB.setMinutes(this.febeWeeklyMinute);
			waitTime = febeNB.getTime() - now;
			if(waitTime <= 0){			// Scheduled time already passed
				tmp = febeNB.getTime();
				tmp += (oneDay * 7);// Add a week
				febeNB.setTime(tmp);	
				waitTime = febeNB.getTime() - now;
			}
			break;
		case "monthly":
			febeNB.setDate(this.febeMonthlyDay);
			febeNB.setHours(this.febeMonthlyHour);
			febeNB.setMinutes(this.febeMonthlyMinute);
			waitTime = febeNB.getTime() - now;
			if(waitTime <= 0){			// Scheduled time already passed
				let numDaysInMonth = [31,28,31,30,31,30,31,31,30,31,30,31];
				numDaysInMonth[1] += this.febeLeapYear();	// Leap year fix
				let thisMonth = dte.getMonth();
				let nextMonth = thisMonth + 1;
				if(nextMonth == 12){nextMonth = 0};
				let dayOfMonth = dte.getDate();
				let daysLeftThisMonth = numDaysInMonth[thisMonth] - dayOfMonth; 
				tmp = (daysLeftThisMonth +1) * oneDay;
				febeNB.setTime(now + tmp);
				febeNB.setHours(0,0,0);		// First day of next month at Midnight
				febeNB.setDate(this.febeMonthlyDay);
				febeNB.setHours(this.febeMonthlyHour);
				febeNB.setMinutes(this.febeMonthlyMinute);
				waitTime = febeNB.getTime() - now;
			}
			break;
		default:
			this.febeSchedule = "none";
			this.febeIsScheduled = false;
			break;
	}//switch
	
	this.clearSetTimeouts();
	this.febeSetMsgs();
	let startTime = waitTime - oneMinute;	// Start the warning one minute prior to backup
	let nbd = document.getElementById("nextbackupdate");
	if(this.febeIsScheduled == true){
		this.febeNextBackup = this.febeLocalizedDate(febeNB);
		if(save){
			// Only write the next scheduled backup date/time after a scheduled backup has occurred or when setting in FEBE options
			this.febeSetUnicharPref("extensions.febe.schedule.next.backup",this.febeNextBackup);
		}
		this.febeSetStatus();
		if(nbd) nbd.value = FEBE.febeSetDateString(febeNB,FEBE.febeMsg[267]);
	}else{
		if(nbd) nbd.value = this.febeMsg[113];
		return false;
	}
	
	// Schedule the backup
	if(this.febeScheduledBuTimer.hasOwnProperty("cancel")){
		this.febeScheduledBuTimer.cancel();
	}
	this.febeScheduledBuTimer = Cc['@mozilla.org/timer;1'].createInstance(Ci.nsITimer);
	this.febeScheduledBuTimer.cancel();	// Cancel any previously set timers
	this.febeScheduledBuTimer.initWithCallback(FEBE.febeStartScheduledBackup, startTime, Ci.nsITimer.TYPE_ONE_SHOT);
},
	
febeStartScheduledBackup: function (){
	let win = FEBE.febeControllerWindow;
	FEBE.febeControllerWindow.focus();
	febeDebug("febeStartScheduledBackup: !win.FEBE.febeIsScheduleController = "+!win.FEBE.febeIsScheduleController);
	if(!win.FEBE.febeIsScheduleController) {return true;}	// Only the controlling window can initiate a backup
	win.FEBE.clearSetTimeouts();	// Clear any previous scheduled backups

	// Save process id in case user aborts
	let to = new FEBE.febeSetTimeoutObj;
	win.FEBE.febeBackupRunType = 4;	// 'Scheduled'
	to.PID = win.setTimeout(function(){win.FEBE.initBackup();}, 60000);
	to.Process = 'FEBE.initBackup()';
	win.FEBE.febeWarn();
	win.FEBE.febeSetTimeoutIDs.push(to);
	return true;
},

febeScheduleInit: function (){
	let prefName;
	// Get daily time info
	prefName = "extensions.febe.schedule.daily.hour";
	if(this.febePrefs.prefHasUserValue(prefName)){
		this.febeDailyHour = this.febePrefs.getIntPref(prefName);
	} else {
		this.febePrefs.setIntPref(prefName,1);
		this.febeDailyHour = 1;
	}
	prefName = "extensions.febe.schedule.daily.minute";
	if(this.febePrefs.prefHasUserValue(prefName)){
		this.febeDailyMinute = this.febePrefs.getIntPref(prefName);
	} else {
		this.febePrefs.setIntPref(prefName,0);
		this.febeDailyMinute = 0;
	}

	// Get weekly time info
	prefName = "extensions.febe.schedule.weekly.day";
	if(this.febePrefs.prefHasUserValue(prefName)){
		this.febeWeeklyDay = this.febePrefs.getIntPref(prefName);
	} else {
		this.febePrefs.setIntPref(prefName,0);
		this.febeWeeklyDay = 0;
	}
	prefName = "extensions.febe.schedule.weekly.hour";
	if(this.febePrefs.prefHasUserValue(prefName)){
		this.febeWeeklyHour = this.febePrefs.getIntPref(prefName);
	} else {
		this.febePrefs.setIntPref(prefName,1);
		this.febeWeeklyHour = 1;
	}
	prefName = "extensions.febe.schedule.weekly.minute";
	if(this.febePrefs.prefHasUserValue(prefName)){
		this.febeWeeklyMinute = this.febePrefs.getIntPref(prefName);
	} else {
		this.febePrefs.setIntPref(prefName,0);
		this.febeWeeklyMinute = 0;
	}

	// Get monthly time info
	prefName = "extensions.febe.schedule.monthly.day";
	if(this.febePrefs.prefHasUserValue(prefName)){
		this.febeMonthlyDay = this.febePrefs.getIntPref(prefName);
	} else {
		this.febePrefs.setIntPref(prefName,1);
		this.febeMonthlyDay = 1;
	}
	prefName = "extensions.febe.schedule.monthly.hour";
	if(this.febePrefs.prefHasUserValue(prefName)){
		this.febeMonthlyHour = this.febePrefs.getIntPref(prefName);
	} else {
		this.febePrefs.setIntPref(prefName,1);
		this.febeMonthlyHour = 1;
	}
	prefName = "extensions.febe.schedule.monthly.minute";
	if(this.febePrefs.prefHasUserValue(prefName)){
		this.febeMonthlyMinute = this.febePrefs.getIntPref(prefName);
	} else {
		this.febePrefs.setIntPref(prefName,0);
		this.febeMonthlyMinute = 0;
	}

	// Get scheduled backup frequency
	prefName = "extensions.febe.schedule.frequency";
	if(this.febePrefs.prefHasUserValue(prefName)){
		this.febeSchedule = this.febePrefs.getCharPref(prefName);
	} else {
		this.febePrefs.setCharPref(prefName,"none");
		this.febeSchedule = "none";
	}
	this.febeSetIsScheduled();
	this.febeSetStatus();
	return this.febeIsScheduled;
},

febeSetIsScheduled: function (){
	// Set scheduled backup string
	let prefName = "extensions.febe.schedule.next.backup";
	if(FEBE.febeGetUnicharPref("extensions.febe.schedule.frequency") == "none"){
		FEBE.febeIsScheduled = false;
		FEBE.febeSchedule = "none";
		FEBE.febeSetMsgs();
		FEBE.febeSetUnicharPref(prefName,FEBE.febeMsg[113]);
		FEBE.febeNextBackup = FEBE.febeMsg[113];
	}else{
		FEBE.febeNextBackup = FEBE.febeGetUnicharPref(prefName);
		FEBE.febeIsScheduled = true;
	};
	return FEBE.febeIsScheduled;
},

febeScheduleController: function (exclude){
  // Assign a window to be the controlling window
	// If 'exclude' is set, that window is closing so ignore it when determining the new controller
	if(typeof exclude === "undefined") exclude = {};

	// Only allow assignment to certain window types
	let windowtype = document.documentElement.getAttribute("windowtype");
	let OK = false;
	if(windowtype == "navigator:browser") OK = true;
	if(windowtype == "febe:options") OK = true;
	if(windowtype == "febe:progress") OK = true;
	if(windowtype == "febe:switch") OK = true;
	if(!OK) return true;
	

	this.febeIsScheduleController = false;
	this.febeHideIcons = this.febePrefs.getBoolPref("extensions.febe.hideIcons");
	
	// How many windows are open?
	let wm = Cc["@mozilla.org/appshell/window-mediator;1"].getService(Ci.nsIWindowMediator);
	let wincnt = 0;
	var winarray = [];
	let enumerator = wm.getEnumerator("navigator:browser");
	while(enumerator.hasMoreElements()) {
		let win = enumerator.getNext();
		if(win == exclude) continue;
		
		wincnt++;
		winarray[wincnt] = win;
	}
	
	let contIndex = 0;
	if(wincnt == 1){	// Only one window (this one) is opened - make it the controller
		this.febeIsScheduleController = true;
		this.febeControllerWindow = winarray[1];
		this.febeSetStatus();
	}else{
		// More than one window is open ... see if any are the controller and set the statusbar icons (visible for the conroller, hidden otherwise
		for(let i=1; i<=wincnt; i++){
			let statusbar = winarray[i].document.getElementById("febestatusbar");
			if(!Boolean(statusbar)){continue;}
			if(winarray[i].FEBE.febeIsScheduleController){
				contIndex = i;
				statusbar.hidden = this.febeHideIcons;
				statusbar.collapsed = this.febeHideIcons;
			}else{
				winarray[i].FEBE.febeIsScheduleController = false;
				statusbar.hidden = true;
				statusbar.collapsed = true;
			}
		}
	}
	
	let controller = {};
	
	if(contIndex == 0){	// No controller set, make it this one
		controller = winarray[1];
	}else{
		controller = winarray[contIndex];
	}
	if(!controller) return true;	// Closing last window
	
	controller.FEBE.febeIsScheduleController = true;
	let statusbar = controller.document.getElementById("febestatusbar");
	if(statusbar){
		statusbar.hidden = this.febeHideIcons;
		statusbar.collapsed = this.febeHideIcons;
	}
	this.febeControllerWindow = controller;
	winarray = [];		// Free up memory
	return true;
},

febeScheduleChange: function (){
	FEBE.febeScheduleInit();
	switch(FEBE.febeSchedule){
		case "daily":
			FEBE.febeDisableFields("daily",false);
			FEBE.febeDisableFields("weekly",true);
			FEBE.febeDisableFields("monthly",true);
			FEBE.febeDisableFields("none",true);
			FEBE.febeDisableFields("scheduleInfo",false);	
			break;
		case "weekly":
			FEBE.febeDisableFields("daily",true);
			FEBE.febeDisableFields("weekly",false);
			FEBE.febeDisableFields("monthly",true);
			FEBE.febeDisableFields("none",true);
			FEBE.febeDisableFields("scheduleInfo",false);	
			break;
		case "monthly":
			FEBE.febeDisableFields("daily",true);
			FEBE.febeDisableFields("weekly",true);
			FEBE.febeDisableFields("monthly",false);
			FEBE.febeDisableFields("none",true);
			FEBE.febeDisableFields("scheduleInfo",false);	
			break;
		case "none":
			FEBE.febeDisableFields("daily",true);
			FEBE.febeDisableFields("weekly",true);
			FEBE.febeDisableFields("monthly",true);
			FEBE.febeDisableFields("none",false);
			FEBE.febeDisableFields("scheduleInfo",true);	
			break;
	}
},

febeDisableFields: function(which,state){
	let useFEBEcolors = FEBE.febePrefs.getBoolPref("extensions.febe.useFEBEcolors");
	let classEnabled = "solid";
	let classDisabled = "translucent";
	if(useFEBEcolors){
		classEnabled = "febeTimepicker "+classEnabled;
		classDisabled = "febeTimepicker "+classDisabled;
	}
	try{
		switch(which){
			case "daily":
					document.getElementById("dailyID").className = (state ? classDisabled : classEnabled);
					document.getElementById("dailylabelatID").disabled = state;
					document.getElementById("dailyTime").disabled = state;
					document.getElementById("dailyTime").className = (state ? classDisabled : classEnabled);
				break;
			case "weekly":
				document.getElementById("weeklyID").className = (state ? classDisabled : classEnabled);
				document.getElementById("weeklyDayID").disabled = state;
				document.getElementById("weeklylabelatID").disabled = state;
				document.getElementById("weeklyTime").disabled = state;
				document.getElementById("weeklyTime").className = (state ? classDisabled : classEnabled);
				break;
			case "monthly":
				document.getElementById("monthlyID").className = (state ? classDisabled : classEnabled);
				document.getElementById("monthlyDayID").disabled = state;
				document.getElementById("monthlylabelatID").disabled = state;
				document.getElementById("monthlyTime").disabled = state;
				document.getElementById("monthlyTime").className = (state ? classDisabled : classEnabled);
				break;
			case "none":
				document.getElementById("noscheduledID").className = (state ? classDisabled : classEnabled);
				break;
			case "scheduleInfo":
				document.getElementById("setschedulebtn").disabled = state;
				document.getElementById("nextbackupdate").disabled = state;
				document.getElementById("remindmissedscheduledbackup").disabled = state;
				document.getElementById("missedschedluedbackupminutes").disabled = state;
				document.getElementById("remindmissedscheduledbackup2").disabled = state;
				document.getElementById("nextbackupdate").value = FEBE.febeSetDateString(FEBE.febeGetUnicharPref("extensions.febe.schedule.next.backup"),FEBE.febeMsg[267]);
				break;
		}
	}catch(err){;;}
	return true;
},

febeSetScheduleBtn: function (){
	FEBE.saveSchedulePrefs();
	FEBE.febeScheduleInit();
	FEBE.febeScheduleBackup(true);
	FEBE.febeScheduleController();
	FEBE.setStyles();

	let when = FEBE.febePrefs.getCharPref("extensions.febe.schedule.next.backup");
	FEBE.febeGetPlatform();
	let tmp = FEBE.febeStyle.purple12+FEBE.febeMsg[228].replace("%DATETIME%",when);
	if(FEBE.febePlatform == 3){// Mac can't handle modal alerts properly
		alert(tmp);
	}else{	
		FEBE.febeAlert(tmp);
	}
	FEBE.febeNextBackup = when;
	FEBE.febeSetStatus();
	return true;
},

saveSchedulePrefs: function(){
	let daily = document.getElementById("dailyTime");
	let weekly = document.getElementById("weeklyTime");
	let monthly = document.getElementById("monthlyTime");
	
	FEBE.febePrefs.setIntPref("extensions.febe.schedule.daily.hour",daily.hour);
	FEBE.febePrefs.setIntPref("extensions.febe.schedule.daily.minute",daily.minute);
	FEBE.febePrefs.setIntPref("extensions.febe.schedule.weekly.hour",weekly.hour);
	FEBE.febePrefs.setIntPref("extensions.febe.schedule.weekly.minute",weekly.minute);
	FEBE.febePrefs.setIntPref("extensions.febe.schedule.monthly.hour",monthly.hour);
	FEBE.febePrefs.setIntPref("extensions.febe.schedule.monthly.minute",monthly.minute);
	return true;
},

febeColorScheme: function(checked){
	let useFEBEcolors = new Boolean();
	if(typeof checked !== 'undefined'){
		useFEBEcolors = Boolean(checked);
		FEBE.febePrefs.setBoolPref("extensions.febe.useFEBEcolors",checked);
	}else{
		useFEBEcolors = FEBE.febePrefs.getBoolPref("extensions.febe.useFEBEcolors");
	}
	let klassnames = "febeGroupbox febeCaption purple backgroundLight backgroundDark tabSelected tabNotSelected febeButton febeDropdown febeMenuitem numspinbox spinbox purpleBold febeDate";
	let klasses = klassnames.split(" ");
	for(let i=0; i<klasses.length; i++){
		let collection = document.getElementsByClassName(klasses[i]);
		for(let elm=0; elm<collection.length; elm++){
			let element = collection[elm];
			element.setAttribute("useFEBEcolors",useFEBEcolors);
		}
	}
	let prefWindow = document.getElementById("febeOptionsID");
	if(prefWindow) prefWindow.setAttribute("useFEBEcolors",useFEBEcolors);
	FEBE.febeScheduleChange();
	return true;
},

febeLeapYear: function (){
  // returns 1 if now is a leap year, 0 otherwise 
	let retval = 0;
	let now = new Date();
	let year = now.getFullYear();
	
	if(year % 4 == 0){
		if(year % 100 != 0){
			retval = 1;
		}else{
			if(year % 400 == 0){
				retval = 1;
			}else{
				retval = 0;
			}
		}
	}
	return retval;
},


// FEBE User-defined backup routines

febeUDBuObj: function (Label, Type, Description, Path, Include){
	this.Label = Label;
	this.Type = Type;
	this.Description = Description;
	this.Path = Path;
	this.Include = Include; 
	return true;

},

febeNewUDBu: function (){
	this.febeUDBuDisableAll();
	document.getElementById("febeUDBuCaption").value = this.febeMsg[136];
	this.febeUDBuAction = 1;
	this.febeUDBuEnableNew();
	this.febeUDBuStatusMsg("");
	return true;
},

febeEditUDBu: function (){
	this.febeUDBuDisableAll();
	document.getElementById("febeUDBuCaption").value = this.febeMsg[137];
	this.febeUDBuAction = 2;
	this.febeUDBuPopulateListbox();
	this.febeUDBuStatusMsg("");
	return true;
},

febeDeleteUDBu: function (){
	this.febeUDBuDisableAll();
	document.getElementById("febeUDBuCaption").value = this.febeMsg[138];
	this.febeUDBuAction = 3;
	this.febeUDBuPopulateListbox();
	this.febeUDBuStatusMsg("");
	return true;
},

febeSelUDBu: function (){
	let dd = document.getElementById("febeUDBuType");
	if(dd.selectedIndex == -1){
		let tmp = this.febeMsg[165];
		this.febeAlert(tmp);
		return false;
	}
	let type = dd.selectedIndex;
	switch(type){
		case 0:		// File
			this.febeSelUDBuFile();
			break;
		case 1:		// Folder
			this.febeSelUDBuFolder();
			break;
	}//switch
	return true;
},

febeSelUDBuFile: function (){
  // Select a file to backup
	let fp = Cc["@mozilla.org/filepicker;1"].createInstance(Ci.nsIFilePicker);
	fp.init(window, this.febeMsg[133], Ci.nsIFilePicker.modeOpen);
	fp.appendFilters(Ci.nsIFilePicker.filterAll);
	
	// Set the default directory to the current profile directory
	this.febeProfDir = Cc["@mozilla.org/file/directory_service;1"].getService(Ci.nsIProperties).get("ProfD", Ci.nsIFile);
	fp.displayDirectory = this.febeProfDir;

	let rv = fp.show();
	if (rv == Ci.nsIFilePicker.returnOK){
		rv = fp.file;
		document.getElementById("febeUDBuSource").value = rv.path;
		return true;
	}
	return false;
},

febeSelUDBuFolder: function (){
  // Select a folder to backup
	let fp = Cc["@mozilla.org/filepicker;1"].createInstance(Ci.nsIFilePicker);
	fp.init(window, this.febeMsg[159], Ci.nsIFilePicker.modeGetFolder);
	fp.appendFilters(Ci.nsIFilePicker.filterAll | Ci.nsIFilePicker.filterText);

	// Set the default directory to the current profile directory
	this.febeProfDir = Cc["@mozilla.org/file/directory_service;1"].getService(Ci.nsIProperties).get("ProfD", Ci.nsIFile);
	fp.displayDirectory = this.febeProfDir;

	let rv = fp.show();
	if (rv == Ci.nsIFilePicker.returnOK){
		rv = fp.file;
		document.getElementById("febeUDBuSource").value = rv.path;
		return true;
	}
	return false;
},

febeUDBuInit: function (){
	this.febeSetMsgs();
  // Get data from file - create template if needed
	this.febeDataFile = Cc["@mozilla.org/file/directory_service;1"].getService(Ci.nsIProperties).get("ProfD", Ci.nsIFile);
	this.febeDataFile.append(this.FEBEDATAFILE);
	if(!this.febeDataFile.exists()){
	  // Create the template
				
		let dflt = new this.febeUDBuObj();
		dflt.Label = this.febeMsg[182];
		dflt.Type = 0;
		dflt.Description = this.febeMsg[181];
		dflt.Path = this.febeDataFile.path.replace(/\\/g,"\\");
		dflt.Include = true;
		
		let fos = Cc["@mozilla.org/network/file-output-stream;1"].createInstance(Ci.nsIFileOutputStream);
		fos.init(this.febeDataFile, 0x02 | 0x08 | 0x20, 0x1ED, 0); // write, create, truncate	
		let cos = Cc["@mozilla.org/intl/converter-output-stream;1"].createInstance(Ci.nsIConverterOutputStream);
		cos.init(fos, "UTF-8", 0, 0x0000);
		let jstr = JSON.stringify(dflt);
		cos.writeString(jstr+"\n");
		cos.close();
	}
	
  // Read the data
	let dFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
	dFile.initWithPath(this.febeDataFile.path);
		
  // open an input stream from file
	let fis = Cc["@mozilla.org/network/file-input-stream;1"].createInstance(Ci.nsIFileInputStream);
	fis.init(dFile, 0x01, 0x124, 0);
	fis.QueryInterface(Ci.nsILineInputStream);

	let cis = Cc["@mozilla.org/intl/converter-input-stream;1"].createInstance(Ci.nsIConverterInputStream);
	cis.init(fis,"UTF-8", 0, 0x0000);
	
	let lis = cis.QueryInterface(Ci.nsIUnicharLineInputStream);

  // read lines into array and parse into individual fields
	this.febeUDBuList = [];
	
	let line = {}, hasmore, cnt;
	cnt = 0; // Count of UDBU items
	do {
		hasmore = lis.readLine(line);
		if(line.value.length == 0){break;}
		let febeUDBuItem = JSON.parse(line.value); 
		this.febeUDBuList[febeUDBuItem.Label] = febeUDBuItem;
		cnt += 1;
	} while(hasmore);
	cis.close();
	fis.close();
	try {
		document.documentElement.getButton("extra2").disabled = true;
		this.febeUDBuStatusMsg("");
	}catch(e){;;}
	if(cnt == 0){return false;}
	return this.febeUDBuList;
},

febeUDBuWrite: function (){
	this.febeDataFile = Cc["@mozilla.org/file/directory_service;1"].getService(Ci.nsIProperties).get("ProfD", Ci.nsIFile);
	this.febeDataFile.append(this.FEBEDATAFILE);
	let fos = Cc["@mozilla.org/network/file-output-stream;1"].createInstance(Ci.nsIFileOutputStream);
	fos.init(this.febeDataFile, 0x02 | 0x08 | 0x20, 0x1ED, 0); // write, create, truncate	
	let cos = Cc["@mozilla.org/intl/converter-output-stream;1"].createInstance(Ci.nsIConverterOutputStream);
	cos.init(fos, "UTF-8", 0, 0x0000);

	for(let i in this.febeUDBuList){
		let jstr = JSON.stringify(this.febeUDBuList[i]);
		cos.writeString(jstr+"\n");
	}
	cos.close();
	return true;
},

febeUDBuDisableAll: function (){
	document.getElementById("febeUDBuCaption").value = this.febeMsg[134];
	document.getElementById("febeUDBuListSelBtn").removeAllItems();
	document.getElementById("febeUDBuListSelBtn").setAttribute("label",this.febeMsg[135]);
	document.getElementById("febeUDBuListSelBtn").disabled = true;
	document.getElementById("febeUDBuLabelID").disabled = true;
	document.getElementById("febeUDBuLabel").disabled = true;
	document.getElementById("febeUDBuTypeID").disabled = true;
	document.getElementById("febeUDBuType").disabled = true;
	document.getElementById("febeUDBuDescID").disabled = true;
	document.getElementById("febeUDBuDesc").disabled = true;
	document.getElementById("febeUDBuSourceID").disabled = true;
	document.getElementById("febeUDBuSource").disabled = true;
	document.getElementById("febeUDBuBrowseBtn").disabled = true;
	document.getElementById("febeIncludeInBu_id").disabled = true;
	document.getElementById("febeUDBuSubmitBtn").disabled = true;
	document.getElementById("febeUDBuLabel").value = "";
	document.getElementById("febeUDBuDesc").value = "";
	document.getElementById("febeUDBuSource").value = "";
	document.getElementById("febeIncludeInBu_id").checked = false;
	this.febeUDBuStatusMsg("");
	return true;
},

febeUDBuEnableNew: function (){
	document.getElementById("febeUDBuCaption").value = this.febeMsg[136];
	document.getElementById("febeUDBuListSelBtn").setAttribute("label",this.febeMsg[135]);
	document.getElementById("febeUDBuListSelBtn").disabled = true;
	document.getElementById("febeUDBuLabelID").disabled = false;
	document.getElementById("febeUDBuLabel").disabled = false;
	document.getElementById("febeUDBuTypeID").disabled = false;
	document.getElementById("febeUDBuType").disabled = false;
	document.getElementById("febeUDBuDescID").disabled = false;
	document.getElementById("febeUDBuDesc").disabled = false;
	document.getElementById("febeUDBuSourceID").disabled = false;
	document.getElementById("febeUDBuSource").disabled = false;
	document.getElementById("febeUDBuBrowseBtn").disabled = false;
	document.getElementById("febeIncludeInBu_id").disabled = false;
	document.getElementById("febeUDBuSubmitBtn").disabled = false;
	document.getElementById("febeUDBuLabel").value = "";
	document.getElementById("febeUDBuDesc").value = "";
	document.getElementById("febeUDBuSource").value = "";
	document.getElementById("febeIncludeInBu_id").checked = false;
	this.febeUDBuStatusMsg("");
	return true;
},

febeUDBuEnableEdit: function (){
	document.getElementById("febeUDBuListSelBtn").setAttribute("label",this.febeMsg[135]);
	document.getElementById("febeUDBuListSelBtn").disabled = false;
	document.getElementById("febeUDBuLabelID").disabled = false;
	document.getElementById("febeUDBuLabel").disabled = true;
	document.getElementById("febeUDBuTypeID").disabled = false;
	document.getElementById("febeUDBuType").disabled = false;
	document.getElementById("febeUDBuDescID").disabled = false;
	document.getElementById("febeUDBuDesc").disabled = false;
	document.getElementById("febeUDBuSourceID").disabled = false;
	document.getElementById("febeUDBuSource").disabled = false;
	document.getElementById("febeUDBuBrowseBtn").disabled = false;
	document.getElementById("febeIncludeInBu_id").disabled = false;
	document.getElementById("febeUDBuSubmitBtn").disabled = false;
	document.getElementById("febeUDBuLabel").value = "";
	document.getElementById("febeUDBuDesc").value = "";
	document.getElementById("febeUDBuSource").value = "";
	document.getElementById("febeIncludeInBu_id").checked = false;
	this.febeUDBuStatusMsg("");
	return true;
},

febeUDBuEnableDelete: function (){
	document.getElementById("febeUDBuListSelBtn").removeAllItems();
	document.getElementById("febeUDBuListSelBtn").setAttribute("label",this.febeMsg[135]);
	document.getElementById("febeUDBuListSelBtn").disabled = false;
	document.getElementById("febeUDBuLabelID").disabled = false;
	document.getElementById("febeUDBuLabel").disabled = true;
	document.getElementById("febeUDBuTypeID").disabled = true;
	document.getElementById("febeUDBuType").disabled = true;
	document.getElementById("febeUDBuDescID").disabled = false;
	document.getElementById("febeUDBuDesc").disabled = true;
	document.getElementById("febeUDBuSourceID").disabled = false;
	document.getElementById("febeUDBuSource").disabled = true;
	document.getElementById("febeUDBuBrowseBtn").disabled = true;
	document.getElementById("febeIncludeInBu_id").disabled = true;
	document.getElementById("febeUDBuSubmitBtn").disabled = false;
	document.getElementById("febeUDBuLabel").value = "";
	document.getElementById("febeUDBuDesc").value = "";
	document.getElementById("febeUDBuSource").value = "";
	document.getElementById("febeIncludeInBu_id").checked = false;
	this.febeUDBuStatusMsg("");
	return true;
},

febeUDBuOK: function (){
	this.febeUDBuWrite();
	this.febeUDBuStatusMsg(this.febeMsg[149]);
	return true;
},

febeUDBuCancel: function (){
	FEBE.setStyles();
	if(this.febeUDBuTrxPending == true){
		let style = FEBE.febeStyle.orangeredBold
		let tmp = style+this.febeMsg[139]+"\n";
		tmp += style+this.febeMsg[140]+"\n\n";
		tmp += this.febeMsg[141];
		return FEBE.febeConfirm(tmp);
	}
	return true;
},

febeUDBuSubmit: function (){
	let febeUDBuItem = new this.febeUDBuObj; 
	febeUDBuItem.Label = document.getElementById("febeUDBuLabel").value;
	febeUDBuItem.Type = document.getElementById("febeUDBuType").selectedIndex;
	febeUDBuItem.Description = document.getElementById("febeUDBuDesc").value;
	febeUDBuItem.Path = document.getElementById("febeUDBuSource").value;
	febeUDBuItem.Include = document.getElementById("febeIncludeInBu_id").checked;
	let key = febeUDBuItem.Label;
	let action;
	switch(this.febeUDBuAction){
		case 1:	// New
			action = this.febeMsg[92];
			if(febeUDBuItem.Label == ""){
				this.febeAlert(this.febeMsg[142]);
				return false;
			}
			if(febeUDBuItem.Type == -1){
				this.febeAlert(this.febeMsg[160]);
				return false;
			}
			if(febeUDBuItem.Description == ""){
				this.febeAlert(this.febeMsg[143]);
				return false;
			}
			if(febeUDBuItem.Path == ""){
				this.febeAlert(this.febeMsg[144]);
				return false;
			}
			// See if label already exists
			for(let tmp in this.febeUDBuList){
				if(tmp == key){
					this.febeAlert(this.febeMsg[145].replace("%key%",key));
					return false;
				}
			}
			this.febeUDBuList[key] = febeUDBuItem;
			break;
		case 2:	// Edit
			action = this.febeMsg[93];
			this.febeUDBuList[key] = febeUDBuItem;
			break;
		case 3:	// Delete
			action = this.febeMsg[94];
			delete this.febeUDBuList[key];
			break;
		default:// WTF??
		;
	}//switch
	this.febeUDBuTrxPending = true;
	document.documentElement.getButton("extra2").disabled = false;
	this.febeUDBuDisableAll();
	this.febeUDBuStatusMsg(this.febeMsg[146].replace("%ACTION%",action));
	return true;
},

febeUDBuPopulateListbox: function (){
	// Clear existing items
	let submenu = document.getElementById("febeUDBuListSelBtn");
	let children = submenu.childNodes;
	let n = children.length;
	for (let i = 0; i < n; i++) {
		submenu.removeChild(children[0]);
	}
	for(let i in FEBE.febeUDBuList){
		let item = document.getElementById("febeUDBuListSelBtn").appendItem(FEBE.febeUDBuList[i].Label,FEBE.febeUDBuList[i].Label);
		item.className = "febeMenuitem";
	}
	document.getElementById("febeUDBuListSelBtn").disabled = false;
	return true;
},
 
febeUDBuDisplayData: function (){
	let key = document.getElementById("febeUDBuListSelBtn").selectedItem.value;
	switch(this.febeUDBuAction){
		case 2: 
			this.febeUDBuEnableEdit();
			break;
		case 3:
			this.febeUDBuEnableDelete();
			break;
	}//switch
	document.getElementById("febeUDBuLabel").value = this.febeUDBuList[key].Label;
	document.getElementById("febeUDBuType").selectedIndex = this.febeUDBuList[key].Type;
	document.getElementById("febeUDBuDesc").value = this.febeUDBuList[key].Description;
	document.getElementById("febeUDBuSource").value = this.febeUDBuList[key].Path;
	document.getElementById("febeIncludeInBu_id").setAttribute("checked",this.febeUDBuList[key].Include);
	return true;
},

febe_fillUDBUmenu: function (element){
  // Populate the restore UDBU submenu
  
	// Clear existing items
	let submenu = document.getElementById(element);
	let children = submenu.childNodes;
	let n = children.length;
	for (let i = 0; i < n; i++) {
		submenu.removeChild(children[0]);
	}
	this.febeUDBuInit();
	for(let i in this.febeUDBuList){
		let aMenuItem=document.createElement('menuitem');
		let item = this.febeUDBuList[i];
		aMenuItem.setAttribute( "label" , item.Label);
		aMenuItem.onclick = function(event){FEBE.febeRestoreUDBU(this.label);};
		aMenuItem.setAttribute( "tooltiptext" , this.febeMsg[170]+" "+item.Description);
		document.getElementById(element).appendChild(aMenuItem);
	}
	return true;
},

febeResetUDBu: function (){
	FEBE.setStyles();
	let style = FEBE.febeStyle.orangeredBold
	let tmp = style+this.febeMsg[174]+"\n\n";
	tmp += this.febeMsg[175];
	if(!FEBE.febeConfirm(tmp)){return true;};
	this.febeDataFile = Cc["@mozilla.org/file/directory_service;1"]
                 .getService(Ci.nsIProperties)
                 .get("ProfD", Ci.nsIFile);
	this.febeDataFile.append(this.FEBEDATAFILE);
	if(this.febeDataFile.exists()){this.febeDataFile.remove(false);}
	this.febeUDBuList = [];
	this.febeUDBuInit();
	this.febeUDBuPopulateListbox();
	this.febeUDBuDisableAll();
	this.febeAlert(this.febeMsg[176]);
	return true;
},

febeUDBuStatusMsg: function (msg){
	let d = document.getElementById("febeUDBustatusText");
	if(d){
		d.value = msg;
		//sizeToContent();
	}
	return true;
},

// FEBE Ignore list routines
febeBuildIgnoreList: function (){
	let febeIgnList = document.getElementById("febeIgnoreList");
	let febeIgnItems = febeIgnList.childNodes;
	FEBE.febeItemsSelectedCount = 0;
	FEBE.febeItemsListedCount = 0;
	
	// Clear the list
	let n = febeIgnItems.length;
	for (let i = 0; i < n; i++) {
		febeIgnList.removeChild(febeIgnItems[0]);
	}
	FEBE.febeBuildExtList();
	
	// Sort the list
	let sortArray = [];
	for(let i in FEBE.febeExtensionsList){
		//if(FEBE.febeExtensionsList[i].ignore == true) continue;
		let type = FEBE.febeExtensionsList[i].type;
		if(type != "extension" && type != "theme") continue;
		sortArray.push(FEBE.febeExtensionsList[i].name);
	}
	sortArray.sort();
	for(let i in sortArray){
		let item = FEBE.febeExtensionsList[FEBE.febeNameGuidxref[sortArray[i]]];
		let row = document.createElement('listitem');
		row.setAttribute('id', item.guid );
		row.setAttribute('type', "checkbox" );
		row.onclick = function(event){FEBE.febeCountSelectedIL(this)};

		let aType = "";
		if(item.isGlobal) aType = "(global)";
		if(item.isProxy) aType = "(proxy)";
		row.setAttribute('label', item.name+"{"+item.version+"}  "+aType );
		row.setAttribute('checked', item.ignore );
		
		// Always ignore Fx default theme and any global/proxy extensions
		if(item.guid == "{972ce4c6-7e08-4474-a285-3208198ce6fd}")row.setAttribute('checked', true );
		if(item.isGlobal == true) row.setAttribute('checked', true );
		if(item.isProxy == true) row.setAttribute('checked', true );

		if(item.type == "extension"){
			row.setAttribute('style', "color: blue;" );
		}else{
			row.setAttribute('style', "color: green;" );
		}
		if(item.isCompatible == false) row.setAttribute('style', "color: red;" );
		if(item.userDisabled) row.setAttribute('style', "color: grey;" );
		febeIgnList.appendChild( row );
		if(row.getAttribute('checked') == "true") FEBE.febeItemsSelectedCount++;
		FEBE.febeItemsListedCount++;
	}
	document.getElementById("febeSelectILAllID").disabled = false;
	document.getElementById("febeDeselectILAllID").disabled = false;
	document.getElementById("febeSelectILAICID").disabled = false;
	document.getElementById("febeSaveIgnoreListID").disabled = false;
	document.getElementById("febeIlSelectedValueID").value = FEBE.febeItemsSelectedCount;
	document.getElementById("febeILlistedValueID").value = FEBE.febeItemsListedCount;
	return true;
},

febeSelectQBU: function (bool){
  // Select/deselect all
	this.febeItemsSelectedCount = 0;
	for(let i in this.febeExtensionsList){
		let type = this.febeExtensionsList[i].type;
		if(type != "extension" && type != "theme") continue;
		let item = document.getElementById(i);
		if(item){
			item.setAttribute("checked",bool);
			if(bool) this.febeItemsSelectedCount++;
		}
	}
	document.getElementById("febeQbuSelectedValueID").value = this.febeItemsSelectedCount;
},

febeSelectIncompatable: function (){
	this.febeItemsSelectedCount = 0;
	for(let i in this.febeExtensionsList){
		let item = this.febeExtensionsList[i];
		let type = this.febeExtensionsList[i].type;
		if(type != "extension" && type != "theme") continue;
		item = document.getElementById(i);
		if(!this.febeExtensionsList[i].isCompatible) {
			item.setAttribute("checked",true)
			this.febeItemsSelectedCount++;
		}
	}
	document.getElementById("febeIlSelectedValueID").value = this.febeItemsSelectedCount;
},

febeCountSelected2: function (which){
	let check = this.febeExtensionsList[which.id].isGlobal || this.febeExtensionsList[which.id].isProxy;
	if(check){
		this.febeAlert(this.febeMsg[354]);
		which.checked = true;
		return;
	}
	let bool = which.checked;
	if(bool){
		this.febeItemsSelectedCount++;
	}else{
		this.febeItemsSelectedCount--;
	}
	document.getElementById("febeIlSelectedValueID").value = this.febeItemsSelectedCount;
	return true;
},

febeSaveIgnoreList: function (){
	let febeIgnList = document.getElementById("febeIgnoreList");
	let febeIgnItems = febeIgnList.childNodes;
	let n = febeIgnItems.length;
	
	// Create ignore list data file
	let ignoreList = [];
	for (let i = 0; i < n; i++) {
		let checked = febeIgnItems[i].checked;
		let id = febeIgnItems[i].id;
		let label = febeIgnItems[i].label;
		this.febeAddons[id].ignore = checked;
		if(checked){
			let ignoreItem = {};
			ignoreItem.id = id;
			ignoreItem.name = label;
			ignoreList.push(ignoreItem);
		}
	}
	
	// Write ignore list to file
	let fos, cos;
	
  // Get data from file - create template if needed
	this.febeDataFile = Cc["@mozilla.org/file/directory_service;1"].getService(Ci.nsIProperties).get("ProfD", Ci.nsIFile);
	this.febeDataFile.append(this.FEBEIGNORELISTDATAFILE);

	fos = Cc["@mozilla.org/network/file-output-stream;1"].createInstance(Ci.nsIFileOutputStream);
	fos.init(this.febeDataFile, 0x02 | 0x08 | 0x20, 0x1ED, 0); // write, create, truncate
	
	cos = Cc["@mozilla.org/intl/converter-output-stream;1"].createInstance(Ci.nsIConverterOutputStream);
	cos.init(fos, "UTF-8", 0, 0x0000);
	
	for(let i in ignoreList){
		let jstr = JSON.stringify(ignoreList[i]);
		cos.writeString(jstr+"\n"); 
	}
	
	cos.close();
	fos.close();
	this.febeAddons = [];	// Force rebuild of addon list
	this.febeGetAddonList();
	this.febeAlert(this.febeMsg[348]);
	return true;
},

febeBuildExtList: function (){
  //Get a list of all installed extensions/themes
	FEBE.febeExtensionsList = {};
	for(let guid in FEBE.febeAddons){
			let ext = FEBE.febeAddons[guid];
			FEBE.febeExtensionsList[guid] = ext;
			FEBE.febeNameGuidxref[ext.name] = guid; 
	}
	return true;
},

// FEBE Profile routines
febeProfileWindowInit: function (){
	let wm = Cc["@mozilla.org/appshell/window-mediator;1"].getService(Ci.nsIWindowMediator);
	win = wm.getMostRecentWindow("febe:restoreProfile");
	FEBE.febeProfileWin = win.document;

	if(!FEBE.febeInitDir()){return false;}
	FEBE.febeSetMsgs();
	FEBE.febeSetUnicharPref("extensions.febe.restoreToProfilePath","");  // Full path to backed up profile
	
	FEBE.febePrName = FEBE.febeMsg[293];
	FEBE.febeSetUnicharPref("extensions.febe.restoreProfileFromBackupName",FEBE.febePrName);

	FEBE.febePrName = FEBE.febeMsg[295];
	FEBE.febeSetUnicharPref("extensions.febe.restoreToProfileName",FEBE.febePrName);
	
	FEBE.febePlatform = FEBE.febeGetPlatform();
	let d = document.getElementById("create_shortcut_id");
	if(FEBE.febePlatform == 1){
		d.setAttribute('hidden','false');	// Windows
	}else{
		d.setAttribute('hidden','true');	// Not windows
	}
	FEBE.febeSetRestoreProfileHeader();
	FEBE.febeBuildProfileList();
	FEBE.febeProfileIndex = -1;
	FEBE.febeProfileBackupIsSelected = false;
	FEBE.febeProfileDestinationIsSelected = false;
	FEBE.febeProfileRestoreSanityCheck();
},

febeSetRestoreProfileHeader: function (){
	let pname, prefName, label, febePrRestName;
	pname = FEBE.febeProfileWin.getElementById("febeCurrentProfileText");
	pname.value = FEBE.febeProfName ;
	this.febeProfList = FEBE.febeGetProfileList();
	
	FEBE.febePathName = FEBE.febePrefs.getCharPref("extensions.febe.restoreProfileFromBackupPath");  // Full path to backed up profile
	
	FEBE.febePrName = FEBE.febePrefs.getCharPref("extensions.febe.restoreProfileFromBackupName");
	label = FEBE.febeProfileWin.getElementById("febeSelectedProfileText");
	if(FEBE.febePrName == FEBE.febeMsg[293]){
		label.className = "invalidItem";
	}else{
		label.className = "fontbold";
	}

	if(FEBE.febeIsOnlineBackup){	
		label.value = FEBE.febePrName + " "+ FEBE.febeMsg[304];
	}else{
		label.value = FEBE.febePrName;
	}
	
	febePrRestName = FEBE.febePrefs.getCharPref("extensions.febe.restoreToProfileName");
	label = FEBE.febeProfileWin.getElementById("febeDestinationProfileText");
	if(febePrRestName == FEBE.febeMsg[295]){
		label.className = "invalidItem";
	}else{
		label.className = "fontbold";
	}
	label.value = febePrRestName;
	return true;
},

febeBuildProfileList: function (sel){	
	// Clear existing items
	let theTree = document.getElementById("febeProfileList");
	let children = theTree.childNodes;
	let n = children.length;
	for(let i = 0; i < n; i++) {
		theTree.removeChild(children[0]);
	}
	
	let files = Cc["@mozilla.org/file/directory_service;1"]
        .getService(Ci.nsIProperties)
        .get("DefProfRt", Ci.nsIFile);
	let dfltProfile = files.path;
	
	for(let i = 0; i < this.febeProfList.length; i++){
		let rootPath = this.febeProfList[i].rootDir.path;
		let item = FEBE.febeProfileWin.getElementById("febeProfileList")
			.appendItem (this.febeProfList[i].name,rootPath);
		item.label = this.febeProfList[i].name;
		item.setAttribute("tooltiptext",FEBE.febeMsg[286]+" "+rootPath);
		if(rootPath.indexOf(dfltProfile) == 0){
			item.className = "defaultDir";		// Default directory
		}else{
			item.className = "nonDefaultDir";// Non-default directory
		}
		if(item.label == FEBE.febeProfName ){
			item.disabled = true;
			item.className = "invalidItem";
		}
	}
	FEBE.febeProfileWin.getElementById("febeProfileList").selectedIndex = -1;	// Clear selected item
	
	if(this.febeProfList.length == 1){	// If there is only one profile, display help message
		let d = FEBE.febeProfileWin.getElementById("febeRestoreID").value;
		FEBE.febeHelp('99',d);
		FEBE.febeProfileDestinationIsSelected = true;
		FEBE.febeProfileRestoreSanityCheck();
		return false;
	}
	
	if(!sel) sel = -1;
	if(sel >=0){
		FEBE.febeProfileWin.getElementById("febeProfileList").selectedIndex = sel;
		FEBE.febeProfileWin.getElementById("febeProfileList").ensureIndexIsVisible(sel);
		FEBE.febeProfileIndex = sel;
		FEBE.febeProfileDestinationIsSelected = true;
		FEBE.febeProfileRestoreSanityCheck();
	}
	return true;
},

febeProfileSelected: function (){
	FEBE.febeProfileIndex = FEBE.febeProfileWin.getElementById("febeProfileList").selectedIndex;
	if(FEBE.febeProfileIndex == -1){return false;}
	
	let item = FEBE.febeProfileWin.getElementById("febeProfileList").selectedItem.label;
	if(item == FEBE.febeProfName ){
		FEBE.febeAlert(FEBE.febeMsg[6]);	// Can't be current profile
		return false;
	}
	let label = FEBE.febeProfileWin.getElementById("febeDestinationProfileText");
	label.value = item;
	label.className = "fontbold";
	FEBE.febePrefs.setCharPref("extensions.febe.restoreToProfileName",item);
	FEBE.febeProfileDestinationIsSelected = true;
	return true;
},

febeGetProfileList: function (){
	let profArray = [];
	let profiles = FEBE.febeProfileService.profiles;
	while (profiles.hasMoreElements()) {
		let profile = profiles.getNext().QueryInterface(Ci.nsIToolkitProfile);
		profArray.push(profile);
	}
	return profArray;
},

febeCreateProfileInit: function (){
	document.getElementById("febeProfileButtonBox").setAttribute("hidden","true");
	document.getElementById("febeCreateProfileID").setAttribute("hidden","false");
	document.getElementById("newprofileID").reset();
	document.getElementById("newprofileID").focus();
	document.getElementById("febeProfileList").disabled = true;
	FEBE.febeProfileRestoreSanityCheck();
	return true;
},

febeCancelCreateProfile: function (){
	document.getElementById("febeProfileButtonBox").setAttribute("hidden","false");
	document.getElementById("febeCreateProfileID").setAttribute("hidden","true");
	document.getElementById("newprofileID").focus();
	document.getElementById("febeProfileList").disabled = false; 
	FEBE.febeProfileRestoreSanityCheck();
	return true;
},

febeCreateProfile: function (){
	let newProfileName = document.getElementById("newprofileID").value;
	if(!FEBE.febeCheckProfileName(newProfileName)){return false;}
	let dirService = Cc["@mozilla.org/file/directory_service;1"].getService(Ci.nsIProperties);
	let proot = dirService.get("DefProfRt", Ci.nsIFile);
	let prName = "febeprof." + newProfileName;	// Use 'febeprof' as the salt value to easily identify which profiles FEBE creates
	proot.append(prName);
	try{
		let newProfile = FEBE.febeProfileService.createProfile(proot, newProfileName);
		FEBE.febeProfileService.flush();
		FEBE.febeProfList.push(newProfile);
		let tmp = FEBE.febeMsg[288].replace("%PROFILE%",newProfileName);		
		let createShortcut = document.getElementById("create_shortcut_id").checked;
		if(createShortcut){
			FEBE.createDesktopShortcut(newProfileName);
			tmp += "\n\n"+FEBE.febeMsg[559].replace("%NAME%",newProfileName);
		}
		FEBE.febeAlert(tmp);
		FEBE.febeCancelCreateProfile();
		FEBE.febePrName = newProfileName;
		document.getElementById("febeProfileList").selectedIndex
		FEBE.febeSetRestoreProfileHeader();
		let sel = this.febeProfList.length-1;
		FEBE.febeBuildProfileList(sel);
	}catch(e){
		FEBE.febeFatal(e,FEBE.febeMsg[289],true);
		return false;
	}
	return true;
},

createDesktopShortcut: function(profileName){
	let pref = FEBE.febePrefs.getCharPref("extensions.febe.FxExecutablePath");
	let Fx;
	if(FEBE.febePrefs.prefHasUserValue(pref)){
		let path = FEBE.febePrefs.getCharPref(pref);
		Fx = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
		Fx.initWithPath(path);
	}else{
		Fx = FileUtils.getFile('XREExeF', []);
		FEBE.febePrefs.setCharPref(pref,Fx.path);
	}
	let sc = FileUtils.getFile('Desk', [profileName+'.lnk']);
	let winSc = sc.QueryInterface(Ci.nsILocalFileWin);
	winSc.setShortcut(Fx, null, '-p '+'"'+profileName+'"');
	return true;
},

febeCheckProfileName: function (profileNameToCheck){
  // Check for emtpy profile name.
	if (!/\S/.test(profileNameToCheck)){
		FEBE.febeAlert(FEBE.febeMsg[290]);
		return false;
	}

	// Check whether all characters in the profile name are allowed.
	if (/([\\*:?<>|\/\"])/.test(profileNameToCheck)){
		let tmp = FEBE.febeMsg[291].replace("%BADCHAR%",[RegExp.$1]);
		FEBE.febeAlert(tmp);
		return false;
	}

	// Check whether a profile with the same name already exists.
	if (FEBE.febeProfileExists(profileNameToCheck)){
		FEBE.febeAlert(FEBE.febeMsg[292]);
		return false;
	}
	
	// profileNameToCheck is valid.
	return true;
},

febeProfileExists: function (aName){
	let profiles = FEBE.febeProfileService.profiles;
	while (profiles.hasMoreElements()) {
		let profile = profiles.getNext().QueryInterface(Ci.nsIToolkitProfile);
		if (profile.name.toLowerCase() == aName.toLowerCase()){return true;}
	}
	return false;
},

febeGetProfileBackup: function (which){
	FEBE.setStyles();
	if(!FEBE.febeInitDir()){return false;}
	if(which == "local"){
		FEBE.febePathName = "";
		let mask = "FEBE profile backups; profileFx*{*}.fbu;"
		if(FEBE.febePlatform == 3) mask = "*.fbu";	// Bug 444423
		if(!this.febePickRestoreFile(mask,90)){return true};

		let ok = FEBE.febePrName.match(/^profileFx[\d+].*\{.*\}\.fbu$/)
		if(!ok){
			let tmp = FEBE.febeStyle.purpleBold+FEBE.febeMsg[103].replace("%FILE%","'"+FEBE.febePrName+"'")+"\n";
			FEBE.febeAlert(tmp);
			return false;
		}
		
		FEBE.febeSetUnicharPref("extensions.febe.restoreToProfilePath",FEBE.febePathName);
		FEBE.febePrefs.setCharPref("extensions.febe.restoreProfileFromBackupName",FEBE.febePrName);
		FEBE.febeIsOnlineBackup = false;
	}else{
		let date = FEBEstorage.getItem("created", "");
		FEBE.febePathName = FEBEstorage.getItem("location", "");
		FEBE.febePrName = FEBEstorage.getItem("boxname", "");
		FEBE.febeBUdate = new Date(parseInt(date));
		
		FEBE.febeSetUnicharPref("extensions.febe.restoreToProfilePath",FEBE.febePathName);
		
		FEBE.febePrefs.setCharPref("extensions.febe.restoreProfileFromBackupName",FEBE.febePrName);
		FEBE.febeIsOnlineBackup = true;
		let wm = Cc["@mozilla.org/appshell/window-mediator;1"].getService(Ci.nsIWindowMediator);
		let win = wm.getMostRecentWindow("febe:boxrestore");
		if(win) win.close();
		win = wm.getMostRecentWindow("febe:restoreProfile");
		FEBE.febeProfileWin = win.document;
		FEBE.febeProfileSelected();
	}
	FEBE.febeSetRestoreProfileHeader();
	FEBE.febeProfileBackupIsSelected = true;
	FEBE.febeProfileRestoreSanityCheck();
	return true;
},

febeStartProfileRestoreCheck: function (){
	let restorePath = FEBE.febeGetUnicharPref("extensions.febe.restoreToProfilePath");
	
	if(restorePath == ""){
		FEBE.febeAlert(FEBE.febeMsg[294]);	// No backup file selected
		return false;
	}
	FEBE.febeProfileWin.getElementById("febeProfileList").selectedIndex = FEBE.febeProfileIndex;
	if(FEBE.febeProfileWin.getElementById("febeProfileList").selectedIndex == -1){
		FEBE.febeAlert(FEBE.febeMsg[48]);	// No destination profile selected
		return false;
	}
	FEBE.febeStartProfileRestore(this.febeProfList[FEBE.febeProfileIndex]);
	return true;
},

febeSwitchToProfile: function (profileName){	
	let newProfile = FEBE.febeProfileService.getProfileByName(profileName);
	FEBE.febeProfileService.selectedProfile = newProfile;
	FEBE.febeProfileService.startWithLastProfile = true;
	FEBE.febeProfileService.flush();
	return true;
},

febeStartupOptions: function (){
	let opt = FEBE.febeProfileWin.getElementById("febeStartupOptionID").selectedIndex;
	switch(opt){
		case 0:	// Use new/selected profile
			let profileName = FEBE.febePrefs.getCharPref("extensions.febe.restoreToProfileName");			
			if(profileName == FEBE.febeMsg[295]){	// No profile selected
				FEBE.febeAlert(FEBE.febeMsg[303]);
				break;
			}
			let newProfile = FEBE.febeProfileService.getProfileByName(profileName);
			FEBE.febeProfileService.selectedProfile = newProfile;
			FEBE.febeProfileService.startWithLastProfile = true;
			FEBE.febeProfileService.flush();
			FEBE.febeShutdownRestart(profileName);
			break;
		case 1:	// Use profile manager
			FEBE.febeProfileService.startWithLastProfile = false;
			FEBE.febeProfileService.flush();
			FEBE.febeShutdownRestart("");
			break;
		case 2:	// Do nothing			
			let startupbox = FEBE.febeProfileWin.getElementById("febeStartupBox");
			startupbox.setAttribute("hidden", "true");
			
			let buttonbox = FEBE.febeProfileWin.getElementById("febeProfileButtonBox");
			buttonbox.setAttribute("hidden", "false");

			//sizeToContent();
			break;
	}//switch
	FEBE.febeProfileRestoreSanityCheck();
	return true;
},

febeShutdownRestart: function (profileName){
	// Restart Fx with the given profile
	// Note: This routine uses 'nsIProcess' because I can find no other way to restart Fx with a different profile.
	FEBE.febeSetMsgs();
	let tmp = "";
	if(profileName != ""){
		tmp = FEBE.febeMsg[296] = FEBE.febeMsg[296].replace(/%PROFILE%/,"'"+profileName+"'");	// New porofile
	}else{
		tmp = FEBE.febeMsg[297];		// Profile Manager
	}
	let app = FEBE.febeGetEnvironmentVariableValue("MOZ_CRASHREPORTER_RESTART_ARG_0");
	if(app){
		tmp += "\n\n<style>color: orangered; font-weight: bold; font-size: 12px;</style>"+FEBE.febeMsg[298]+"\n";
	}
	let OK = FEBE.febeConfirm(tmp);
	if(OK && app){
		let Fx = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
		Fx.initWithPath(app);
		let args = [];
		if(profileName != ""){	// Start with profile
			args[0] = "-P";
			args[1] = profileName;
			args[2] = "-no-remote";
		}else{
			args[0] = "-no-remote";
			args[1] = "-P";
		}
		let process = Cc["@mozilla.org/process/util;1"].getService(Ci.nsIProcess);
		process.init(Fx);
		process.run(false,args,args.length);
		window.setTimeout(function(){FEBE.febeQuitFx();},1000);	// Give it a second to catch up, then shutdown
	}else{
		let startupbox = FEBE.febeProfileWin.getElementById("febeStartupBox");
		startupbox.setAttribute("hidden", "true");
		
		let buttonbox = FEBE.febeProfileWin.getElementById("febeProfileButtonBox");
		buttonbox.setAttribute("hidden", "false");

		//sizeToContent();
	}
	FEBE.febeProfileRestoreSanityCheck();
	return true;
},

febeStartupButton: function (){
	let startupbox = FEBE.febeProfileWin.getElementById("febeStartupBox");
	startupbox.setAttribute("hidden", "false");
	
	let buttonbox = FEBE.febeProfileWin.getElementById("febeProfileButtonBox");
	buttonbox.setAttribute("hidden", "true");

	//sizeToContent();
	return true;
},

febeQuitFx: function (){
	FEBEstorage.setItem("shuttingDownAfterProfileRestore", true);
	FEBE.febeMainWindow.goQuitApplication();	// Use the shutdown routine in chrome/global/globalOverlay.js
},

febeRestoreProfile: function (){
	// Open restore profile window
	FEBE.febeGetPlatform();
	let opts;
	if(FEBE.febePlatform == 3){	// No modal windows for Mac
		opts = "chrome,alwaysRaised,centerscreen,resizable,dialog='no'"
	}else{
		opts = "chrome,alwaysRaised,centerscreen,resizable,dialog='no'"
	}
	FEBE.febeWin = window.open('chrome://febe/content/febeProfile.xul', 'FEBE Profile Restore', opts);	
	return true;
},

febeStartProfileRestore: function (){
	if(!FEBE.febeInitDir()){return false;}
	let wm = Cc["@mozilla.org/appshell/window-mediator;1"].getService(Ci.nsIWindowMediator);  
	FEBE.febeWin = wm.getMostRecentWindow("febe:restoreProfile");  
	
	FEBE.febePathName = FEBE.febeGetUnicharPref("extensions.febe.restoreToProfilePath");  // Full path to backed up profile
	if(!FEBE.febeIsOnlineBackup){FEBE.febeGetBuDate(FEBE.febePathName);} 
	if(FEBE.febeConfirmRestore(75,FEBE.febeBUdate,false,true)){	
		if(!FEBE.febeInitDir()){return false;}
		let buttonbox = document.getElementById("febeProfileButtonBox");
		buttonbox.setAttribute("hidden", "true");

		let progressbox = document.getElementById("febeProfileRestoreBox");
		progressbox.setAttribute("hidden", "false");
		
		setTimeout(function(){FEBE.febeStartProfileRestore2();},500);	// Let the browser catch up
	}else{
		FEBE.febeAlert(FEBE.febeMsg[46]);
	}
	return true;
},

febeStartProfileRestore2: function (){
	// Remove contents of destination profile
	let wm = Cc["@mozilla.org/appshell/window-mediator;1"].getService(Ci.nsIWindowMediator);  
	FEBE.febeWin = wm.getMostRecentWindow("febe:restoreProfile"); 
	let item = FEBE.febeProfileWin.getElementById("febeProfileList").selectedItem
	let destProfile = item.value;
	let pDestDir = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
	pDestDir.initWithPath(destProfile);
	let entries = pDestDir.directoryEntries;
	while(entries.hasMoreElements()){
		let entry = entries.getNext();   
		entry.QueryInterface(Ci.nsIFile);
		try{
			entry.remove(true);
		}catch(err){
			if(entry.isDirectory()){
				entry.permissions = 0x1ED;
				FEBE.febeChmod(entry.path);
			}else{
				entry.permissions = 0x1A4;
			}
			entry.remove(true);	
		}
	}
	
	let zipFile = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsIFile);
	zipFile.initWithPath(FEBE.febePathName);
	
	let sourceDir = zipFile.parent.path;
	let destDir = destProfile;
	let zipName = zipFile.leafName
	let OK = true;
	OK = FEBE.febeMainWindow.FEBE.febeUnzip(sourceDir,destDir,zipName);
	let progressbox = document.getElementById("febeProfileRestoreBox");
	progressbox.setAttribute("hidden", "true");
	if(OK){
		FEBE.febeChmod(destDir);			
		FEBE.febeAlert(FEBE.febeMsg[91]);
	}else{
		FEBE.febeAlert(FEBE.febeMsg[46]);
	}
	let buttonbox = document.getElementById("febeProfileButtonBox");
	buttonbox.setAttribute("hidden", "false");
	FEBE.febeProfileRestoreSanityCheck();
	return true;
},

febeProfileRestoreSanityCheck: function (){
  // Don't enable the ""start restore" button unless everything is ready to go
	let spb = FEBE.febeProfileWin.getElementById("startProfileRestoreID");
	if(FEBE.febeProfileBackupIsSelected && FEBE.febeProfileDestinationIsSelected){
		spb.disabled = false;
	}else{
		spb.disabled = true;
	}
	
	//let obu = FEBE.febeProfileWin.getElementById("onlinerestorebuttonID");
	//let boxEnabled = FEBE.febePrefs.getBoolPref("extensions.febe.boxnet.enabled");
	//obu.setAttribute("disabled",!boxEnabled);
	//obu.setAttribute("hidden",!boxEnabled);
	return true;
},

febeTabStyle: function(tabElm){
	let tabs = tabElm.getElementsByTagName('tab');
	for(let index = 0; index<tabs.length; index++){
		let tab = tabs[index];
		tab.className = tab.selected ? "tabSelected" : "tabNotSelected";
	}
},

// FEBE Help routines
febeLoadHelp: function (){
	var index = window.arguments[0];
	var field = window.arguments[1];
	FEBE.febeClipboard = [];

	document.getElementById("field").value = field;
	var stringBundleService = Cc["@mozilla.org/intl/stringbundle;1"].getService(Ci.nsIStringBundleService);
	var helpFile = stringBundleService.createBundle("chrome://febe/locale/febeHelp.properties");
	var helpTxt = helpFile.GetStringFromName("febe.help_"+index+".text1");
	
	// XUL palette
	var description = document.createElement('description');
	description.setAttribute('flex', "1");
	var separator = document.createElement('separator');
	separator.setAttribute('class', "thin");
	var vbox = document.createElement('vbox');
	var hbox = document.createElement('hbox');
	var grid = document.createElement('grid');
	var columns = document.createElement('columns');
	var column = document.createElement('column');
	var rows = document.createElement('rows');
	var row = document.createElement('row');
	var spacer = document.createElement('spacer');
	spacer.setAttribute('flex', "1");
	var image = document.createElement('image');
	var label = document.createElement('label');
	var text = document.createElement('text');
	var htmlul = document.createElementNS(this.febeNamespace,'html:ul');
	var htmlli = document.createElementNS(this.febeNamespace,'html:li');
	var htmlbr = document.createElementNS(this.febeNamespace,'html:br');
	var helpTxtbox = document.getElementById('helptextbox');
	switch(index){
		case "51":	// Restore cookies
			helpTxt = helpFile.GetStringFromName("febe.help_"+index+".text1");
			addHelpLine(helpTxt);
			helpTxtbox.appendChild(separator);
			helpTxt = helpFile.GetStringFromName("febe.help_"+index+".text2");
			addHelpLine(helpTxt);
			break;
		case "05":	// Restore profile
		case "99":	
			helpTxt = helpFile.GetStringFromName("febe.help_05.text1").replace("%LINK%","");
			var desc = description.cloneNode(true);
			desc.appendChild(document.createTextNode(helpTxt));
			text = text.cloneNode(false);
			text.setAttribute('value', "http://kb.mozillazine.org/Profile_Manager");
			text.setAttribute('class', "link");
			text.onclick = function(event){FEBE.febeOpenLink('http://kb.mozillazine.org/Profile_Manager')};

			desc.appendChild(text);
			helpTxtbox.appendChild(desc);
			
			// Parse colored text
			// Items listed in %GREEN%green%/GREEN% are located in the default directory, %PURPLE%purple%/PURPLE% in a non-default. %RED%Red%/RED% indicates an invalid directory.
			helpTxt = helpFile.GetStringFromName("febe.help_05.text2");
			var p1 = helpTxt.indexOf("%GREEN%");
			var p2 = helpTxt.indexOf("%/GREEN%");
			var txt1 = helpTxt.substr(0,p1);			//"Items listed in "
			var green = helpTxt.substring(p1+7,p2);		// "green"
			var helpTxt = helpTxt.substr(p2+8);			// " are located in the default directory, %PURPLE%purple%/PURPLE% in a non-default. %RED%Red%/RED% indicates an invalid directory."
			
			var p1 = helpTxt.indexOf("%PURPLE%");
			var p2 = helpTxt.indexOf("%/PURPLE");
			var txt2 = helpTxt.substr(0,p1);			//" are located in the default directory, "
			var purple = helpTxt.substring(p1+8,p2);	// "purple"
			var helpTxt = helpTxt.substr(p2+9);			// "  in a non-default. %RED%Red%/RED% indicates an invalid directory."
			
			var p1 = helpTxt.indexOf("%RED%");
			var p2 = helpTxt.indexOf("%/RED");
			var txt3 = helpTxt.substr(0,p1);			//""
			var red = helpTxt.substring(p1+5,p2);		// "red"
			var txt4 = helpTxt.substr(p2+6);			// "  indicates an invalid directory."
			
			var desc = description.cloneNode(true);
			var text = text.cloneNode(false);
			text.setAttribute('value', txt1);
			text.removeAttribute('style');
			text.removeAttribute('class');
			text.removeAttribute('onclick');
			desc.appendChild(text);
			
			var text = text.cloneNode(false);
			text.setAttribute('value', green);
			text.setAttribute('style', "color: green;");
			desc.appendChild(text);
			
			var text = text.cloneNode(false);
			text.setAttribute('value', txt2);
			text.removeAttribute('style');
			desc.appendChild(text);
			
			var text = text.cloneNode(false);
			text.setAttribute('value', purple);
			text.setAttribute('style', "color: purple;");
			desc.appendChild(text);
			
			var text = text.cloneNode(false);
			text.setAttribute('value', txt3);
			text.removeAttribute('style');
			desc.appendChild(text);
			
			var text = text.cloneNode(false);
			text.setAttribute('value', red);
			text.setAttribute('style', "color: red;");
			desc.appendChild(text);
			
			var text = text.cloneNode(false);
			text.setAttribute('value', txt4);
			text.removeAttribute('style');
			desc.appendChild(text);
			
			helpTxtbox.appendChild(desc);			
			
			helpTxt = helpFile.GetStringFromName("febe.help_05.text3");
			addHelpLine(helpTxt);
			
			if(index == "99"){	// Restore profile error message
				helpTxtbox.appendChild(separator);
				var desc = description.cloneNode(true);
				helpTxt = helpFile.GetStringFromName("febe.help_99.text1");
				var text = text.cloneNode(false);
				text.setAttribute('value', helpTxt);
				text.setAttribute('class', "font12");
				desc.appendChild(text);
				
				helpTxt = helpFile.GetStringFromName("febe.help_99.text2")+" "+helpFile.GetStringFromName("febe.help_99.text3")+" ";
				desc.appendChild(document.createTextNode(helpTxt));
				
				var linkTxt = helpFile.GetStringFromName("febe.help_99.text4");
				var text = text.cloneNode(false);
				text.setAttribute('class', "link");
				text.setAttribute('value', linkTxt);
				text.onclick = function(event){FEBE.febeOpenLink('http://www.customsoftwareconsult.com/phpBB2/viewtopic.php?t=593')};

				desc.appendChild(text);
				
				helpTxt = " "+helpFile.GetStringFromName("febe.help_99.text5");
				var text = text.cloneNode(false);
				text.setAttribute('value', helpTxt);
				text.removeAttribute('class');
				text.removeAttribute('onclick');
				desc.appendChild(text);				
				helpTxtbox.appendChild(desc);				
			}
			break;
		case "07":
			var htmlul = htmlul.cloneNode(false);
			var htmlli = htmlli.cloneNode(false);
			var image = image.cloneNode(false);
			image.setAttribute('src', "chrome://febe/skin/play.png");
			image.setAttribute('style', "cursor: pointer");
			var tooltip = helpFile.GetStringFromName("febe.help_"+index+".text7");
			image.setAttribute('tooltiptext', tooltip);	
			
			helpTxt = helpFile.GetStringFromName("febe.help_"+index+".text1");
			addHelpLine(helpTxt);

			helpTxt = helpFile.GetStringFromName("febe.help_"+index+".text2")+"  ";
			var htmlli = htmlli.cloneNode(false);
			htmlli.appendChild(document.createTextNode(helpTxt));
			var image = image.cloneNode(true);
			image.onclick = function(event){FEBE.febePlaySoundHelp('busuccess')};
			htmlli.appendChild(image);
			htmlul.appendChild(htmlli);
			helpTxt = helpFile.GetStringFromName("febe.help_"+index+".text3")+"  ";
			var htmlli = htmlli.cloneNode(false);
			htmlli.appendChild(document.createTextNode(helpTxt));
			var image = image.cloneNode(true);
			image.onclick = function(event){FEBE.febePlaySoundHelp('bufailure')};
			htmlli.appendChild(image);
			htmlul.appendChild(htmlli);
			
			helpTxt = helpFile.GetStringFromName("febe.help_"+index+".text4")+"  ";
			var htmlli = htmlli.cloneNode(false);
			htmlli.appendChild(document.createTextNode(helpTxt));
			var image = image.cloneNode(true);
			image.onclick = function(event){FEBE.febePlaySoundHelp('warning')};			
			htmlli.appendChild(image);
			htmlul.appendChild(htmlli);

			helpTxt = helpFile.GetStringFromName("febe.help_"+index+".text5")+"  ";
			var htmlli = htmlli.cloneNode(false);
			htmlli.appendChild(document.createTextNode(helpTxt));
			var image = image.cloneNode(true);
			image.onclick = function(event){FEBE.febePlaySoundHelp('message')};
			htmlli.appendChild(image);
			htmlul.appendChild(htmlli);
			
			helpTxt = helpFile.GetStringFromName("febe.help_"+index+".text6")+"  ";
			var htmlli = htmlli.cloneNode(false);
			htmlli.appendChild(document.createTextNode(helpTxt));
			var image = image.cloneNode(true);
			image.onclick = function(event){FEBE.febePlaySoundHelp('help')};

			htmlli.appendChild(image);
			htmlul.appendChild(htmlli);
			
			vbox.appendChild(htmlul);
			helpTxtbox.appendChild(vbox);
			
			var vbox = vbox.cloneNode(false);
			vbox.setAttribute('style', "font-style:italic");
			
			var desc = description.cloneNode(true);
			helpTxt = helpFile.GetStringFromName("febe.help_"+index+".text8");
			desc.appendChild(document.createTextNode(helpTxt));
			vbox.appendChild(desc);
					
			helpTxtbox.appendChild(vbox);
			break;
		case "09":
			var hbox = hbox.cloneNode(false);
			var desc = description.cloneNode(true);
			helpTxt = helpFile.GetStringFromName("febe.help_"+index+".text1")
			
			desc.appendChild(document.createTextNode(helpTxt));
			hbox.appendChild(desc);
			helpTxtbox.appendChild(hbox);
			var separator = separator.cloneNode(true);
			helpTxtbox.appendChild(separator);

			var grid = grid.cloneNode(false);
				var columns = columns.cloneNode(false);
					var column = column.cloneNode(false);
						columns.appendChild(column);
					var column = column.cloneNode(false);
						column.setAttribute('flex', "1");
						columns.appendChild(column);
					grid.appendChild(columns);
				var rows = rows.cloneNode(false);
					var row = row.cloneNode(false);
						var image = image.cloneNode(false);
							image.setAttribute('style', "max-width: 24px; max-height: 24px");
							image.setAttribute('src', "chrome://febe/skin/febeScheduled.png");
						var desc = description.cloneNode(true);
							helpTxt = helpFile.GetStringFromName("febe.help_"+index+".text2")
							desc.appendChild(document.createTextNode(helpTxt));
						row.appendChild(image);	
						row.appendChild(desc);
						rows.appendChild(row);
						var row = row.cloneNode(false);
						var image = image.cloneNode(false);
							image.setAttribute('style', "max-width: 24px; max-height: 24px");
							image.setAttribute('src', "chrome://febe/skin/febeNotScheduled.png");
						var desc = description.cloneNode(true);
							helpTxt = helpFile.GetStringFromName("febe.help_"+index+".text3")
							desc.appendChild(document.createTextNode(helpTxt));
						row.appendChild(image);	
						row.appendChild(desc);
					rows.appendChild(row);	
						var row = row.cloneNode(false);
						var image = image.cloneNode(false);
							image.setAttribute('style', "max-width: 24px; max-height: 24px");
							image.setAttribute('src', "chrome://febe/skin/febeScheduleWarning.gif");
						var desc = description.cloneNode(true);
							helpTxt = helpFile.GetStringFromName("febe.help_"+index+".text4")
							desc.appendChild(document.createTextNode(helpTxt));
						row.appendChild(image);	
						row.appendChild(desc);	

					rows.appendChild(row);
				
			grid.appendChild(rows);
			helpTxtbox.appendChild(grid);
			
			var hbox = hbox.cloneNode(false);
			var desc = description.cloneNode(true);
			helpTxt = helpFile.GetStringFromName("febe.help_"+index+".text5")			
			desc.appendChild(document.createTextNode(helpTxt));
			hbox.appendChild(desc);
			helpTxtbox.appendChild(hbox);
			var separator = separator.cloneNode(true);
			helpTxtbox.appendChild(separator);

			var hbox = hbox.cloneNode(false);
			var desc = description.cloneNode(true);
			helpTxt = helpFile.GetStringFromName("febe.help_"+index+".text6")			
			desc.appendChild(document.createTextNode(helpTxt));
			hbox.appendChild(desc);
			helpTxtbox.appendChild(hbox);
			var separator = separator.cloneNode(true);
			helpTxtbox.appendChild(separator);
			break;
		case "11":
			helpTxt = helpFile.GetStringFromName("febe.help_"+index+".text1");
			addHelpLine(helpTxt);
			helpTxtbox.appendChild(spacer);
			
			var desc = description.cloneNode(true);
			var hbox = hbox.cloneNode(false);
			var label = label.cloneNode(false);
				helpTxt = helpFile.GetStringFromName("febe.help_"+index+".text2");
				label.setAttribute('value', helpTxt);
			var image = image.cloneNode(false);
				image.setAttribute('class', "helpButton");
			hbox.appendChild(label);
			hbox.appendChild(separator);
			hbox.appendChild(image);
			desc.appendChild(hbox);
			helpTxtbox.appendChild(desc);
			helpTxt = helpFile.GetStringFromName("febe.help_"+index+".text3");
			addHelpLine(helpTxt);
			break;
		case "21":
			for(var i=1; i<11; i++){ 
				helpTxt = helpFile.GetStringFromName("febe.help_"+index+".text"+i);
				addHelpLine(helpTxt);
			}
			break;
		case "41":
			helpTxt = helpFile.GetStringFromName("febe.help_"+index+".text1");
			addHelpLine(helpTxt);
			helpTxtbox.appendChild(spacer);

			helpTxt = helpFile.GetStringFromName("febe.help_"+index+".text2")+" ";
			var desc = description.cloneNode(true);
			desc.setAttribute('style', "font-style: italic;");
			desc.appendChild(document.createTextNode(helpTxt));
			helpTxtbox.appendChild(desc);
			helpTxtbox.appendChild(spacer);

			for(var i=3; i<6; i++){ 
				helpTxt = helpFile.GetStringFromName("febe.help_"+index+".text"+i);
				addHelpLine(helpTxt);
			}
			break;
		case "57":	// Check AM functionalilty
			var desc = description.cloneNode(true);
			helpTxt = helpFile.GetStringFromName("febe.help_"+index+".text1")+" ";
			desc.appendChild(document.createTextNode(helpTxt));
			var linkTxt = helpFile.GetStringFromName("febe.help_"+index+".text2");
			var text = text.cloneNode(false);
			text.setAttribute('class', "link");
			text.setAttribute('value', linkTxt);
			text.onclick = function(event){FEBE.febeOpenLink('http://www.customsoftwareconsult.com/phpBB2/index.php')};

			desc.appendChild(text);
			helpTxt = " "+helpFile.GetStringFromName("febe.help_"+index+".text3");
			desc.appendChild(document.createTextNode(helpTxt));
			helpTxtbox.appendChild(desc);
			break;

		default:
			addHelpLines(index);
			break;
	}//switch
	
	function addHelpLines(index){
		var line = 1;
		while(true){
			try{
				var helpTxt = helpFile.GetStringFromName("febe.help_"+index+".text"+line.toString());
				addHelpLine(helpTxt);
				line++;
			}catch(err){
				break;
			}
		}
		return true;
	}
	
	function addHelpLine(helpTxt){
		var txt = document.createTextNode(helpTxt);
		var desc = description.cloneNode(true);
		desc.appendChild(txt);	
		helpTxtbox.appendChild(desc);	
		helpTxtbox.appendChild(separator.cloneNode(true));
		FEBE.febeClipboard.push(helpTxt);
		FEBE.febeClipboard.push("");
		return true;
	}
	this.febePlaySound("help");
	return true;
},

errorConsole: function(that){
	let hidden;
	if(that){
		hidden = !that.checked;
	}else{
		hidden = !FEBE.febePrefs.getBoolPref("extensions.febe.debugMode");
	}
	let wm = Cc["@mozilla.org/appshell/window-mediator;1"].getService(Ci.nsIWindowMediator);  
	FEBE.febeMainWindow = wm.getMostRecentWindow("navigator:browser"); 
	let ac = FEBE.febeMainWindow.document.getElementById('appcontent');
	let container = FEBE.febeMainWindow.document.getElementById('febe_error_console_container');
	let splitter = FEBE.febeMainWindow.document.getElementById('febe_error_console_splitter');
	let console = FEBE.febeMainWindow.document.getElementById('febe_error_console');
	splitter.setAttribute('hidden', hidden);
	container.setAttribute('hidden', hidden);
	let alreadyShown = FEBEstorage.getItem("febeErrorConsoleShown", false);	
	if(!hidden && !alreadyShown){
		console.setAttribute('src', 'chrome://global/content/console.xul');
		//console.setAttribute('src', 'chrome://browser/content/devtools/webconsole.xul');
		FEBE.openBrowserConsole();
	}
},

errorConsoleInitMsg: function(){
	let msg = "*** FEBE Error Console ***";
	msg += "\n     To hide, uncheck FEBE Options > Advanced > Miscellaneous > Advanced preferences > FEBE debug mode";
	msg += "\n     To search for FEBE errors, type 'febe' into the search box (no quotes).";
	msg += "\n     To copy messages (to post in the support forum) right-click and select 'Copy'.";
	FEBE.febeMainWindow.FEBE.logMsg(msg);
	FEBEstorage.setItem("febeErrorConsoleShown", true);
	return true;
},

pauseThread: function(){
	// During validation, the message "Banned or deprecated JavaScript Identifier" is generated.
	// This function is only used when updating xul progress meters.
	// As per Jorge Villalobos, this method is acceptable for this purpose.
	let currentThread = Cc['@mozilla.org/thread-manager;1'].getService(Ci.nsIThreadManager).currentThread;
	currentThread.processNextEvent(false);
	return true;
},

}//FEBE